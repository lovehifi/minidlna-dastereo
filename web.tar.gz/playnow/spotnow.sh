#!/bin/bash

path="/var/www/playnow"
tmp=/var/www/tmp
event=$PLAYER_EVENT
trackid=$TRACK_ID
#[ "$event" != "start" ] || [ "$event" != "change" ] && exit
! [ -f /boot/hdmi ] && exit
[ -z "$trackid" ] && exit

CLIENT_ID="4fe3fecfe5334023a1472516cc99d805"
CLIENT_SECRET="0f02b7c483c04257984695007a4a8d5c"

a=$(echo "$CLIENT_ID:$CLIENT_SECRET" |base64)
curl -X POST -d -m 5 "grant_type=client_credentials&redirect_url=url&client_secret=$CLIENT_SECRET&client_id=$CLIENT_ID" https://accounts.spotify.com/api/token >$tmp/spotify.auth
access_token=$(jq -r ".access_token" < $tmp/spotify.auth)
token_type=$(jq -r ".token_type" < $tmp/spotify.auth)

#echo "$access_token"
#echo "$token_type"

trackid=$TRACK_ID
curl -m 5 -H "Authorization: $token_type $access_token" https://api.spotify.com/v1/tracks/$trackid \
-H "Accept: application/json" -H "Content-Type: application/json" >$tmp/spotify.track

title=$(jq -r ".name" $tmp/spotify.track)
album=$(jq -r ".album.name" $tmp/spotify.track)
artist=$(jq -r ".artists[0].name" $tmp/spotify.track)
img=$(jq -r ".album.images[0].url" $tmp/spotify.track)

#echo "$title;$album;$artist;$img"
curl -o $tmp/cover.jpg -m 5 $img
sudo $path/showimage spotify "$tmp/cover.jpg" "$artist - $title"
