#!/bin/bash

path="/var/www/playnow"
$path/sqlisten.sh &
sleep 5
$path/sqgetimage.sh

pipe=/var/www/tmp/pip
while :
do
    if read line; then
	a=$(echo "$line" |grep "newsong\|load_done")
	if [ -n "$a" ]; then
	    echo "new song event"
	    $path/sqgetimage.sh
	fi
    fi
done <"$pipe"
