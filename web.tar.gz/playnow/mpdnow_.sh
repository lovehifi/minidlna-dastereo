#!/bin/sh

black="/var/www/img/black.png"
dkey="pEsOuXarSDrqtXwQANUc"
dsecret="GsOSjuWcLHhVHnFKUMPFgITJLaqMhihk"
www=/var/www
tmp=/var/www/tmp
path=/var/www/playnow

MUSIC_DIR="/mnt"
IMG_REG="(front|cover|folder)\.(jpg|jpeg|png)$"

urldecode() { : "${*//+/ }"; echo -e "${_//%/\\x}"; }

urlencode() {
    # urlencode <string>
    old_lc_collate=$LC_COLLATE
    LC_COLLATE=C
    
    local length="${#1}"
    for (( i = 0; i < length; i++ )); do
        local c="${1:i:1}"
        case $c in
            [a-zA-Z0-9.~_-]) printf "$c" ;;
            *) printf '%%%02X' "'$c" ;;
        esac
    done
    
    LC_COLLATE=$old_lc_collate
}


while :
do
#    sudo pkill radio
    title=
    name=
    file1=
    img=
    artist=
    mpc idle player
    sleep 1
    file=$(mpc current -f "%file%")

    if [ -n "$(echo $file |grep 'radioparadise.com/aac-320')" ]; then
	sudo pkill radio
	curl -k -o $tmp/rp -m 5 "https://api.radioparadise.com/api/nowplaying_list?event=0&elapsed=0.001&chan=0"
	cover=$(jq -r '.song[]|.cover' $tmp/rp |head -n 1)
	cover=${cover//\\/}

	artist=$(jq -r '.song[]|.artist' $tmp/rp |head -n 1)
	title=$(jq -r '.song[]|.title' $tmp/rp |head -n 1)
	fulltitle="$artist - $title"

	img="http://img.radioparadise.com/$cover"
	ext=${img##*.}
	sudo rm -f $tmp/cover.$ext
	curl -o $tmp/cover.$ext -m 5 "$img"
	img=$tmp/cover.$ext
#	fbv -r -e -i -s 1 $black
#	fbv -f -e -i -s 1 "$img"
	$path/showimage radio "$img" "$fulltitle"
    else
    if [ -n "$(echo $file |grep 'http:\|https:')" ]; then
    #radio
	oldtitle="-"
	for i in {1..2}; do
	echo -e "currentsong\nclose" | nc 127.0.0.1 6600 >$tmp/mpd.tmp
	while read line; do
	    if [ -n "$(echo $line|grep 'title:\|Title:')" ]; then
		title=${line#*: }
	    fi
	    if [ -n "$(echo $line|grep 'Name:')" ]; then
		name=${line#*: }
	    fi
	    if [ -n "$(echo $line|grep 'file:')" ]; then
		fil=${line#*: }
	    fi
	done <$tmp/mpd.tmp
	
	[ "$oldtitle" = "$title" ] && break
	if [ -n "$(echo $title|grep '-')" ]; then
	    artist=${title%% -*}
	fi
	[ -z "$title" ] && title="$name"
	y=$(cat "$tmp/radios.txt" |grep "$fil")
	if [ -n "$y" ]; then 
	    name=$(echo $y | cut -f 1 -d'|')
	    ext=$(echo $y | cut -f 3 -d'|')
	    if [ -z "$ext" ]; then
		img=
	    else
		img="/var/lib/mpd/music/webradio/logos/$name.$ext"
		echo $img >>/tmp/123.txt
	    fi
	fi
#	echo "artist: $artist;title:$title;name:$name" >>2.txt

	sudo pkill radio
	if [ -n "$(echo $fil|grep 'space-flac\|progressive-flac\|next-flac')" ]; then
#	    echo "sector">>/tmp/123.txt
	    channel=${fil##*\/}
	    channel=${channel%%-*}
#	    sudo pkill radio
	    sleep 1
	    $path/radio sector $channel &
	fi
	if [ -n "$(echo $fil|grep 'orfeyfm192')" ]; then
#	    echo "orfeyfm">>/tmp/123.txt
#	    sudo pkill radio
	    sleep 1
	    $path/radio orfey &
	fi
	if [ -n "$(echo $name|grep fonotron)" ]; then
#	    echo "fonotron">>/tmp/123.txt
	    channel=${fil##*Chan_}
	    channel=${channel%_*}
	    curl -X GET -m 5 "http://fonotron.ru/templates/fonotron/muzcentrum.php?index.php?option=com_currentlyplaying&format=json&cid=$channel" >$tmp/radio

	    author=$(jq -r ".author" $tmp/radio)
	    author=$(urldecode $author)
	    title0=$(jq -r ".title" $tmp/radio)
	    title0=$(urldecode $title0)
	    title="$author - $title0"
	    img=/var/www/img/radio_fonotron.png
	    artist=
	fi
	if [ -n "$artist" ]; then
	    lang=en
	    sudo rm -f $tmp/art.txt
#		curl -o $tmp/art.txt \
#	    "https://api.discogs.com/database/search?q=$(urlencode $artist)&type=artist&key=$dkey&secret=$dsecret&page=1&per_page=3"
#		img=$(jq -r ".results[0].cover_image" $tmp/art.txt)
	    sudo curl -o $tmp/art.txt -m 5 -d 'api_key=33e8bad40a879d61e20e3d02cda14169' \
	-d "method=artist.getInfo" \
	-d "artist=$artist" \
	-d "lang=$lang" \
	-d "format=json" \
	'http://ws.audioscrobbler.com/2.0/' 2> /dev/null
	    img1=$(jq '.artist.image[] | select(.size == "mega")' $tmp/art.txt | grep '#text')
	    img1=${img1#*:}
	    img1=${img1#*\"}
	    img1=${img1%\"*}
	    if [ -n "$img1" ]; then
		ext=${img1##*.}
		curl -o $tmp/cover.$ext -m 5 "$img1"
		img=$tmp/cover.$ext
	    else
		artalbum=${title// /+}
		artalbum=${artalbum%%[*}
		artalbum1=$(urlencode "$artalbum")
#		echo "$artalbum1"
#		sleep 1
		sudo rm -f $tmp/art.txt
		curl -o $tmp/art.txt -m 5 \
	    "https://api.discogs.com/database/search?q=$artalbum1&key=$dkey&secret=$dsecret&page=1&per_page=3"
		len=$(jq ".results|length" $tmp/art.txt)
		if [ $len -gt 0 ]; then
		    img1=$(jq -r ".results[0].cover_image" $tmp/art.txt)
		    if [ -z "$img1" ]; then
			[ -z "$img" ] && img="$www/images/internet_music.png"
		    else
			ext=${img1##*.}
			curl -o $tmp/cover.$ext -m 5 "$img1"
			img=$tmp/cover.$ext
		    fi
		else
		    [ -z "$img" ] && img="$www/images/internet_music.png"
		fi
	    fi
	    $path/showimage radio "$img" "$title"
	else #no artist
	    [ -z "$img" ] && img="$www/images/internet_music.png"
	    $path/showimage radio "$img" "$title"
	fi
	sleep 2
	oldtitle="$title"
	done
    else
	sudo pkill radio
	art="$MUSIC_DIR/${file%/*}"
#	echo "$art">2.txt
	cover="$(sudo find "$art/" -maxdepth 1 -type f | egrep -i -m1 "$IMG_REG")"
	echo -e "currentsong\nclose" | nc 127.0.0.1 6600 >$tmp/mpd.tmp
	while read line; do
	    if [ -n "$(echo \"$line\"|grep 'title:\|Title:')" ]; then
		title=${line#*: }
	    fi
	    if [ -n "$(echo \"$line\"|grep 'Artist:')" ]; then
		artist=${line#*: }
	    fi
	    if [ -n "$(echo \"$line\"|grep 'Name:')" ]; then
		name=${line#*: }
	    fi
	    if [ -n "$(echo \"$line\"|grep 'file:')" ]; then
		file1=${line#*: }
	    fi
	done <$tmp/mpd.tmp

	if [ -z "$title" ]; then
	    file1=${file1%.*}
	    title=${file1##*\/}
	fi
	[ -n "$artist" ] && fulltitle="$artist - $title" || fulltitle="$title"
	n=$(shuf -i 1-3 -n 1)

	if [ -n "$cover" ]; then
	    $path/showimage mpd "$cover" "$fulltitle"
	else #search
	    if [ -n "$artist" ] && [ -n "$album" ]; then
		artalbum=$(echo "$artist - $album" | sed "s| |+|g")
		artalbum1=${artalbum%%[*}
#		artalbum1=$(urlencode "$artalbum")
		sudo rm -f $tmp/art.txt
		curl -o $tmp/art.txt -m 5 \
	    "https://api.discogs.com/database/search?q=$artalbum1&key=$dkey&secret=$dsecret&page=1&per_page=3"
		len=$(jq ".results|length" $tmp/art.txt)
		if [ $len -gt 0 ]; then
		    img=$(jq -r ".results[0].cover_image" $tmp/art.txt)
		    if [ -z "$img" ]; then
			img="$www/img/cd${n}.jpg"
		    else
			ext=${img##*.}
			curl -o $tmp/cover.$ext -m 5 "$img"
			img=$tmp/cover.$ext
		    fi
		else
		    img="$www/img/cd${n}.jpg"
		fi
	    else
		[ -n "$file1" ] && img="$www/img/cd${n}.jpg" || img="$www/img/loaded.jpg"
	    fi
	    $path/showimage mpd "$img" "$fulltitle"
	fi
    fi
    fi #radio paradise
done
