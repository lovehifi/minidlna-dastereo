#!/bin/bash

sqname=RPi3
portcli=9090
port=9000

path=/var/www/playnow
tmp=/var/www/tmp
server=$(cat $tmp/lmsserver)

urldecode() { : "${*//+/ }"; echo -e "${_//%/\\x}"; }

wget -q -O- --post-data='{"id":1,"method":"slim.request","params": [ "RPi3", [ "status","-","1","tags:acbhlruoKNJ" ] ]}' --header 'Content-Type: application/json' http://$server:9000/jsonrpc.js >$tmp/sq.tmp

trid=$(jq -r ".result.playlist_loop[]|.coverid" <$tmp/sq.tmp)
art=$(jq -r ".result.playlist_loop[]|.artwork_url" <$tmp/sq.tmp)
art=$(urldecode "$art")
art=${art/\/imageproxy\//}
title=$(jq -r ".result.playlist_loop[]|.title" <$tmp/sq.tmp)
artist=$(jq -r ".result.playlist_loop[]|.artist" <$tmp/sq.tmp)
url=$(jq -r ".result.playlist_loop[]|.url" <$tmp/sq.tmp)

rtitle=$(jq -r ".result.playlist_loop[]|.remote_title" <$tmp/sq.tmp)
if [ -n "$artist" ]; then
    ftitle="$artist - $title"
else
    ftitle="$title"
fi

typ=sq
[ -n "$(echo $art|grep static.qobuz)" ] && art=${art%\/*}

if [ -n "$(echo $url|grep 'qobuz:')" ]; then
    typ=qobuz
fi
if [ -n "$(echo $url|grep 'tidal:')" ]; then
    typ=tidal
fi
if [ -n "$(echo $url|grep 'deezer:')" ]; then
    typ=deezer
fi
if [ -n "$(echo $url|grep 'radioparadise:')" ]; then
    typ=radioparadise
fi

if [ -n "$(echo $art|grep 'YouTube')" ]; then 
    typ=youtube
    url=$(jq -r ".result.playlist_loop[]|.url" <$tmp/sq.tmp)
    art1=${url##*\/}
    art="http://img.youtube.com/vi/$art1/hqdefault.jpg"
    ftitle=$(jq -r ".result.current_title" <$tmp/sq.tmp)
fi

ext=${art##*.}
black="/var/www/img/black.png"
if [ -n "$art" ] && [ -n "$(echo $art | grep 'http://\|https://')" ] ; then
    if [ "$ext" = "png" ] || [ "$ext" = "jpg" ]; then
	curl -o $tmp/cover.$ext -m 5 "$art"
	$path/showimage $typ $tmp/cover.$ext "$ftitle"
    fi
else
    curl -o $tmp/cover.jpg -m 5 "http://$server:$port/music/$trid/cover.jpg"
    $path/showimage $typ $tmp/cover.jpg "$ftitle"
fi
