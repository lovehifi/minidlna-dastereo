#!/bin/sh

uri=$1

# ! test -f /boot/hdmi_playnow && exit

dkey="pEsOuXarSDrqtXwQANUc"
dsecret="GsOSjuWcLHhVHnFKUMPFgITJLaqMhihk"
www=/var/www
tmp=/var/www/tmp
cache=/tmp/cache

path=/var/www/playnow

#MUSIC_DIR="/mnt"
#IMG_REG="(front|cover|folder)\.(jpg|jpeg|png)$"

urldecode() { : "${*//+/ }"; echo -e "${_//%/\\x}"; }

urlencode() {
    # urlencode <string>
    old_lc_collate=$LC_COLLATE
    LC_COLLATE=C
    
    local length="${#1}"
    for (( i = 0; i < length; i++ )); do
        local c="${1:i:1}"
        case $c in
            [a-zA-Z0-9.~_-]) printf "$c" ;;
            *) printf '%%%02X' "'$c" ;;
        esac
    done
    
    LC_COLLATE=$old_lc_collate
}

sudo rm -f $cache/mympd_station
sudo rm -f $cache/mympd_title
sudo rm -f $cache/mympd_img

if [ -n "$(echo $uri |grep 'radioparadise.com/aac-320')" ]; then
#    sudo pkill radio
    curl -k -o $tmp/rp -m 5 "https://api.radioparadise.com/api/nowplaying_list?event=0&elapsed=0.001&chan=0"
    cover=$(jq -r '.song[]|.cover' $tmp/rp |head -n 1)
    cover=${cover//\\/}

    artist=$(jq -r '.song[]|.artist' $tmp/rp |head -n 1)
    title1=$(jq -r '.song[]|.title' $tmp/rp |head -n 1)

    title="$artist - $title1"
    img="http://img.radioparadise.com/$cover"
    echo "Radio Paradise" >$cache/mympd_station
    echo "$title" > $cache/mympd_title
    echo "$img" > $cache/mympd_img
    exit
else
    echo -e "currentsong\nclose" | nc 127.0.0.1 6600 >$tmp/mympd.tmp
    while read line; do
	if [ -n "$(echo $line|grep 'title:\|Title:')" ]; then
	    title=${line#*: }
	fi
	if [ -n "$(echo $line|grep 'Name:')" ]; then
	    name=${line#*: }
	fi
    done <$tmp/mympd.tmp

    if [ -n "$(echo $title|grep '-')" ]; then
	artist=${title%% -*}
    fi

    [ -z "$title" ] && title="$name"
    str=$(cat "$tmp/radios.txt" |grep "$uri")
    if [ -n "$str" ]; then 
	station=$(echo $str | cut -f 1 -d'|')
	ext=$(echo $str | cut -f 3 -d'|')
	if [ -n "$ext" ]; then
	    img="library/webradio/logos/$station.$ext"
	fi
	echo "$station" >$cache/mympd_station
	echo $img >$cache/mympd_img
#	exit
    fi

    if [ -n "$(echo $name|grep 'fonotron')" ]; then
	channel=${uri##*Chan_}
	channel=${channel%_*}
	sudo rm -f $tmp/radio
	curl -X GET -m 5 "http://fonotron.ru/templates/fonotron/muzcentrum.php?index.php?option=com_currentlyplaying&format=json&cid=$channel" >$tmp/radio

	author=$(jq -r ".author" $tmp/radio)
	author=$(urldecode $author)
	title0=$(jq -r ".title" $tmp/radio)
	title0=$(urldecode $title0)

	title="$author - $title0"
	img=assets/radio_fonotron.png
#	artist=
	echo "$title" >$cache/mympd_title
	echo "$img" >$cache/mympd_img
	exit
    fi
	
    if [ -n "$(echo $title| grep ' - ')" ] && [ -n "$title" ]; then
	artalbum=${title// /+}
	artalbum=${artalbum%%[*}
	artalbum1=$(urlencode "$artalbum")
	sudo rm -f $tmp/art.txt
	curl -o $tmp/art.txt -m 5 \
	"https://api.discogs.com/database/search?q=$artalbum1&key=$dkey&secret=$dsecret&page=1&per_page=3"
	len=$(jq ".results|length" $tmp/art.txt)
	if [ $len -gt 0 ]; then
	    img1=$(jq -r ".results[0].cover_image" $tmp/art.txt)
	    if [ -n "$img1" ]; then
		img=$img1
	    fi
	else #artist
	    lang=en
	    sudo rm -f $tmp/art.txt
	    sudo curl -o $tmp/art.txt -d 'api_key=33e8bad40a879d61e20e3d02cda14169' \
	    -d "method=artist.getInfo" \
	    -d "artist=$artist" \
	    -d "lang=$lang" \
	    -d "format=json" -m 5 \
	    'http://ws.audioscrobbler.com/2.0/' 2> /dev/null
	    img1=$(jq '.artist.image[] | select(.size == "mega")' $tmp/art.txt | grep '#text')
	    if [ -n "$img1" ]; then
		img1=${img1#*:}
		img1=${img1#*\"}
		img1=${img1%\"*}
		img=$img1
	    fi
	fi
    fi
fi

[ -z "$img" ] && img="/assets/coverimage-httpstream.png"
echo "$img" > $cache/mympd_img
