#!/bin/bash
#mkfifo $tmp/shairport-sync-metadata

path=/var/www/playnow
tmp=/var/www/tmp
oldtitle="-"
shairport-sync-metadata-reader < $tmp/shairport-sync-metadata| while read line
do
    echo "$line"
    a=$(echo "$line" | grep "Artist:")
    if [ -n "$a" ]; then
	artist="$a"
	artist=${artist#*\"}
	artist=${artist%\"*}
    fi
    a=$(echo "$line" | grep "Album name:")
    if [ -n "$a" ]; then 
	album="$a"
	album=${album#*\"}
	album=${album%\"*}
    fi
    a=$(echo "$line" | grep "Title:")
    if [ -n "$a" ]; then
	title="$a"
	title=${title#*\"}
	title=${title%\"*}
    fi
#    if [ -n "$title" ] ; then
	#reload image
#	oldtitle="$title"
#    fi
    pic=$(echo "$line" | grep "Picture received")
    if [ -n "$pic" ] && [ "$oldtitle" != "$title" ]; then
	[ -n "$artist" ] && fulltitle="$artist - $title" || fulltitle="$title"
	fulltitle="$fulltitle"
#	fbv -r -e -s 1 /var/www/img/black.png
#	fbv -e -f -s 1 /tmp/airplay.img
	cp -f /tmp/airplay.img $tmp/airplay.img
	$path/showimage airplay $tmp/airplay.img "$fulltitle"
	oldtitle="$title"
    fi
done 
