#!/bin/bash

www=/var/www
tmp=$www/tmp
path=$www/playnow

sudo pkill node
sleep 1
node $path/roon &
sleep 3
curl -X GET -m 5 "http://127.0.0.1:3002/roonAPI/listZones" >$tmp/rzone
zoneid=$(jq -r ".zones| keys[0]" $tmp/rzone)
#echo $zoneid
oldline=
oldkey=

while :
do
    curl -X GET "http://127.0.0.1:3002/roonAPI/getZone?zoneId=$zoneid"  >$tmp/roon
    line1=$(jq -r ".zoneId.now_playing.one_line.line1" $tmp/roon)
    imagekey=$(jq -r ".zoneId.now_playing.image_key" $tmp/roon)
    echo $imagekey
    if ! [ "$imagekey" = "$oldkey" ]; then
	if [ "$imagekey" = "null" ]; then
	    img=$www/img/cd1.jpg
	else
	    rm -f roon.jpg
	    curl -X GET -o $tmp/roon.jpg -m 5 "http://127.0.0.1:3002/roonAPI/getOriginalImage?image_key=$imagekey"
	    img=$tmp/roon.jpg
	fi
    fi
    if ! [ "$oldline" = "$line1" ]; then
	#show image and tags
	$path/showimage roon "$img" "$line1"
    fi
    oldline=$line1
    oldkey=$imagekey
    sleep 5
done
