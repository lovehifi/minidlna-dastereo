#!/bin/bash

black="/var/www/img/black.png"
fbv -r -e -i -s 1 $black
fbv -f -i -s 1 "/var/www/img/aplayer.jpg"
