#!/bin/bash

sqname=RPi3
portcli=9090
tmp=/var/www/tmp

server=$(sudo find_servers |head -n 1)
server=${server#*(}
server=${server%)*}
[ -z "$server" ] && server=$(cat /opt/sq/lmsserver)
echo "$server">$tmp/lmsserver

sudo mkfifo $tmp/pip

while :
do
    printf "$sqname listen 1\n" |nc $server $portcli >$tmp/pip
done
