#!/bin/sh

#uri=$1
# ! test -f /boot/hdmi_playnow && exit

dkey="pEsOuXarSDrqtXwQANUc"
dsecret="GsOSjuWcLHhVHnFKUMPFgITJLaqMhihk"
www=/var/www
tmp=/var/www/tmp
cache=/tmp/cache

path=/var/www/playnow

#MUSIC_DIR="/mnt"
#IMG_REG="(front|cover|folder)\.(jpg|jpeg|png)$"

urldecode() { : "${*//+/ }"; echo -e "${_//%/\\x}"; }

urlencode() {
    # urlencode <string>
    old_lc_collate=$LC_COLLATE
    LC_COLLATE=C
    
    local length="${#1}"
    for (( i = 0; i < length; i++ )); do
        local c="${1:i:1}"
        case $c in
            [a-zA-Z0-9.~_-]) printf "$c" ;;
            *) printf '%%%02X' "'$c" ;;
        esac
    done
    
    LC_COLLATE=$old_lc_collate
}

sudo rm -f $cache/mympd_station
sudo rm -f $cache/mympd_img
sudo rm -f $cache/mympd_title

 #local/network music
echo -e "currentsong\nclose" | nc 127.0.0.1 6600 >$tmp/mpd.tmp
while read line; do
    if [ -n "$(echo \"$line\"|grep 'title:\|Title:')" ]; then
	title=${line#*: }
    fi
    if [ -n "$(echo \"$line\"|grep 'Artist:')" ]; then
	artist=${line#*: }
    fi
    if [ -n "$(echo \"$line\"|grep 'Album:')" ]; then
	album=${line#*: }
    fi
    if [ -n "$(echo \"$line\"|grep 'Name:')" ]; then
	name=${line#*: }
    fi
    if [ -n "$(echo \"$line\"|grep 'file:')" ]; then
	file1=${line#*: }
    fi
done <$tmp/mpd.tmp

#echo $artist:$title:$album

if [ -z "$title" ]; then
    file1=${file1%.*}
    title=${file1##*\/}
    echo "$title" > $cache/mympd_title
fi

if [ -n "$artist" ] && [ -n "$album" ]; then
    artalbum=$(echo "$artist - $album" | sed "s| |+|g")
    echo $artalbum
#    artalbum1=${artalbum%%[*}
    artalbum1=$(urlencode "$artalbum")
    echo $artalbum1
    sudo rm -f $tmp/art.txt
    curl -o $tmp/art.txt -m 5 \
    "https://api.discogs.com/database/search?q=$artalbum1&key=$dkey&secret=$dsecret&page=1&per_page=3"
    len=$(jq ".results|length" $tmp/art.txt)
    if [ $len -gt 0 ]; then
	img1=$(jq -r ".results[0].cover_image" $tmp/art.txt)
	if [ -n "$img1" ]; then
	    img=$img1
	fi
    fi
fi

[ -z "$img" ] && img="/assets/coverimage-notavailable.png"
echo "$img" > $cache/mympd_img
