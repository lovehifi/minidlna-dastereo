#!/bin/sh

roonmixer=softvol
dsdmode=dopusb

conf=/etc/raat.conf

if [ "$roonmixer" = "fixedvol" ]; then
    s1="sed '/volume/,/}/c      \"volume\": { \n\
\t\"type\": \"null\",\n\
\t\"optional\": true\n \
\t}'"
else
    s1="sed '/volume/,/}/c \"volume\": { \n\
\t\"type\": \"software\"\n\
\t}'"
fi

[ "$dsdmode" = "native" ] && ds=native || ds=dop
s2="sed '/dsd_mode/c\\\t\"dsd_mode\":\t\"$ds\",'"
sp=$(cat /etc/raat.conf |grep "signal_path")

case "$dsdmode" in
"dop")
    s2="sed '/signal_path/d' | $s2"
    ;;
"dopusb"|"native")
    [ -z "$sp" ] && s2="$s2 | sed '/dsd_mode/i \\\t\"signal_path\": [ { \"quality\": \"lossless\", \"type\": \"output\", \"method\": \"usb\" } ],'"
    ;;
esac
eval "cat $conf | $s1 |$s2"
