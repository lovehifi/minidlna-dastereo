#!/bin/bash

src=/opt/json/scloud_main.json
curl -k -o $src -m 5 "https://api-v2.soundcloud.com/mixed-selections?client_id=pKRYMYhRDOaPdIiGMoamQlBYrQmFBLge&limit=10&offset=0&linked_partitioning=1&app_version=1590139067&app_locale=en"
