#!/bin/sh

main=/opt/sygma/index.json
#epfile=/tmp/sygma-episodes2.json
mkdir /tmp/cache/sygma
num=$(jq '.data.episodes|length' $main)
c=0
while [ $c -lt $num ]; do
    url=$(jq -r ".data.episodes[$c]|.picture.small.url" $main)
    fil=${url##*\/}
    name=${fil%.*}
#    curl -k -o /tmp/cache/sygma/$fil $url
    convert -resize 180 -quality 82 -strip -unsharp 0x0.55+0.55+0.008 /tmp/cache/sygma/$fil /tmp/cache/sygma2/$name.jpg
    echo "$c"
    c=$(($c+1))
done