#!/bin/sh

#main=/opt/sygma/index.json
epfile=/tmp/sygma-episodes2.json
enfile=/tmp/sygma-episodes1.json
cache=/tmp/cache/sygma2
num=$(jq '.data|length' $epfile)
c=0
jq -c '.data[] += {"imgcache":"none"}' $epfile >$enfile

while [ $c -lt $num ]; do
    echo $c
    url=$(jq -r ".data[$c]|.picture" /tmp/1)
    name=${url##*\/}
    name=${name%.*}
    fname="${name}.jpg"
    if test -f "$cache/$fname" ; then
	jq -c ".data[$c].imgcache=\"$fname\"" $enfile >/tmp/2
	mv -f /tmp/2 >$enfile
    fi
    c=$(($c+1))
done
