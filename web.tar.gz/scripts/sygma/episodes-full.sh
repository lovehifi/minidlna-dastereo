#!/bin/sh

main=/opt/sygma/index.json
epfile=/tmp/sygma-episodes2.json
num=$(jq '.data.episodes|length' $main)
c=0
d=1
echo -n "{\"data\":" >$epfile
jq -c '.data.episodes' $main >>$epfile
echo -n ",\"EntitiesReturn\": $num}">>$epfile