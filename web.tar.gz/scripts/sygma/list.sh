#!/bin/sh

echo "list"
main=/opt/sygma/index.json
target=/tmp/sygma-list
#target=/opt/sygma/json/sygma-list
num=$(jq -c ".data.shows|length"<$main)
c=0 
echo "$num"
while [ $c -lt $num ]; do
    slug1=$(jq -r ".data.shows[$c].slug"<$main)
    echo "{\"data\":" > $target-$c.json
    jq -r -c ".data.shows[$c].episodes" < $main >> $target-$c.json
    echo "}" >> $target-$c.json
    echo "$slug1"
    c=$(($c+1))
done
