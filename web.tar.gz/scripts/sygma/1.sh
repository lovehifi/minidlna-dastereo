num=$(jq -c ".data|length"</tmp/sygma-show.json)
c=0 
echo "$num"
while [ $c -lt $num ]; do
    slug1=$(jq -r ".data[$c].slug"</tmp/sygma-show.json)
    echo "$slug1"
    c=$(($c+1))
done