#!/bin/sh

src=/opt/json/sygma.json
curl -o $src -m 5 https://radio.syg.ma/index.json