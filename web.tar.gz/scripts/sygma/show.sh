#!/bin/sh

main=/opt/sygma/index.json
showfile=/tmp/sygma-show.json
#showfile=/opt/sygma/json/sygma-show.json
num=$(jq '.data.shows|length' $main)
c=0
d=1
echo -n "{\"data\":" >$showfile
jq -c ".data.shows |map({id,slug,title,description,picture})" $main>>$showfile

echo -n ",\"EntitiesReturn\": $c}">>$showfile

/opt/sygma/list.sh

exit

while [ $c -lt $num ]; do
    k=0
    eval $(jq -r ".data.shows[$c]|@sh \"id=\(.id) slug=\(.slug) title=\(.title) desc=\(.description) pic=\(.picture.url) \"" $main)
    [ -z "$pict" ] && pict=--
    echo -n "{\"id\":$id,\"slug\":\"$slug\", \"title\":\"$title\",\"desc\":\"$desc\",\"pic\":\"$pic\"}">>$showfile
    if ! [ $d -eq $num ]; then
	echo -n ",">>$showfile
    fi
    c=$(($c+1))
    d=$(($d+1))
done
