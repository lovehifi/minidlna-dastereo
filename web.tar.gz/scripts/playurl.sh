#!/bin/sh

player=mpd
ip=192.168.0.105

echo "$1">>/tmp/123
[ -z "$1" ] && exit

if [ "$player" == "mpd" ]; then
#    systemctl stop aprenderer
    mpc clear
    mpc add "$1"
    mpc play
fi
if [ "$player" == "aprenderer" ]; then
    mpc stop
    sudo systemctl start aprenderer
    python /var/www/scripts/dlnap1.py --ip $ip --play "$1" &
fi
