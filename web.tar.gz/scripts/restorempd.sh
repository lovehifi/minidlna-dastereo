#!/bin/sh

# write settings
tjson=/home/tidal.json
qjson=/home/qobuz.json
#name=$(jq -r ".name" <$json)
mpdconf=/etc/mpd.conf

user=$(jq -r ".username" $tjson)
pass=$(jq -r ".password" $tjson)
if [ -n "$user" ]; then
    #write to mpd.conf
    cat $mpdconf | sed "/tidal/,/\}/s|username.*|username\t\"$user\"|1;/tidal/,/\}/s|password.*|password\t\"$pass\"|1">/tmp/temp.1 
    sudo mv -f /tmp/temp.1 $mpdconf
fi

user=$(jq -r ".username" $qjson)
pass=$(jq -r ".password" $qjson)

if [ -n "$user" ]; then
    #write to mpd.conf
    cat $mpdconf | sed "/qobuz/,/\}/s|username.*|username\t\"$user\"|1;/qobuz/,/\}/s|password.*|password\t\"$pass\"|1">/tmp/temp.1 
    sudo mv -f /tmp/temp.1 $mpdconf
fi
