site=http://online-red.com
out=/tmp/radio.json

echo "[">$out

j=0
cat list.txt | while read line; do
  group=$(echo $line |cut -f 1 -d";")
  linc=$(echo $line |cut -f 2 -d";")

  span=
  img=
  href=
  echo "$linc"
#  curl -k -o /tmp/101 "$linc"
#  xmllint --html --xpath '/html/body/div/div/table[1]' /tmp/101 >/tmp/102
  curl -k "$linc" |xmllint --html --xpath '/html/body/div/div/table[1]' - >/tmp/102
  
  echo "{\"id\":$j,
  \"group\":\"$group\",
  \"link\":\"$linc\",
  \"items\":[" >>$out
  i=0
  while read line; do
    a=$(echo $line|grep " href=")
    if [ -n "$a" ]; then
	href=${a#*href=\"}
	href=${href%%\"*}
	curl $site/$href >/tmp/101-r
	desc=$(xmllint --html --xpath "/html/body/div/div/div/p" /tmp/101-r)
	desc=$(echo "$desc" | tr "\n" "<br>")
	desc=${desc#*<p><strong>}
	
	desc=${desc%<p align*}
	desc=${desc//\"/\\\"}
	desc=${desc//\//\\\/}
	desc=${desc//\\/\\\\}
#	echo $desc
	url=$(cat /tmp/101-r |grep " file:")
	url=${url#* file:\'}
	url=${url#* file:\"}
	url=${url%%\'*}
	url=${url%%\"*}
	rm /tmp/101-r
    fi
    a=$(echo $line|grep "<img")
    if [ -n "$a" ]; then
	img=${a#*src=\"}
	img=${img%%\"*}
	alt=${a#*alt=\"}
	alt=${alt%%\"*}
    fi
    a=$(echo $line|grep "<span")
    if [ -n "$a" ]; then
	span=${a#*<span>}
	span=${span%%<\/span>*}
#	echo "$alt|$href|$url|$img|$span" >>/tmp/radio.txt
	echo "{\"name\":\"$alt\",\"link\":\"$href\",\"url\":\"$url\",\"img\":\"${site}${img}\",\"span\":\"$span\",\"desc\":\"<strong>$desc\"}," >>$out
	i=$(($i+1))
	alt=
	span=
	url=
	href=
	echo "$group - $i"
#	break
    fi
  done </tmp/102
  rm /tmp/102
  echo "{}]},">>$out
#  break
  j=$(($j+1))
done
echo "]">>$out

cp $out -f /opt/onlinered/list.json
