desc=$(xmllint --html --xpath '//h2|//td[@class="text-stream"]/text()' latin.html)
#desc=$(echo "$desc" |tr "^M" "<br>")
desc=$(echo "$desc" |sed "s/^M/<br>/g")
echo $desc

a=$(cat latin.html | grep "file:")
a=${a#*file:\"}
a=${a%%\"*}
echo $a
