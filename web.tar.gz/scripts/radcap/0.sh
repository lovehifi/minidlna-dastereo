#!/bin/sh

tmp=/tmp/102r
echo "[" >/tmp/radcap.json
i=0
b=0
cat index-db.html | while read line; do
    if [ -n "$(echo $line | grep '<h2')" ]; then
#    a=${line}
      url=${line#*href=\"}
      url=${url%%\"*}
      title=${line%\<\/a\>*}
      title=${title##*\>}
      [ $b -gt 0 ] && echo "]},">>/tmp/radcap.json
echo "{\"url\":\"$url\",
\"group\":\"$title\",
\"items\":[">>/tmp/radcap.json
     b=$(($b+1))
    fi
    if [ -n "$(echo \"$line\" | grep '<a href')" ]; then
      url=${line#*href=\"}
      url=${url%%\"*}

      title=${line%\<\/span\>*}
      title=${title##*\>}
      if [ -z "$(echo $url| grep 'radcap\|index.html')" ]; then

      img=${line#*\<img src=\"}
      img=${img%%\"*}
      echo "	{
      \"url\":\"$url\",
      \"title\":\"$title\",
      \"img\":\"$img\"," >>/tmp/radcap.json
#       wget -O $tmp http://radcap.ru/$url
       curl "http://radcap.ru/$url" >$tmp
       sleep 1
	desc=$(xmllint --html --xpath '//h2|//td[@class="text-stream"]' $tmp)
	desc=${desc//<\/td>/}
	desc=${desc//\"/\'}
	desc=$(echo "$desc" |sed "s/<h2 style='.*;'>/<h2>/g" | sed "s/<td class='text-stream'>//g"| sed '/<span/,/<\/span>/d' | tr '\r\n' ' ')

	fil=$(cat $tmp | grep "file:")
	fil=${fil#*file:\"}
	fil=${fil%%\"*}
     echo "	\"audio\":\"$fil\",
     \"desc\":\"$desc\"},">>/tmp/radcap.json
#     break
     rm $tmp
     fi
    fi
    i=$(($i+1))
    echo $i
done
echo "]">>/tmp/radcap.json
