#!/bin/sh

name=$1
# write settings
json=/tmp/settings.json
sudo rm -f $json

case "$name" in
"tidal")
    fil=/home/tidal.json
    if test -f $fil; then
	cp -f $fil $json
    fi

;;
"qobuz")
    fil=/home/qobuz.json
    if test -f $fil; then
#	cp -f $fil $json
    a=$(cat /etc/mpd.conf |grep format_id)
    a=${a#*\"}
    a=${a%\"*}
    [ -z "$a" ] && a=5
	echo "{\"quality\":$a}">/tmp/q
	jq -s 'add' $fil /tmp/q > $json
    fi
;;
"youtube")
    fil=/home/youtube.json
    if test -f $fil; then
	vplayer=$(jq -r ".player" $fil)
    else
	vplayer=none
    fi
    echo -n "{\"player\":\"$vplayer\"}" > $json
;;
esac
