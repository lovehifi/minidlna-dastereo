jq -c 'del (.channels[].twitter,.channels[].updated,.channels[].lastPlaying)' somafm.json  >1

jq 'select (.channels[].playlists[].quality=="low")| del (.channels[].playlists[]' somafm.json >3