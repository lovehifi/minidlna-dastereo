len=$(jq '.|length' /tmp/mpdradio/groups.json)
c=0
rm -f 1.json
a=$(seq 0 $(($len-1)))
for c in $a
do
    tag=$(jq -r ".[$c]" /tmp/mpdradio/groups.json)

    jq ".items[]|select(.tags[] == \"$tag\")|del(.tags)" radio.json | jq -s -c "[{group:\"$tag\",items:[.[]]}]" >/tmp/2.tmp
    jq -s 'add' /tmp/1.tmp /tmp/2.tmp #>3.json
    cp 3.json 1.json
done
