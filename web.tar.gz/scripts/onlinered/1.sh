cat 1.txt | while read line; do
    url=$(echo $line |cut -f 2 -d";")
    wget "$url" | sed "/<table>/,/<\/table>/">str.txt
    break
done