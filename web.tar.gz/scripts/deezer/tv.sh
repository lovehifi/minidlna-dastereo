
url="http://tv.deezer.com/smarttv/authentication.php"
logn="dnjhjq324@gmail.com"
pass=123456
pass=$(echo $pass|openssl md5)
pass=${pass#*= }
device=panasonic

echo "curl -o r1 -d \"login=$logn\" -d \"password=$pass\" -d \"device=panasonic\" \"$url\""
curl -o r1 -d 'login=$logn' -d 'password=$pass' -d 'device=panasonic' \
-H "user-agent: Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36"  "$url"
