#!/bin/bash

#genres list
tab=$1
type=$2
val=$3
offset=$4
home=/var/www/scripts/qobuz
api=https://www.qobuz.com/api.json/0.2
app_id=579169010


path=/tmp/qobuz
if ! test -d $path; then
    sudo mkdir $path
fi

if ! test -f /tmp/qobuz/session; then
    $home/connect.sh
fi

ccode=$(cat /tmp/qobuz/ccode)
eval "$(jq -r ".|@sh \"userid=\(.user.id) zone=\(.user.zone) store=\(.user.store) plan=\(.user.credential.label) authtoken=\(.user_auth_token)\"" /tmp/qobuz/session)"

fil=/tmp/qobuz/album.json
src=1001.json
nr=$(jq -r ".items|length" $src)
echo $nr
n=0
while [ $n -lt $nr ]; do
    id=$(jq -r ".items[$n].id" $src)
    rm -f $fil
    sudo curl -o $fil -d "album_id=$id" "$api/album/get?offset=0&limit=50&extra=albumsFromSameArtist%2Cfocus&app_id=$app_id" -H "X-App-id:$app_id" -H "X-User-Auth-Token: $authtoken"
    break
    album=$(jq -r ".items[$n].album" $src)
    artist=$(jq -r ".items[$n].artist" $src)
    echo "$id"
    n=$((n+1))
done
