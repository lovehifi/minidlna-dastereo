const i18nLangs = {
    main_service:"Сервисы",
    main_radio:"Радио",
    artist:"Артист",
    album:"Альбом",
    station:"Радиостанция",
    
}