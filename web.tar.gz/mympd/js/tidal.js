"use strict";

var tidalFavs, qobuzFavs;
//tidal:TRACK,ALBUM,VIDEO,ARTIST,PLAYLIST
//qobuz:albums,tracks,artists
function checkTFav(type,id) {
    if (!tidalFavs) return false;
    if (type == "track") {
	for (var i in tidalFavs.TRACK) {
	    if (tidalFavs.TRACK[i] == id) return true;
	}
	return false;
    } else
    if (type == "album") {
	for (var i in tidalFavs.ALBUM) {
	    if (tidalFavs.ALBUM[i] == id) return true;
	}
	return false;
    } else
    if (type == "artist") {
	for (var i in tidalFavs.ARTIST) {
	    if (tidalFavs.ARTIST[i] == id) return true;
	}
	return false;
    } else
    if (type == "playlist") {
	for (var i in tidalFavs.PLAYLIST) {
	    if (tidalFavs.PLAYLIST[i] == id) return true;
	}
	return false;
    } else
    if (type == "video") {
	for (var i in tidalFavs.VIDEO) {
	    if (tidalFavs.VIDEO[i] == id) return true;
	}
	return false;
    }
}

function checkQFav(type,id) {
    if (!qobuzFavs) return false;
    if (type == "track") {
	for (var i in qobuzFavs.tracks) {
	    if (qobuzFavs.tracks[i] == id) return true;
	}
	return false;
    }
    if (type == "album") {
	for (var i in qobuzFavs.albums) {
	    if (qobuzFavs.albums[i] == id) return true;
	}
	return false;
    }
    if (type == "artist") {
	for (var i in qobuzFavs.artists) {
	    if (qobuzFavs.artists[i] == id) return true;
	}
	return false;
    }
    if (type == "playlist") {
	for (var i in qobuzFavs.playlists) {
	    if (qobuzFavs.playlists[i] == id) return true;
	}
	return false;
    }
}

function parseFav(obj, request) {
    if (request.cmd == "API_TIDAL_GROUP") tidalFavs = obj;
    if (request.cmd == "API_QOBUZ_GROUP") qobuzFavs = obj;
//    console.log(obj);
}

function parseSet(obj,request) {
    if (request.data.name == "tidal") {
	var tl = document.getElementById("tidalLogin");
	tl.value = obj.username;
	var tp = document.getElementById("tidalPass");
	tp.value = obj.password;
	if (obj.username) sendAPI({"cmd": "API_TIDAL_GROUP","data":{"group":"fav"}}, parseFav);
    }
    else if (request.data.name == "qobuz") {
	var tl = document.getElementById("qobuzLogin");
	tl.value = obj.username;
	var tp = document.getElementById("qobuzPass");
	tp.value = obj.password;
	var tp = document.getElementById("qobuzQuality");
	tp.value = obj.quality;

	if (obj.username) sendAPI({"cmd": "API_QOBUZ_GROUP","data":{"group":"fav"}}, parseFav);
    }
    else if (request.data.name == "youtube") {
	var tl = document.getElementById("youtubePlayer");
	tl.value = obj.player;
    }
}

function showPass(serv){
    var el = document.getElementById(serv+'Pass');
    var type = el.getAttribute('type');
    el.setAttribute('type',(type == 'text' ? 'password':'text'));
}

function modalSearch(cmd){
    var el = document.getElementById('tidalS');
    if (cmd == 'show')
	el.classList.remove('hide');
    if (cmd == 'hide')
	el.classList.add('hide');
}

function modalQSearch(cmd){
    var el = document.getElementById('qobuzS');
    if (cmd == 'show')
	el.classList.remove('hide');
    if (cmd == 'hide')
	el.classList.add('hide');
}

function streamconf() {
    sendAPI({"cmd": "API_SETTINGS_READ","data":{"name":"tidal"}}, parseSet);
    sendAPI({"cmd": "API_SETTINGS_READ","data":{"name":"qobuz"}}, parseSet);
    sendAPI({"cmd": "API_SETTINGS_READ","data":{"name":"youtube"}}, parseSet);
}

//===========================================================

var QobuzGenreHandler = function(genre) {
  return function() {
  var view = app.current.view;
  if (view == 'albums' || view == 'playlists') 
    appGoto("Qobuz","page",view,'0/'+genre+'/'); 

  };
}

var PitchGenreHandler = function(genre) {
  return function() { 
  var gr = document.getElementById('pitchMenu');
  var a = gr.getElementsByClassName('active');
    var arg = a[0].getAttribute('data-tag');

  appGoto("Pitchfork",arg,undefined,'0/'+genre+'/'); 
  };
}

var PitchHandler = function(arg) {
  return function() { 
  var gr = document.getElementById('pitchGenres');
  var a = gr.getElementsByClassName('active');
     var genre = a[0].getAttribute('data-tag');
  appGoto("Pitchfork",arg,undefined,'0/'+genre+'/'); 
  };
}

var ecmHandler = function(filter) {
  return function() { 
  var gr = document.getElementById('ecmMenu');
  appGoto("Tidal","page","ecm",'0/'+filter+'/'); 
  };
}

var a1001Handler = function(filter) {
  return function() { 
  var gr = document.getElementById('a1001Menu');
  appGoto("Tidal","page","1001",'0/'+filter+'/'); 
  };
}

var q1001Handler = function(filter) {
  return function() { 
  var gr = document.getElementById('q1001Menu');
  appGoto("Qobuz","page","1001",'0/'+filter+'/'); 
  };
}

function primemenu(){
var odata=['home','browse','composers','conductors','ensembles','soloists'];
var odesc=['Home','Browse','Composers','Conductors','Ensembles','Soloists'];
    var nrItems = odata.length;
    var cardContainer = document.getElementById('primeMenu');
    for (var i = 0; i < nrItems; i++) {
    	var item = document.createElement('a');
    	item.classList.add('dropdown-item');
    	item.id = 'cardPrimeNav' + odata[i];
    	item.href = '#';
    	item.onclick = createClickHandler('Prime',odata[i]);
    	var str ='';
    	if (odata[i]=='home') str = 'home'
    	else if (odata[i]=='browse') str = 'explore'
    	else if (odata[i]=='composers') str = 'person';
    	else if (odata[i]=='conductors') str = 'person';
    	else if (odata[i]=='ensembles') str = 'group';
    	else if (odata[i]=='soloists') str = 'person';
    	item.innerHTML = '<i class="material-icons">'+str+'</i>'+odesc[i];
    	cardContainer.appendChild(item);
    }
}

function tidalmenu(){
var odata=['home','explore','videos','my','div','ecm','daaudio','1001','plists','apple','ddd','twgeema','search','account'];
var odesc=['Home','Explore','Videos','My collection','divider','ECM label','DA choice','1001 Albums','History','Apple Music','Digital Dream','TWGEEMA','Search','Account'];
var years=["all","2010s","2000s","1990s","1980s","1970s"];
var years2=["all","2000s","1990s","1980s","1970s","1960s","1950s"];
    
    var nrItems = odata.length;
    var cardContainer = document.getElementById('tidalMenu');
    for (var i = 0; i < nrItems; i++) {
	if (odata[i] == 'div'){
    	    var item = document.createElement('div');
	    item.classList.add('divider');
    	    cardContainer.appendChild(item);
	}
/*	else if (odata[i] == 'my'){
    	    var item = document.createElement('div');
    	    item.innerHTML = odesc[i];
    	    item.classList.add('dropdown-item');
    	    cardContainer.appendChild(item);
    	}*/
	else {
    	    var item = document.createElement('a');
    	    item.classList.add('dropdown-item');
    	    item.id = 'cardTidalNav' + odata[i];
    	    item.href = '#';
    	    var list0 = 'ecm|daaudio|1001|apple|ddd|plists|twgeema';
    	    if (list0.indexOf(odata[i])!=-1) {
    		item.onclick = createClickHandler('Tidal','page',odata[i]);
    	    } else
    		item.onclick = createClickHandler('Tidal',odata[i]);

    	    var str ='';
//    	    if (odata[i]=='myalbums') str = 'album'
//    	    else if (odata[i]=='mymix') str = 'track_changes'
//    	    else if (odata[i]=='myartists') str = 'people'
//    	    else if (odata[i]=='mytracks') str = 'audiotrack'
//    	    else if (odata[i]=='myplists') str = 'playlist_play'
    	    if (odata[i]=='my') str = 'favorite_border'
    	    else if (odata[i]=='explore') str = 'explore'
    	    else if (odata[i]=='search') str = 'search'
    	    else if (odata[i]=='videos') str = 'music_video'
    	    else if (odata[i]=='daaudio') str = 'thumb_up'
    	    else if (odata[i]=='ecm') str = 'label'
    	    else if (odata[i]=='1001') str = 'pan_tool'
    	    else if (odata[i]=='plists') str = 'date_range'
    	    else if (odata[i]=='apple') str = 'center_focus_weak'
    	    else if (odata[i]=='ddd') str = 'flare'
    	    else if (odata[i]=='twgeema') str = 'track_changes'
    	    else if (odata[i]=='home') str = 'home'
    	    else if (odata[i]=='account') str = 'account_circle';
    	    item.innerHTML = '<i class="material-icons">'+str+'</i>'+odesc[i];
    	    cardContainer.appendChild(item);
        }
    } //for
// ecm menu yeasr
    var nrItems = years.length;
    var cardContainer = document.getElementById('ecmMenu');
    for (var i = 0; i < nrItems; i++) {
    	var item = document.createElement('a');
    	item.classList.add('dropdown-item');
    	item.id = 'ecm' + years[i];
    	item.href = '#';
    	item.setAttribute("data-tag",years[i])
    	item.onclick = ecmHandler(years[i]);
    	item.innerHTML = years[i];
    	cardContainer.appendChild(item);
    }
    var nrItems = years2.length;
    var cardContainer = document.getElementById('a1001Menu');
    for (var i = 0; i < nrItems; i++) {
    	var item = document.createElement('a');
    	item.classList.add('dropdown-item');
    	item.id = 'a1001' + years2[i];
    	item.href = '#';
    	item.setAttribute("data-tag",years2[i])
    	item.onclick = a1001Handler(years2[i]);
    	item.innerHTML = years2[i];
    	cardContainer.appendChild(item);
    }
}

function parseQobuzGenres(obj,request){
    var cardContainer = document.getElementById('qobuzGenres');
    var len = obj.genres.items.length;
    var item = document.createElement('a');
    item.classList.add('dropdown-item');
    item.id = 'QobuzGenreall';
    item.href = '#';
    item.setAttribute("data-id","all");
    item.setAttribute("data-tag","all");
    item.onclick = QobuzGenreHandler('all');
    item.innerHTML = 'All';
    cardContainer.appendChild(item);
    
    for (var i=0; i<len; i++) {
	var a = obj.genres.items[i];
    	var item = document.createElement('a');
    	item.classList.add('dropdown-item');
    	item.id = 'QobuzGenre' + a.id;
    	item.href = '#';
    	item.setAttribute("data-id",a.id);
    	item.setAttribute("data-tag",a.slug);
    	item.onclick = QobuzGenreHandler(a.id);
    	item.innerHTML = a.name;
    	cardContainer.appendChild(item);
    }
}

function qobuzmenu(){
var odata = ['explore','albums','playlists','my','div','labels','daaudio','1001','search','account'];
var odesc = ['Explore','New','Playlists','My collection','divider','Labels','DA Choice','1001 Albums','Search','Account'];
var years2 = ["all","2000s","1990s","1980s","1970s","1960s","1950s"];
    var nrItems = odata.length;
    var cardContainer = document.getElementById('qobuzMenu');
    for (var i = 0; i < nrItems; i++) {
	if (odata[i] == 'div'){
    	    var item = document.createElement('div');
	    item.classList.add('divider');
    	    cardContainer.appendChild(item);
	}
	else {
    	    var item = document.createElement('a');
    	    item.classList.add('dropdown-item');
    	    item.id = 'cardQobuzNav' + odata[i];
    	    item.href = '#';
	    var list0 = 'daaudio|1001|playlists|albums';
    	    if (list0.indexOf(odata[i])!=-1) {
    		item.onclick = createClickHandler('Qobuz','page',odata[i]);
    	    } else
    		item.onclick = createClickHandler('Qobuz',odata[i]);
    	
    	    var str ='';
    	    if (odata[i]=='myalbums') str = 'album'
//    	    else if (odata[i]=='myartists') str = 'people'
//    	    else if (odata[i]=='mytracks') str = 'audiotrack'
//    	    else if (odata[i]=='myplists') str = 'playlist_play'
    	    else if (odata[i]=='my') str = 'favorite_border'
    	    else if (odata[i]=='playlists') str = 'playlist_play'
    	    else if (odata[i]=='albums') str = 'album'
    	    else if (odata[i]=='explore') str = 'explore'
    	    else if (odata[i]=='daaudio') str = 'thumb_up'
    	    else if (odata[i]=='1001') str = 'pan_tool'
    	    else if (odata[i]=='labels') str = 'label'
    	    else if (odata[i]=='search') str = 'search'
    	    else if (odata[i]=='home') str = 'home'
    	    else if (odata[i]=='account') str = 'account_circle';
    	    item.innerHTML = '<i class="material-icons">'+str+'</i>'+odesc[i];
    	    cardContainer.appendChild(item);
        }
    } // for
    var nrItems = years2.length;
    var cardContainer = document.getElementById('q1001Menu');
    for (var i = 0; i < nrItems; i++) {
    	var item = document.createElement('a');
    	item.classList.add('dropdown-item');
    	item.id = 'q1001' + years2[i];
    	item.href = '#';
    	item.setAttribute("data-tag",years2[i])
    	item.onclick = q1001Handler(years2[i]);
    	item.innerHTML = years2[i];
    	cardContainer.appendChild(item);
    }

// qobuz-genres
    sendAPI({"cmd": "API_QOBUZ_GENRES"}, parseQobuzGenres);
}

function youtubemenu(){
var odata = ['search','ddd','da','account'];
var odesc = ['Search','Digital Dream','DA Choice','Settings'];
    var nrItems = odata.length;
    var cardContainer = document.getElementById('youtubeMenu');
    for (var i = 0; i < nrItems; i++) {
    	var item = document.createElement('a');
    	item.classList.add('dropdown-item');
    	item.id = 'cardYoutubeNav' + odata[i];
    	item.href = '#';
        if (odata[i]=='ddd' || odata[i]=='da') {
    	    item.onclick = createClickHandler('Youtube','page',odata[i]);
    	} else 
    	    item.onclick = createClickHandler('Youtube',odata[i]);

    	var str ='';
    	if (odata[i]=='search') str = 'search'
    	else if (odata[i]=='ddd') str = 'flare'
    	else if (odata[i]=='da') str = 'thumb_up'
    	else if (odata[i]=='account') str = 'account_circle';
    	item.innerHTML = '<i class="material-icons">'+str+'</i>'+odesc[i];
    	cardContainer.appendChild(item);
    }
}

function parsePitchGenres(obj, request){
    var cardContainer = document.getElementById('pitchGenres');
    var nrItems = obj.items.length;
    for (var i = 0; i < nrItems; i++) {
    	var item = document.createElement('a');
    	item.classList.add('dropdown-item');
    	item.id = 'PitchGenre' + obj.items[i].tag;
    	item.href = '#';
    	item.setAttribute("data-tag",obj.items[i].tag)
    	item.onclick = PitchGenreHandler(obj.items[i].tag);
    	item.innerHTML = obj.items[i].title;
    	cardContainer.appendChild(item);
    }
}

function pitchmenu(){
    var odata = ['bestalbums','bestreissue','rating8','sunday','besttracks'];
    var odesc = ['Best Albums','Best new Reissue','8.0+ reviews','Sunday reviews','Best new Tracks'];
    var nrItems = odata.length;
    var cardContainer = document.getElementById('pitchMenu');
    for (var i = 0; i < nrItems; i++) {
    	var item = document.createElement('a');
    	item.classList.add('dropdown-item');
    	item.id = 'cardPitchNav' + odata[i];
    	item.href = '#';
    	item.setAttribute('data-tag',odata[i]);
    	item.onclick = PitchHandler(odata[i]);
    	item.innerHTML = odesc[i];
    	cardContainer.appendChild(item);
    }
    sendAPI({"cmd": "API_PITCHFORK_CMD", "data": {"cmd": "genres"}}, parsePitchGenres);
}


function TidalPage(page) {
    modalLoader.show();
    sendAPI({"cmd": "API_TIDAL_PAGE", "data": {"page": page}}, parseTidal);
}


function parseTidalList(obj, request){
//var str = "Myplist|Myalbums|Myartist|Mytracks|Genres|Moods" //list
var str = "my|mymix|myplists|myalbums|myvideos|myartists|mytracks";
    var len = 0, total = 0;
    var item, card, img;

    document.getElementById('topTitle').innerHTML = '';

    if (request.data.group) var group  = request.data.group;

    if (str.indexOf(group)!==-1) {
	var div = document.getElementById('Tidalmy');
        div.classList.remove('hide');
	var cardContainer2 = document.getElementById('T'+group);
	cardContainer2.classList.remove('hide');
	cardContainer2.classList.add('active');
//	cardContainer2.getElementsByClassName.row[0].length>0

	var el = document.getElementById('T'+group+'-tab');
	el.classList.add('active');
/*	if (cardContainer2.getElementsByTagName('div').length > 0) {
	    modalLoader.hide();
	    return;
	}*/
    } else {
	var cardContainer2 = document.getElementById('Tidal'+group);
	cardContainer2.classList.remove('hide');
	if (obj.status)
	    return;
    }

    if (obj.items) { 
	len = obj.items.length;
	total = obj.totalNumberOfItems;
    } else {
	len = obj.rows[0].modules[0].pagedList.items.length;
	total = obj.rows[0].modules[0].pagedList.totalNumberOfItems;
    }

    if (!request.data.offset) {
	var cardContainer = document.createElement('div');
	cardContainer.setAttribute('id','Tidal'+group+'body');
	cardContainer2.appendChild(cardContainer);
	if (len > 0) { 
	    cardContainer.setAttribute('data-offset',len);
	    cardContainer.setAttribute('data-total',total);
	}
	var offset = 0;
    } else {
	var cardContainer = document.getElementById('Tidal'+group+'body');
	var offset = parseInt(cardContainer.getAttribute('data-offset'));
    }
    if (group == "myplists") {
	if (!request.data.offset) {
	    cardContainer.innerHTML = '';

    	    cardContainer.classList.add('row');
    	    if (phone) cardContainer.classList.add('phone');
    	}
        for (var i = 0; i < len; i++) {
	    item = obj.items[i].playlist;
	    card = document.createElement('div');
    	    card.classList.add('my-item');
    	    card.classList.add('grid-item');
    	    card.id = group + (i + offset);
    	    var img = item.squareImage;
    	    if (img == null)
    		var link = 'icons/disc.svg'
	    else {
    		img = img.replace(/-/g,'\/');
    		var link = 'https://resources.tidal.com/images/'+img+'/160x160.jpg';
    	    }

    	    var str = '<div class="card1">' +
                             ' <a class="clickable" data-type="playlist" data-id="'+item.uuid+'" data-name="' + item.title + '" onclick=\'appGoto("Tidal","page","playlist__'+ item.uuid+'");\'>'+
                             ' <div class="item-wrapper'+(phone ? ' ensemble':'')+'">'+
                             ' <img class="lozad" src="icons/disc.svg" data-src="'+link+'" width="100%" height="100%" data-loaded="false">';
            if (phone)
    		str += ' <div class="aplay">'+
                       '     <button class="btn material-icons shadow-none" type="button" role="button" onclick=\'Tidal("play","playlist","'+item.uuid+'",event);\' title="Play">play_arrow</button>' +
                       ' </div>'+
    		       '</div></a>'+
                       '<div class="card-tit">'+
                       ' <div>'+
                       '  <span class="item-title talb clickable" title="'+item.title+'">' + item.title + '</span>' +
                       ' </div>'+
                       ' <div class="title-button"><button class="btn material-icons shadow-none" onclick="showMenu2(this,event)">more_vert</button></div>' +
                       '</div>'+
                       '</div>'
            else
        	str += ' <div class="overlay">'+
                       '     <button class="btn material-icons shadow-none" type="button" role="button" onclick=\'Tidal("play","playlist","'+ item.uuid+'",event);\' title="Play">play_arrow</button>'+
                       '     <button class="btn material-icons shadow-none" type="button" role="button" onclick="showMenu2(this, event)" title="Show menu">more_vert</button>'+
                       ' </div>'+
    		       '</div></a>'+
                       '  <span class="item-title talb clickable" title="'+item.title+'" onclick=\'Tidal("play","playlist","'+item.uuid+'",event);\'>' + item.title + '</span>' +
                       '  <span class="item-title tart">' + item.numberOfTracks + ' tracks</span>' +
                       '</div>'; 
            card.innerHTML = str;
    	    cardContainer.appendChild(card);
        }
    }
    else if (group == "mymix") {
	if (obj.status) modalLoader.hide();
    	cardContainer.classList.add('row');
    	if (phone) cardContainer.classList.add('phone');

        for (var i = 0; i < len; i++) {
	    item = obj.rows[0].modules[0].pagedList.items[i];
	    card = document.createElement('div');
    	    card.classList.add('my-item');
    	    card.classList.add('grid-item');

	    var str = '<div class="card1">' +
                     ' <a class="clickable" data-type="mix" data-id="'+item.id+'" data-name="' + item.title + '" onclick=\'appGoto("Tidal","page","mix__'+ item.id+'");\'>'+
                     ' <div class="item-wrapper">';
                     
//            var len2 = item.graphic.images.length;
//            var j = 0;
//            while (j < len2 && j < 4) {
//    		var img = item.graphic.images[j].id;
//    		if (img == null)
//    		    var link = 'icons/disc.svg'
//		else {
//    		    img = img.replace(/-/g,'\/');
//    		    var link = 'https://resources.tidal.com/images/'+img+'/160x160.jpg';
//    		}
		var link = item.images.SMALL.url;
        	str += ' <img class="lozad" src="icons/disc.svg" data-src="'+link+'" data-loaded="false" width="100%" height="100%">';
//        	j = j + 1;
//    	    }
    	    if (phone)
    		str +=  ' <div class="aplay">'+
                        '     <button class="btn material-icons shadow-none" type="button" role="button" onclick=\'Tidal("play","mix","'+item.id+'",event);\' title="Play">play_arrow</button>' +
                        ' </div>'
            else
        	str += ' <div class="overlay">'+
                   '     <button class="btn material-icons shadow-none" type="button" role="button" onclick=\'Tidal("play","mix","'+ item.id+'",event);\' title="Play">play_arrow</button>'+
                   ' </div>';

            str += '</div></a>'+
                   '  <span class="item-title talb" title="'+item.title+'">' + item.title + '</span>' +
                   '  <span class="tart" title="'+item.subTitle+'">' + item.subTitle + '</span>' +
                   '</div>'; 
            card.innerHTML = str;
    	    cardContainer.appendChild(card);
        
	}
    }
    else if (group == "myalbums") {
	if (!request.data.offset) {
	    cardContainer.innerHTML = '';
    	    len = obj.items.length;
    	    cardContainer.classList.add('row');
    	    if (phone) cardContainer.classList.add('phone');
    	}
        for (var i = 0; i < len; i++) {
	    item = obj.items[i].item;
	    card = document.createElement('div');
    	    card.classList.add('my-item');
    	    card.classList.add('grid-item');
    	    card.id = group + (i + offset);
    	    var img = item.cover;
    	    if (img == null)
    		var link = 'icons/disc.svg'
	    else {
    		img = img.replace(/-/g,'\/');
    		var link = 'https://resources.tidal.com/images/'+img+'/160x160.jpg';
    	    }
	    var rdate = item.releaseDate;
	    if (rdate){
		rdate = rdate.split('-')[0];}
	    else {
		rdate = '';
	    }
	    var title = item.title + (rdate == '' ? '' : ' (' + rdate + ')');
	    var str = '<div class="card1">' +
                             (item.audioQuality == "HI_RES" ? ' <i class="hires material-icons">high_quality</i>' : '')+
                             ' <a class="clickable" data-type="album" data-id="'+item.id+'" data-name="' + item.title + '" onclick=\'appGoto("Tidal","page","album__'+item.id+'");\'>' +
                             ' <div class="item-wrapper">' +
                             ' <img class="lozad" src="icons/disc.svg" data-src="'+link+'" width="100%" height="100%" data-loaded="false">';
//                             ' <img class="lozad" src="icons/disc.svg" data-src="'+link+'" width="100%" height="100%">';

	    if (phone)
    		str +=  ' <div class="aplay">'+
                        '     <button class="btn material-icons shadow-none" type="button" role="button" onclick=\'Tidal("play","album","'+item.id+'",event);\' title="Play">play_arrow</button>' +
                        ' </div>'+
                        ' </div></a>'+
                        '<div class="card-tit">'+
                        ' <div>'+
                        '  <span class="item-title1 talb clickable" data-album="" onclick=\'appGoto("Tidal","page","album__'+item.id+'");\' title="'+title+'">' + title + '</span>' +
                        '  <span class="item-title tart clickable" onclick=\'appGoto("Tidal","page","artist__'+item.artists[0].id+'");\'>' + item.artists[0].name + '</span>'+
                        ' </div>'+
                        ' <div class="title-button"><button class="btn material-icons shadow-none" onclick="showMenu2(this,event)">more_vert</button></div>' +
                        '</div>'+
                        '</div>'
	    else
                str +=  ' <div class="overlay">' +
                        '     <button class="btn material-icons shadow-none" type="button" role="button" onclick=\'Tidal("play","album","'+item.id+'",event);\' title="Play">play_arrow</button>' +
                        '     <button class="btn material-icons shadow-none" type="button" role="button" onclick="showMenu2(this, event)" title="Show menu">more_vert</button>' +
                        ' </div></div></a>'+
                        '  <span class="item-title1 talb clickable" data-album="" onclick=\'appGoto("Tidal","page","album__'+item.id+'");\' title="'+title+'">' + title + '</span>' +
                        '  <span class="item-title tart clickable" onclick=\'appGoto("Tidal","page","artist__'+item.artists[0].id+'");\'>' + item.artists[0].name + '</span>' +
                        '</div>';
	    card.innerHTML = str;
    	    cardContainer.appendChild(card);
	}
    }
    else if (group == "myartists") {
	if (!request.data.offset) {
	    cardContainer.innerHTML = '';
    	    len = obj.items.length;
    	    cardContainer.classList.add('row');
    	    if (phone) cardContainer.classList.add('phone');
    	}
	for (var i = 0; i < len; i++) {
	    item = obj.items[i].item;
	    card = document.createElement('div');
    	    card.classList.add('my-item');
    	    card.classList.add('grid-item');
    	    card.id = group + (i + offset);
    	    img = item.picture;
    	    if (img == null)
    		var link = 'icons/disc.svg'
	    else {
    		img = img.replace(/-/g,'\/');
    		var link = 'https://resources.tidal.com/images/'+img+'/160x160.jpg';
    	    }
    	    var str = '<div class="card1">' +
                     ' <a class="clickable" data-type="artist" data-id="'+item.id+'" data-name="' + item.name + '" onclick=\'appGoto("Tidal","page","artist__' + item.id+'");\'>'+
                     ' <div class="'+(phone ? 'item-wrapper ensemble' : 'artist-wrapper')+'">'+
                     ' <img class="lozad" src="icons/disc.svg" data-src="'+link+'" width="100%" height="100%" data-loaded="false">';

    	    if (phone)
    	        str +=  ' </div></a>'+
                        '<div class="card-tit">'+
                        ' <div>'+
                        '  <span class="item-title talb clickable" onclick=\'appGoto("Tidal","page","artist__' + item.id+'")\' title="'+item.name+'">' + item.name + '</span>' +
                        ' </div>'+
                        ' <div class="title-button"><button class="btn material-icons shadow-none" onclick="showMenu2(this,event)">more_vert</button></div>' +
                        '</div>'+
                        '</div>'
	    else
                str +=  ' <div class="overlay">'+
                        '     <button class="btn material-icons clickable" type="button" role="button" onclick=\'Tidal("play","artist","'+item.id+'",event);\' title="Play Artist Radio">play_arrow</button>' +
                        '     <button class="btn material-icons clickable" type="button" role="button" onclick="showMenu2(this, event)" title="Show menu">more_vert</button>'+
                        ' </div></div></a>'+
                        '  <span class="item-title talb clickable textcenter" onclick=\'appGoto("Tidal","page","artist__' + item.id+'")\' title="'+item.name+'">' + item.name + '</span>' +
                        '</div>'; 
            card.innerHTML = str;
    	    cardContainer.appendChild(card);
	} //for j=
    }
    else if (group == "mytracks") {
	if (!request.data.offset) {
	    cardContainer.innerHTML = '';

    	    len = obj.items.length;
    	    var dv = document.createElement('div');
    	    dv.innerHTML = '<button type="button" class="btn btn-outline-light clickable" title="Play All" onclick=\'Tidal("play","mytracks","",event)\'>Play All</button>';
    	    dv.classList.add('group-header');
    	    cardContainer.appendChild(dv);

	    var tbl = document.createElement('ul');
    	    if (phone) tbl.classList.add('phone');

    	    var tr = document.createElement('li');
    	    tr.innerHTML = '<span class="track-cover"></span>'+
    	'<div class="track-title-mobile">'+
    	'<span class="track-title">Title</span><span class="track-artist">Artist</span>'+
    	'</div>'+
    	'<span class="track-album">Album</span><span class="track-duration">Time</span><span class="track-fav"></span><span class="track-action"></span>'
    	    tr.classList.add('tracklist-label');
    	    tbl.appendChild(tr);
    	} else {
    	    var tbl = cardContainer.getElementsByClassName('tracklist')[0];
    	}
	for (var i = 0; i < len; i++) {
	    item = obj.items[i].item;
	    var tr = document.createElement('li');
	    var img = item.album.cover;
    	    if (img == null) {
    		var link = 'icons/disc.svg';
    	    }
	    else {
    		img = img.replace(/-/g,'\/');
    		var link = 'https://resources.tidal.com/images/'+img+'/80x80.jpg';
    	    }

	    tr.innerHTML = '<span class="track-cover">'+
	    '<div class="imgmini2">'+
	    '<div class="item-wrapper">'+
	    '<a class="clickable" onclick=\'Tidal("play","track","'+item.id+'",event);return false;\'>'+
	    '<img class="lozad" src="icons/disc.svg" data-src="'+link+'" width="50px" height="50px" data-loaded="false">'+
	    '<div class="overlay">'+
            '     <button class="btn material-icons shadow-none" type="button" role="button" onclick=\'Tidal("play","track","'+item.id+'",event);\' title="Play">play_arrow</button>' +
            '</div>'+
	    '</a></div></div></span>' +
	    '<div class="track-title-mobile">'+
	    '<span class="track-title"><a class="clickable" onclick=\'Tidal("play","track","'+item.id+'",event); return false;\' title="'+item.title+'">' + item.title + '</a></span>' +
	    '<span class="track-artist"><a class="clickable" onclick=\'appGoto("Tidal","page","artist__' + item.artists[0].id + '");\' title="'+item.artists[0].name+'">' + item.artists[0].name + '</a></span>' +
	    '</div>'+
	    '<span class="track-album"><a class="clickable" onclick=\'appGoto("Tidal","page","album__' + item.album.id + '");\' title="'+item.album.title+'">' + item.album.title + '</a></span>' +
	    '<span class="track-duration">' + HHMMSS(item.duration) + '</span>'+
	    '<span class="track-fav"><a class="clickable material-icons" onclick=\'Tidal("add","track","' + item.id + '",event);\' title="Add to Queue">add</a></span>'+
	    '<span class="track-action"><a class="clickable material-icons" onclick="showMenu2(this.parentNode,event);" title="Show menu">more_vert</a></span>';
	    tr.classList.add('track-item');
	    tr.setAttribute('data-type','track');
	    tr.setAttribute('data-title',item.title);
	    tr.setAttribute('data-id',item.id);
    	    tr.id = group + (i + offset);
    	    tbl.appendChild(tr);
	}
	tbl.classList.add('tracklist');
    	cardContainer.appendChild(tbl);
    	setPlaying();

    }
    if (request.data.offset) {
    	offset = offset + len;
	cardContainer.setAttribute('data-offset',offset);
    }
    observer.observe();
    modalLoader.hide();
    scrollFlag = false;
}

function parseQobuzList(obj, request){
//var str = "Myplist|Myalbums|Myartist|Mytracks|Genres|Moods" //list
var ss = "myplists|myalbums|myartists|mytracks";
    var len = 0, offset = 0, total = 0;
    var item, card, img;

    if (request.data.group) var group  = request.data.group;

    document.getElementById('topTitle').innerHTML = '';

    if (ss.indexOf(group)!==-1) {
	var div = document.getElementById('Qobuzmy');
        div.classList.remove('hide');
	var cardContainer2 = document.getElementById('Q'+group);
	cardContainer2.classList.remove('hide');
	cardContainer2.classList.add('active');
//	cardContainer2.getElementsByClassName.row[0].length>0

	var el = document.getElementById('Q'+group+'-tab');
	el.classList.add('active');
/*	if (cardContainer2.getElementsByTagName('div').length > 0) {
	    modalLoader.hide();
	    return;
	}*/
    }
    else  {
	var cardContainer2 = document.getElementById('Qobuz'+group);
        cardContainer2.classList.remove('hide');
        if (obj.status)
    	    return;
    }



    if (group == "labels") {
	var cardContainer = document.createElement('div');
	cardContainer2.appendChild(cardContainer);
	
	if (cardContainer.getElementsByTagName('div').length == 0) {
	cardContainer.innerHTML = '';
	var nr = obj.labels.length;
        for (var i = 0; i < nr; i++) {
    	    var label = obj.labels[i];
	    var div0 = document.createElement('div');
	    var div = document.createElement('div');
	    div.innerHTML = "<h5>"+obj.labels[i].group+"</h5>";
	    div.classList.add('header');
    	    div0.appendChild(div);
	    var ul = document.createElement('ul');
    	    len = label.items.length;
    	    for (var j = 0; j < len; j++) {
		var li = document.createElement('li');
    		li.innerHTML = '<a class="clickable" onclick=\'appGoto("Qobuz","page","label__'+ label.items[j].id+'");\'>'+label.items[j].name+'</a>';
    		ul.appendChild(li);
    	    }
    	    div0.appendChild(ul);
    	    div0.style.cssText = 'display:inline-block;padding: 0 40px 0 0; float:left;';
    	    cardContainer.appendChild(div0);
        }
        }
//        cardContainer.classList.remove('hide');
    }

    if (group == "myplists") {
        len = obj.playlists.items.length;
        total = obj.playlists.total;
    } else
    if (group == "myalbums") {
        len = obj.albums.items.length;
        total = obj.albums.total;
    } else
    if (group == "myartists") {
        len = obj.artists.items.length;
        total = obj.artists.total;
    } else
    if (group == "mytracks") {
        len = obj.tracks.items.length;
        total = obj.tracks.total;
    }
    
    if (!request.data.offset) {
	var cardContainer = document.createElement('div');
	cardContainer.setAttribute('id','Qobuz'+group+'body');
	cardContainer2.appendChild(cardContainer);
	if (len > 0) { 
    	    cardContainer.setAttribute('data-offset',len);
    	    cardContainer.setAttribute('data-total',total);
	}
	var offset = 0;
    } else {
	var cardContainer = document.getElementById('Qobuz'+group+'body');
	var offset = parseInt(cardContainer.getAttribute('data-offset'));
    } 
    
    if (group == "myplists") {
//	if (cardContainer.getElementsByTagName('div').length == 0) {
	if (!request.data.offset) {
	    cardContainer.innerHTML = '';
    	    cardContainer.classList.add('row');
    	    if (phone) cardContainer.classList.add('phone');
	}
        for (var i = 0; i < len; i++) {
	    item = obj.playlists.items[i];
	    card = document.createElement('div');
    	    card.classList.add('my-item');
    	    card.classList.add('grid-item');
	    card.id = group + (i + offset);
	
            if (item.image_rectangle) {
    		var img = item.image_rectangle[0];
    	    }
    	    else
    		var img = item.images150[0];
    	    if (img == null) {
    		var link = 'icons/disc.svg';
    	    }
	    else
		var link = img;

    	    var str = '<div class="card1">' +
                             ' <a class="clickable" data-type="playlist" data-id="'+item.id+'" data-name="' + item.name + '" onclick=\'appGoto("Qobuz","page","playlist__'+ item.id+'");\'>'+
                             ' <div class="item-wrapper splaylist">'+
                             ' <img class="lozad" src="icons/disc.svg" data-src="'+link+'" width="100%" height="100%" data-loaded="false">';
            if (phone)
    		str +=  ' <div class="aplay">'+
                        '     <button class="btn material-icons shadow-none" type="button" role="button" onclick=\'Qobuz("play","playlist","'+item.id+'",event);\' title="Play">play_arrow</button>'+
                        ' </div>'+
        		'</div></a>'+
                        '<div class="card-tit">'+
                        ' <div>'+
                	'  <span class="item-title talb clickable" onclick=\'appGoto("Qobuz","page","playlist__'+ item.id+'");\' title="'+item.name+'">' + item.name + '</span>' +
                        ' </div>'+
                        ' <div class="title-button"><button class="btn material-icons shadow-none" onclick="showMenu2(this,event)">more_vert</button></div>' +
                        '</div>'+
                	'</div>'
            else
                str +=  ' <div class="overlay">'+
                        '     <button class="btn material-icons shadow-none" type="button" role="button" onclick=\'Qobuz("play","playlist","'+item.id+'",event);\' title="Play">play_arrow</button>'+
                        '     <button class="btn material-icons shadow-none" type="button" role="button" onclick="showMenu2(this, event)" title="Show menu">more_vert</button>'+
                        ' </div>'+
        		'</div></a>'+
                	'  <span class="item-title talb clickable" onclick=\'appGoto("Qobuz","page","playlist__'+ item.id+'");\' title="'+item.name+'">' + item.name + '</span>' +
                	'</div>'; 
            card.innerHTML = str;
    	    cardContainer.appendChild(card);
        }
//        }
    }
    else if (group == "myalbums") {
	if (!request.data.offset) {
	    cardContainer.innerHTML = '';
    	    cardContainer.classList.add('row');
    	    if (phone) cardContainer.classList.add('phone');
	}
//	if (cardContainer.getElementsByTagName('div').length == 0) {
        for (var i = 0; i < len; i++) {
	    item = obj.albums.items[i];
	    card = document.createElement('div');
    	    card.classList.add('my-item');
    	    card.classList.add('grid-item');
	    card.id = group + (i + offset);

    	    var img = item.image.small;
    	    if (img == null)
    		var link = 'icons/disc.svg'
	    else
    		var link = img;
	    var rdate = item.release_date_original;
	    rdate = rdate.split("-")[0];
	    var title = item.title + ' (' + rdate + ')';

    	    var str = '<div class="card1" id="cardMyalb' + item.id + '">' +
                             (item.audioQuality == "HI_RES" ? ' <i class="hires material-icons">high_quality</i>' : '')+
                             ' <a class="clickable"  data-type="album" data-id="'+item.id+'" data-name="' + item.title + '" onclick=\'appGoto("Qobuz","page","album__'+item.id+'");\'>' +
                             ' <div class="item-wrapper">' +
                             ' <img class="lozad" src="icons/disc.svg" data-src="'+link+'" width="100%" height="100%" data-loaded="false">';
            if (phone)
    		str +=  ' <div class="aplay">'+
                        '     <button class="btn material-icons shadow-none" type="button" role="button" onclick=\'Qobuz("play","album","'+item.id+'",event);\' title="Play">play_arrow</button>' +
                        ' </div>'+
        		'</div></a>'+
                        '<div class="card-tit">'+
                        ' <div>'+
            		'  <span class="item-title1 talb clickable" onclick=\'appGoto("Qobuz","page","album__'+item.id+'");\' title="'+title+'">' + title + '</span>' +
                	'  <span class="item-title tart clickable" onclick=\'appGoto("Qobuz","page","artist__'+item.artist.id+'");\'>' + item.artist.name + '</span>' +
                        ' </div>'+
                        ' <div class="title-button"><button class="btn material-icons shadow-none" onclick="showMenu2(this,event)">more_vert</button></div>' +
                        '</div>'+
                	'</div>'
	    else
                str +=  ' <div class="overlay">' +
                        '     <button class="btn material-icons shadow-none" type="button" role="button" onclick=\'Qobuz("play","album","'+item.id+'",event);\' title="Play">play_arrow</button>' +
                        '     <button class="btn material-icons shadow-none" type="button" role="button" onclick="showMenu2(this, event)" title="Show menu">more_vert</button>'+
                        ' </div>'+
        		'</div></a>'+
            		'  <span class="item-title1 talb clickable" onclick=\'appGoto("Qobuz","page","album__'+item.id+'");\' title="'+title+'">' + title + '</span>' +
                	'  <span class="item-title tart clickable" onclick=\'appGoto("Qobuz","page","artist__'+item.artist.id+'");\'>' + item.artist.name + '</span>' +
                	'</div>';
        
	    card.innerHTML = str;
    	    cardContainer.appendChild(card);
//        }
	}
    }
    else if (group == "myartists") {
//	if (cardContainer.getElementsByTagName('div').length == 0) {
	if (!request.data.offset) {
	    cardContainer.innerHTML = '';
    	    cardContainer.classList.add('row');
    	    if (phone) cardContainer.classList.add('phone');
    	}
	for (var i = 0; i < len; i++) {
	    item = obj.artists.items[i];
	    card = document.createElement('div');
    	    card.classList.add('my-item');
    	    card.classList.add('grid-item');
	    card.id = group + (i + offset);

    	    if (item.image == null)
    		var link = 'icons/disc.svg'
	    else
    		var link = item.image.medium;

    	    var str = '<div class="card1" id="cardMyArt' + item.id + '">' +
                      ' <a class="clickable" data-type="artist" data-id="'+item.id+'" data-name="' + item.name + '" onclick=\'appGoto("Qobuz","page","artist__' + item.id+'");\'>'+
                      ' <div class="'+(phone ? 'item-wrapper ensemble' : 'artist-wrapper')+'">'+
                      ' <img class="lozad" src="icons/disc.svg" data-src="'+link+'" width="100%" height="100%" data-loaded="false">';
            if (phone)
    		str +=  ' <div class="aplay">'+
                        '     <button class="btn material-icons shadow-none" type="button" role="button" onclick=\'Qobuz("play","album","'+item.id+'",event);\' title="Play">play_arrow</button>' +
                        ' </div>'+
        		'</div></a>'+
                        '<div class="card-tit">'+
                        ' <div>'+
                        '  <span class="item-title talb clickable" data-album="" onclick=\'appGoto("Qobuz","page","artist__' + item.id+'")\' title="'+item.name+'">' + item.name + '</span>' +
                        ' </div>'+
                        ' <div class="title-button"><button class="btn material-icons shadow-none" onclick="showMenu2(this,event)">more_vert</button></div>' +
                        '</div>'+
                	'</div>'
            else
                str += ' <div class="overlay">'+
                       '     <button class="btn material-icons shadow-none" type="button" role="button" onclick=\'Qobuz("play","artist","'+item.id+'",event);\' title="Play">play_arrow</button>' +
                       '     <button class="btn material-icons shadow-none" type="button" role="button" onclick="showMenu2(this, event)" title="Show menu">more_vert</button>'+
                       ' </div>'+
            	       '</div></a>'+
                       '  <span class="item-title talb clickable textcenter" data-album="" onclick=\'appGoto("Qobuz","page","artist__' + item.id+'")\' title="'+item.name+'">' + item.name + '</span>' +
                       '</div>'; 
            card.innerHTML = str;
    	    cardContainer.appendChild(card);
	} //for j=
//      }
    }
    else if (group == "mytracks") {
//	if (cardContainer.getElementsByTagName('div').length == 0) {
	if (!request.data.offset) {
	    cardContainer.innerHTML = '';
	    var tbl = document.createElement('ul');
    	    if (phone) tbl.classList.add('phone');

    	    var tr = document.createElement('li');
    	    tr.innerHTML = '<span class="track-cover"></span>'+
    	'<div class="track-title-mobile">'+
    	'<span class="track-title">Title</span><span class="track-artist">Artist</span>'+
    	'</div>'+
    	'<span class="track-album">Album</span><span class="track-duration">Time</span><span class="track-fav"></span><span class="track-action"></span>'
    	    tr.classList.add('tracklist-label');
    	    tbl.appendChild(tr);
    	} else {
    	    var tbl = cardContainer.getElementsByClassName('tracklist')[0]; 
    	}
	for (var i = 0; i < len; i++) {
	    item = obj.tracks.items[i];
	    var tr = document.createElement('li');
	    var img = item.album.image.thumbnail;
    	    if (img == null) {
    		var link = 'icons/disc.svg';
    	    }
	    else {
    		var link = img;
    	    }

	    tr.innerHTML = '<span class="track-cover">'+
	    '<div class="imgmini2">'+
	    '<div class="item-wrapper">'+
	    '<a class="clickable" onclick=\'Qobuz("play","track","'+item.id+'",event)\'>'+
	    '<img class="lozad" src="icons/disc.svg" data-src="'+link+'" width="50px" height="50px" data-loaded="false">'+
	    '<div class="overlay">'+
            '     <button class="btn material-icons shadow-none" type="button" role="button" onclick=\'Qobuz("play","track","'+item.id+'",event);\' title="Play">play_arrow</button>' +
	    '</div>'+
	    '</a></div></div></span>' +
	    '<div class="track-title-mobile">'+
	    '<span class="track-title"><a class="clickable" onclick=\'Qobuz("play","track","'+item.id+'",event);\' title="'+item.title+'">' + item.title + '</a></span>' +
	      (item.performer ? '<span class="track-artist"><a class="clicable" onclick=\'appGoto("Qobuz","page","artist__'+item.performer.id+'");\' title="'+item.performer.name+'">'+item.performer.name+'</a></span>':'<span class="track-artist"><a onclick=\'appGoto("Qobuz","page","artist__'+item.album.artist.id+'");\' title="'+item.album.artist.name+'">'+item.album.artist.name+'</a></span>')+
//	    '<span class="track-artist"><a class="clickable" onclick=\'appGoto("Qobuz","page","artist__' + item.performer.id + '");\' title="'+item.performer.name+'">' + item.performer.name + '</a></span>' +
	    '</div>'+
	    '<span class="track-album"><a class="clickable" onclick=\'appGoto("Qobuz","page","album__' + item.album.id + '");\' title="'+item.album.title+'">' + item.album.title + '</a></span>' +
	    '<span class="track-duration">' + HHMMSS(item.duration) + '</span>'+
	    '<span class="track-fav"><a class="clickable material-icons" onclick=\'Qobuz("add","track","'+item.id+'",event); return false;\' title="Add to Queue">add</a></span>'+
	    '<span class="track-action"><a class="clickable material-icons" onclick="showMenu2(this.parentNode,event);" title="Show menu">more_vert</a></span>';
	    tr.classList.add('track-item');
	    tr.setAttribute('data-type','track');
	    tr.setAttribute('data-id',item.id);
	    tr.setAttribute('data-title',item.title);
	    tr.id = group + (i + offset);
    	    tbl.appendChild(tr);
	}
	tbl.classList.add('tracklist');
    	cardContainer.appendChild(tbl);
    	setPlaying();
//      }
    }
    if (request.data.offset) {
    	offset = offset + len;
	cardContainer.setAttribute('data-offset',offset);
    }
    observer.observe();
    modalLoader.hide();
    scrollFlag = false;
}

function SearchMore(type,query){
    var el = document.getElementById("tfullsearchbtn");
    el.value = query;
    var el2 = document.getElementById("searchType");
    el2.value = type;
    modalSearch('hide');
    searchTidal(query,type);
    appGoto('Tidal','search');
}

function QSearchMore(type,query){
    var el = document.getElementById("qfullsearchbtn");
    el.value = query;
    var el2 = document.getElementById("qsearchType");
    el2.value = type;
    modalQSearch('hide');
    searchQobuz(query,type);
    appGoto('Qobuz','search');
}

function parseQobuzFullSearch(obj, request){
var img = '';
var clas,icon,favtit;

    var cardContainer = document.getElementById('qobuzFullSearch');
    var type = request.data.type;
    if (!request.data.offset) {
	while (cardContainer.firstChild) {
    	    cardContainer.removeChild(cardContainer.firstChild);
	};
    }
    document.getElementById('topTitle').innerHTML = 'Search: ' + request.data.query;

    if (type == 'all') {
	var arr = ['albums','playlists','artists','tracks'];
	var nav = document.createElement('nav');
	nav.classList.add('sticky');
	var str = '<div id="qstabs" class="nav nav-tabs" role="tablist">';
	var len = arr.length;
	var j = 0;
	for (var i = 0; i < len; i++) {
    	    if (obj[arr[i]].total>0) {
    	        str += '<a class="nav-item2 nav-link clickable' + (i==0 ? ' active':'') + '" id="nav-qs'+arr[i]+'-tab" data-toggle="tab" aria-controls="nav-qs'+arr[i]+'" aria-selected="'+(i==0 ? 'true':'false')+'" role="tab" onclick=\'tabshow("qstab-content",this)\'>' + capitalize(arr[i]) + '</a>';
    		j++;
    	    }
        }
        str+='</div>';
	nav.innerHTML = str;
	cardContainer.appendChild(nav);
	
	if (j > 0) {
	    var tabcontent = document.createElement('div');
	    tabcontent.id = 'qstab-content';
	    tabcontent.classList.add('tab-content');
	    cardContainer.appendChild(tabcontent);
	} else {
	    modalLoader.hide();
	}
    }

    if (type == 'albums' || type == 'all') {
    	if (obj.albums)
	    var len = obj.albums.items.length;
      if (len > 0) {
	if (!request.data.offset) {
	    if (type == 'albums') {
		var header = document.createElement('div');
		header.innerHTML = "<h5>Albums</h5>";
		header.classList.add('group-header');
		cardContainer.appendChild(header);
		var headcnt = document.createElement('div');
    		headcnt.classList.add('header-count');
    		headcnt.innerHTML = len + ' / ' + obj.albums.total;
		header.appendChild(headcnt);
	    } else {
		var div2 = document.createElement('div');
		div2.classList.add('tab-pane');
		div2.classList.add('active');
		div2.setAttribute('id','nav-qsalbums');
		div2.setAttribute('role','tabpanel');
		div2.setAttribute('aria-labelledby','nav-qsalbums-tab');
		tabcontent.appendChild(div2);
	    }
	    var div = document.createElement('div');
    	    div.classList.add('row');
	    cardContainer.setAttribute('data-offset',len);
	} else {
	    var div = cardContainer.getElementsByClassName('row')[0];
	    var offset = parseInt(cardContainer.getAttribute('data-offset'));

	    var headcnt = cardContainer.getElementsByClassName('header-count')[0];
	    headcnt.innerHTML = offset+' / '+obj.albums.total;
	    offset = offset + len;

	    cardContainer.setAttribute('data-offset',offset);
	}
	for (var i = 0; i < len; i++) {
    	    if (obj.albums)
		var item = obj.albums.items[i]
	    else
		var item = obj.items[i];
	    img = item.image.small;
    	    if (img == null) {
    		var link = 'icons/disc.svg';
    	    }
	    else {
    		var link = img;
    	    }
    	    var rdate = item.release_date_original;
	    rdate = rdate.split("-")[0];
	    var title = item.title +' (' + rdate +')';
	    var card = document.createElement('div');
    	    card.classList.add('grid-item');
	    icon = 'favorite_border';
    	    var str = '<div class="card1">' +
                             (item.hires ? ' <i class="hires material-icons">high_quality</i>' : '')+
                             ' <a class="clickable" onclick=\'appGoto("Qobuz","page","album__'+item.id+'");\' data-id="'+item.id+'" data-name="'+item.title+'">' +
                             '<div class="item-wrapper">' +
                             ' <img class="lozad" src="icons/disc.svg" data-src="'+link+'" width="100%" height="100%" data-loaded="false">';
            if (phone)
    		str +=  ' <div class="aplay">'+
                        '     <button class="btn material-icons shadow-none" type="button" role="button" onclick=\'Qobuz("play","album","'+item.id+'",event);\' title="Play">play_arrow</button>' +
                        ' </div>'+
        		'</div></a>'+
                        '<div class="card-tit">'+
                        ' <div>'+
            		'  <span class="item-title1 talb clickable" onclick=\'appGoto("Qobuz","page","album__'+item.id+'");\' title="'+title+'">' + title + '</span>' +
                	'  <span class="item-title tart clickable" onclick=\'appGoto("Qobuz","page","artist__'+item.artist.id+'");\'>' + item.artist.name + '</span>' +
                        ' </div>'+
                        ' <div class="title-button"><button class="btn material-icons shadow-none" onclick="showMenu2(this,event)">more_vert</button></div>' +
                        '</div>'+
                	'</div>'
            else
                str +=  ' <div class="overlay">' +
                        '     <button class="btn favbtn material-icons shadow-none" type="button" role="button" onclick=\'Qobuzfav("album","'+item.id+'",event,this);\' title="">'+icon+ '</button>'+
                        '     <button class="btn material-icons shadow-none" type="button" role="button" onclick=\'Qobuz("play","album","'+item.id+'",event);\' title="Play">play_arrow</button>' +
                        '     <button class="btn material-icons shadow-none" type="button" role="button" onclick="showMenu2(this, event)" title="Show menu">more_vert</button>'+
                        ' </div>'+
        		'</div></a>'+
                	'  <span class="item-title talb clickable" onclick=\'appGoto("Qobuz","page","album__'+item.id+'");\' title="'+title+'">' +title+ '</span>' +
                	'  <span class="item-title tart clickable" onclick=\'appGoto("Qobuz","page","artist__'+item.artist.id+'");\' title="'+item.artist.name+'">' + item.artist.name + '</span>' +
                	'</div>';
	    card.innerHTML = str;
	    div.appendChild(card);
    	}
        if (!request.data.offset)
          if (type == 'albums') {
	    cardContainer.appendChild(div);
	  } else 
	    div2.appendChild(div);
      }
    }
    if (type == 'artists' || type == 'all') {
      if (obj.artists)
	var len = obj.artists.items.length;
      if (len>0){
	if (!request.data.offset) {
	    if (type == 'artists') {
		var header = document.createElement('div');
		header.innerHTML = "<h5>Artists</h5>";
		header.classList.add('group-header');
		cardContainer.appendChild(header);

		var div = document.createElement('div');
    		div.classList.add('header-count');
    		div.innerHTML = len + ' / ' + obj.artists.total;
		header.appendChild(div);
	    } else {
		var div2 = document.createElement('div');
		div2.classList.add('tab-pane');
		div2.setAttribute('id','nav-qsartists');
		div2.setAttribute('role','tabpanel');
		div2.setAttribute('aria-labelledby','nav-qsartists-tab');
		tabcontent.appendChild(div2);
	    }
	    var div = document.createElement('div');
    	    div.classList.add('row');
	} else {
	    var div = cardContainer.getElementsByClassName('row')[0];
	    var offset = parseInt(cardContainer.getAttribute('data-offset'));

	    var headcnt = cardContainer.getElementsByClassName('header-count')[0];
	    headcnt.innerHTML = offset+' / '+obj.albums.total;

	    offset = offset + len;
	    cardContainer.setAttribute('data-offset',offset);
	}
	for (var i = 0; i < len; i++) {
	    if (obj.artists)
		var item = obj.artists.items[i]
	    else
		var item = obj.items[i];
	    img = item.picture;
    	    if (img == null) {
    		var link = 'icons/disc.svg';
    	    }
	    else {
    		var link = img;
    	    }
	    var card = document.createElement('div');
    	    card.classList.add('my-item');
    	    card.classList.add('grid-item');
	    icon = 'favorite_border';

    	    var str = '<div class="card1">' +
                             ' <a class="clickable" onclick=\'appGoto("Qobuz","page","artist__' + item.id+'");\' data-id="'+item.id+'" data-name="'+item.title+'">'+
                             ' <div class="artist-wrapper">'+
                             ' <img class="lozad" src="icons/disc.svg" data-src="'+link+'" width="100%" height="100%" data-loaded="false">';
            if (!phone)
                str += ' <div class="overlay">'+
                       '     <button class="btn material-icons clickable" type="button" role="button" onclick=\'Qobuz("play","artist","'+item.id+'",event);\'>play_arrow</button>'+
                       '     <button class="btn favbtn material-icons clickable" type="button" role="button" onclick=\'Qobuzfav("artist","'+item.id+'",event,this);\' title="">'+icon+'</button>'+
                       ' </div>';
            str += '</div></a>'+
                   '  <span class="item-title talb textcenter clickable" onclick=\'appGoto("Qobuz","page","artist__' + item.id+'")\' title="'+item.name+'">' + item.name + '</span>' +
                   '</div>'; 
	    card.innerHTML = str;
    	    div.appendChild(card);
	}
//        if (type == 'artists' && !request.data.offset)
        if (!request.data.offset)
          if (type == 'artists') {
	    cardContainer.appendChild(div);
	  } else
	    div2.appendChild(div);
      }
    }
    if (type == 'playlists' || type == 'all') {
    	if (obj.playlists)
	    var len = obj.playlists.items.length;
      if (len > 0) {
	if (!request.data.offset) {
	    if (type == 'playlists') {
		var header = document.createElement('div');
		header.innerHTML = "<h5>Playlists</h5>";
		header.classList.add('group-header');
		cardContainer.appendChild(header);
		var div = document.createElement('div');
    		div.classList.add('header-count');
    		div.innerHTML = len + ' / ' + obj.playlists.total;
		header.appendChild(div);
	    } else {
		var div2 = document.createElement('div');
		div2.classList.add('tab-pane');
		div2.setAttribute('id','nav-qsplaylists');
		div2.setAttribute('role','tabpanel');
		div2.setAttribute('aria-labelledby','nav-qsplaylists-tab');
		tabcontent.appendChild(div2);
	    }

	    var div = document.createElement('div');
	    div.classList.add('row');
	} else {
	    div = cardContainer.getElementsByClassName('row')[0];
	    var offset = parseInt(cardContainer.getAttribute('data-offset'));

	    var headcnt = cardContainer.getElementsByClassName('header-count')[0];
	    headcnt.innerHTML = offset+' / '+obj.albums.total;

	    offset = offset + len;
	    cardContainer.setAttribute('data-offset',offset);
	}
	for (var i = 0; i < len; i++) {
	    if (obj.playlists)
		var item = obj.playlists.items[i]
	    else
		var item = obj.items[i];
    	    img = item.images300[0];
    	    if (img == null) {
    		var link = 'icons/disc.svg';
    	    } else {
    		var link = img;
    	    }
	    var card = document.createElement('div');
    	    card.classList.add('my-item');
    	    card.classList.add('grid-item');
	    icon = 'favorite_border';
    	    var str = '<div class="card1">' +
                             ' <a class="clickable" onclick=\'appGoto("Qobuz","page","playlist__'+item.id+'");\' data-id="'+item.id+'" data-name="'+item.name+'">'+
                             ' <div class="item-wrapper">'+
                             ' <img class="lozad" src="icons/disc.svg" data-src="'+link+'" width="100%" height="100%" data-loaded="false">';
            if (phone)
    		str +=  ' <div class="aplay">'+
                        '     <button class="btn material-icons clickable" type="button" role="button" onclick=\'Qobuz("play","playlist","'+item.id+'",event);\' title="Play">play_arrow</button>'+
                        ' </div>'
            else
                str += ' <div class="overlay">'+
                      '     <button class="btn favbtn material-icons clickable" type="button" role="button" onclick=\'Qobuzfav("playlist","'+item.uuid+'",event,this);\' title="">'+icon+'</button>'+
                      '     <button class="btn material-icons clickable" type="button" role="button" onclick=\'Qobuz("play","playlist","'+item.id+'",event);\' title="Play">play_arrow</button>'+
                      '     <button class="btn material-icons clickable" type="button" role="button" onclick="showMenu2(this, event)" title="Show menu">more_vert</button>'+
                      ' </div>';
    	    str += '</div></a>'+
                   ' <span class="item-title talb clickable" onclick=\'appGoto("Qobuz","page","playlist__'+item.id+'");\' title="'+item.name+'">' + item.name + '</span>' +
                   '</div>'; 
	    card.innerHTML = str;
	    div.appendChild(card);
	}
        if (!request.data.offset)
    	    if (type == 'playlists') {
	      cardContainer.appendChild(div);
	    } else
	      div2.appendChild(div);
      }
    }
    if (type == 'tracks' || type == 'all') {
      if (obj.tracks)
	var len = obj.tracks.items.length;
      if (len > 0) {
	if (!request.data.offset) {
    	    if (type == 'tracks') {
		var header = document.createElement('div');
		header.innerHTML = "<h5>Tracks</h5>";
		header.classList.add('group-header');
		cardContainer.appendChild(header);

		var div = document.createElement('div');
    		div.classList.add('header-count');
    		div.innerHTML = len + ' / ' + obj.tracks.total;
		header.appendChild(div);
	    } else {
		var div2 = document.createElement('div');
		div2.classList.add('tab-pane');
		div2.setAttribute('id','nav-qstracks');
		div2.setAttribute('role','tabpanel');
		div2.setAttribute('aria-labelledby','nav-qstracks-tab');
		tabcontent.appendChild(div2);
	    }

	    var tbl = document.createElement('ul');
	  
    	    var tr = document.createElement('li');
    	    tr.innerHTML = '<span class="track-cover"></span>'+
    	    '<div class="track-title-mobile">'+
    	    '<span class="track-title">Title</span><span class="track-artist">Artist</span>'+
    	    '</div>'+
    	    '<span class="track-album">Album</span><span class="track-duration">Time</span><span class="track-fav"></span><span class="track-action"></span>'
    	    tr.classList.add('tracklist-label');
    	    tbl.appendChild(tr);
    	} else {
    	    tbl = cardContainer.getElementsByClassName('tracklist')[0];
	    var offset = parseInt(cardContainer.getAttribute('data-offset'));

	    var headcnt = cardContainer.getElementsByClassName('header-count')[0];
	    headcnt.innerHTML = offset+' / '+obj.albums.total;

	    offset = offset + len;
	    cardContainer.setAttribute('data-offset',offset);
    	}
	for (var i = 0; i < len; i++) {
	    if (obj.tracks)
		var item = obj.tracks.items[i]
	    img = item.album.image.small;
	    if (img == null) {
		var link = 'icons/disc.svg';
	    } else {
    		var link = img;;
    	    }
	    var tr = document.createElement('li');
	    tr.innerHTML = '<span class="track-cover">'+
	    '<div class="imgmini2">'+
	    '<div class="item-wrapper">'+
	    '<a class="clickable" onclick=\'Qobuz("play","track","'+item.id+'",event);\' title="Play">'+
	    '<img class="lozad" src="icons/disc.svg" data-src="'+link+'" width="50px" height="50px" data-loaded="false">'+
	    '<div class="overlay">'+
                '<button class="btn material-icons shadow-none" type="button" role="button">play_arrow</button>'+
	    '</div>'+
	    '</a></div></div></span>'+
    	    '<div class="track-title-mobile">'+
	      '<span class="track-title"><a onclick=\'Qobuz("play","track","'+item.id+'",event);\' title="'+item.title+'">'+item.title+'</a></span>'+
	      (item.performer ? '<span class="track-artist"><a onclick=\'appGoto("Qobuz","page","artist__'+item.performer.id+'");\' title="'+item.performer.name+'">'+item.performer.name+'</a></span>':'<span class="track-artist"><a onclick=\'appGoto("Qobuz","page","artist__'+item.album.artist.id+'");\' title="'+item.album.artist.name+'">'+item.album.artist.name+'</a></span>')+
	    '</div>'+
	    '<span class="track-album"><a onclick=\'appGoto("Qobuz","page","album__'+item.album.id+'");\' title="'+item.album.title+'">'+item.album.title+'</a></span>'+
	    '<span class="track-duration">'+HHMMSS(item.duration)+'</span>'+
	    '<span class="track-fav"><a class="material-icons" onclick=\'Qobuz("add","track","'+item.id+'",event); return false;\' title="Add to Queue">add</a></span>'+
	    '<span class="track-action"><a class="material-icons" onclick="showMenu2(this.parentNode,event);" title="Show menu">more_vert</a></span>';
	    tr.classList.add('track-item');
	    tr.setAttribute('data-type','track');
	    tr.setAttribute('data-id',item.id);
	    tr.setAttribute('data-title',item.title);
    	    tbl.appendChild(tr);
    	    
    	}
    	tbl.classList.add('tracklist');
        if (!request.data.offset)
          if (type == 'tracks') {
    	    cardContainer.appendChild(tbl);
    	  } else
    	    div2.appendChild(tbl);
      }
    }
    observer.observe();
    modalLoader.hide();
    scrollFlag = false;
}

function parseTidalFullSearch(obj, request){
var img = '';
var a = 0, b = 0, c = 0, d = 0;
var clas,icon,favtit;
    if (obj.status) {
	if (obj.status == 401) {
            showNotification('Tidal error', obj.userMessage, obj.userMessage, 'danger');
	}
    }
    var cardContainer = document.getElementById('tidalFullSearch');
    var type = request.data.type;
    document.getElementById('topTitle').innerHTML = 'Search: '+request.data.query;

//    if (type != "all" && !request.data.offset) {
    if (!request.data.offset) {
	while (cardContainer.firstChild) {
    	    cardContainer.removeChild(cardContainer.firstChild);
	};
    }
    if (type == 'all') {
	var arr = ['albums','playlists','artists','tracks'];
	var nav = document.createElement('nav');
	nav.classList.add('sticky');
	var str = '<div id="tstabs" class="nav nav-tabs" role="tablist">';
	var len = arr.length;
	var j = 0;
	for (var i = 0; i < len; i++) {
    	    if (obj[arr[i]].totalNumberOfItems>0) {
    	        str += '<a class="nav-item2 nav-link clickable' + (i==0 ? ' active':'') + '" id="nav-ts'+arr[i]+'-tab" data-toggle="tab" aria-controls="nav-ts'+arr[i]+'" aria-selected="'+(i==0 ? 'true':'false')+'" role="tab" onclick=\'tabshow("tstab-content",this)\'>' + capitalize(arr[i]) + '</a>';
    		j++;
    	    }
        }
        str+='</div>';
	nav.innerHTML = str;
	cardContainer.appendChild(nav);
	
	if (j > 0) {
	    var tabcontent = document.createElement('div');
	    tabcontent.id = 'tstab-content';
	    tabcontent.classList.add('tab-content');
	    cardContainer.appendChild(tabcontent);
	} else {
	    modalLoader.hide();
	}
    }
    if (type == 'albums' || type == 'all') {
    	if (obj.albums)
	    var len = obj.albums.items.length
	else
	    var len = obj.items.length;
      if (len > 0) {
	if (!request.data.offset) {
	    if (type == 'albums') {
		var header = document.createElement('div');
	        header.innerHTML = "<h5>Albums</h5>";
		header.classList.add('group-header');
		cardContainer.appendChild(header);

		var headcnt = document.createElement('div');
    		headcnt.classList.add('header-count');
    		headcnt.innerHTML = len + ' / ' + obj.totalNumberOfItems;
		header.appendChild(headcnt);
		cardContainer.setAttribute('data-offset',len);
	    } else {
		var div2 = document.createElement('div');
		div2.classList.add('tab-pane');
		div2.classList.add('active');
		div2.setAttribute('id','nav-tsalbums');
		div2.setAttribute('role','tabpanel');
		div2.setAttribute('aria-labelledby','nav-tsalbums-tab');
		tabcontent.appendChild(div2);
	    }
	    
	    var div = document.createElement('div');
    	    div.classList.add('row');
    	    if (phone) div.classList.add('phone');
	
	} else {
	    var div = cardContainer.getElementsByClassName('row')[0];
	    var offset = parseInt(cardContainer.getAttribute('data-offset'));

	    var headcnt = cardContainer.getElementsByClassName('header-count')[0];
	    headcnt.innerHTML = offset + ' / ' + obj.totalNumberOfItems;

	    offset = offset + len;
	    cardContainer.setAttribute('data-offset',offset);
	}
	for (var i = 0; i < len; i++) {
    	    if (obj.albums)
		var item = obj.albums.items[i]
	    else
		var item = obj.items[i];
	    img = item.cover;
    	    if (img == null) {
    		var link = 'icons/disc.svg';
    	    }
	    else {
    		img = img.replace(/-/g,'\/');
    		var link = 'https://resources.tidal.com/images/'+img+'/160x160.jpg';
    	    }
	    var card = document.createElement('div');
	    var rdate = item.releaseDate;
	    rdate = rdate.split("-")[0];
	    var title = item.title +' (' + rdate +')';

    	    card.classList.add('grid-item');
	    icon = 'favorite_border';
    	    var str = '<div class="card1">' +
                             (item.audioQuality == "HI_RES" ? ' <i class="hires material-icons">high_quality</i>' : '')+
                             ' <a class="clickable" onclick=\'appGoto("Tidal","page","album__'+item.id+'");\'>' +
                             '<div class="item-wrapper">' +
                             ' <img class="lozad" src="icons/disc.svg" data-src="'+link+'" width="100%" height="100%" data-loaded="false">';
            if (phone)
    		str +=  ' <div class="aplay">'+
                        '     <button class="btn material-icons shadow-none" type="button" role="button" onclick=\'Tidal("play","album","'+item.id+'",event);\' title="Play">play_arrow</button>' +
                        ' </div>'+
        		'</div></a>'+
                        '<div class="card-tit">'+
                        ' <div>'+
                	'  <span class="item-title talb clickable" onclick=\'appGoto("Tidal","page","album__'+item.id+'");\' title="'+title+'">' + title +'</span>' +
                	'  <span class="item-title tart clickable" onclick=\'appGoto("Tidal","page","artist__'+item.artists[0].id+'");\' title="'+item.artists[0].name+'">' + item.artists[0].name + '</span>' +
                        ' </div>'+
                        ' <div class="title-button"><button class="btn material-icons shadow-none" onclick="showMenu2(this,event)">more_vert</button></div>' +
                        '</div>'+
                	'</div>'
            else
                str +=  ' <div class="overlay">' +
                        '     <button class="btn favbtn material-icons shadow-none" type="button" role="button" onclick=\'Tidalfav("album","'+item.id+'",event,this);\' title="">'+icon+'</button>'+
                        '     <button class="btn material-icons shadow-none" type="button" role="button" onclick=\'Tidal("play","album","'+item.id+'",event);\' title="Play">play_arrow</button>' +
                        '     <button class="btn material-icons shadow-none" type="button" role="button" onclick="showMenu2(this,event);" title="Show menu">more_vert</button>' +
                        ' </div>'+
        		'</div></a>'+
                	'  <span class="item-title talb clickable" onclick=\'appGoto("Tidal","page","album__'+item.id+'");\' title="'+title+'">' + title +'</span>' +
                	'  <span class="item-title tart clickable" onclick=\'appGoto("Tidal","page","artist__'+item.artists[0].id+'");\' title="'+item.artists[0].name+'">' + item.artists[0].name + '</span>' +
                	'</div>';
	    card.innerHTML = str;
	    div.appendChild(card);
    	}
        if (!request.data.offset) {
    	    if (type == 'albums') {
		cardContainer.appendChild(div);
	    } else
		div2.appendChild(div);
	}
      }
    }
    if (type == 'artists' || type == 'all') {
    	if (obj.artists)
	    var len = obj.artists.items.length
	else
	    var len = obj.items.length;
      if (len>0){
	if (!request.data.offset) {
	    if (type == 'artists') {
		var header = document.createElement('div');
		header.innerHTML = "<h5>Artists</h5>";
		header.classList.add('group-header');
		cardContainer.appendChild(header);

		var headcnt = document.createElement('div');
    		headcnt.classList.add('header-count');
    		headcnt.innerHTML = len + ' / ' + obj.totalNumberOfItems;
		header.appendChild(headcnt);
	    } else {
		var div2 = document.createElement('div');
		div2.classList.add('tab-pane');
//		if (i == 0) div2.classList.add('active');
		div2.setAttribute('id','nav-tsartists');
		div2.setAttribute('role','tabpanel');
		div2.setAttribute('aria-labelledby','nav-tsartists-tab');
		tabcontent.appendChild(div2);
	    }
	    
	    var div = document.createElement('div');
    	    div.classList.add('row');
    	    if (phone) div.classList.add('phone');
	    cardContainer.setAttribute('data-offset',len);
	} else {
	    var offset = parseInt(cardContainer.getAttribute('data-offset'));

	    var headcnt = cardContainer.getElementsByClassName('header-count')[0];
	    headcnt.innerHTML = offset + ' / ' + obj.totalNumberOfItems;

	    offset = offset + len;
	    cardContainer.setAttribute('data-offset',offset);
	    var div = cardContainer.getElementsByClassName('row')[0];
	}
	for (var i = 0; i < len; i++) {
	    if (obj.artists)
		var item = obj.artists.items[i]
	    else
		var item = obj.items[i];
	    img = item.picture;
    	    if (img == null) {
    		var link = 'icons/disc.svg';
    	    }
	    else {
    		img = img.replace(/-/g,'\/');
    		var link = 'https://resources.tidal.com/images/'+img+'/160x160.jpg';
    	    }
	    var card = document.createElement('div');
    	    card.classList.add('my-item');
    	    card.classList.add('grid-item');
	    icon = 'favorite_border';

    	    var str = '<div class="card1">' +
            ' <a class="clickable" onclick=\'appGoto("Tidal","page","artist__' + item.id+'");\'>'+
            ' <div class="'+ (phone ? 'item-wrapper ensemble':'artist-wrapper')+'">'+
            ' <img class="lozad" src="icons/disc.svg" data-src="'+link+'" width="100%" height="100%" data-loaded="false">';
            if (!phone)
                str += ' <div class="overlay">'+
                       '     <button class="btn favbtn material-icons shadow-none" type="button" role="button" onclick=\'Tidalfav("artist","'+item.id+'",event,this);\' title="">'+icon+'</button>'+
                       ' </div>';
            str += '</div></a>'+
                     '  <span class="item-title talb textcenter clickable" onclick=\'appGoto("Tidal","page","artist__' + item.id+'")\' title="'+item.name+'">' + item.name + '</span>' +
                     '</div>'; 
	    card.innerHTML = str;
    	    div.appendChild(card);
	}
        if (!request.data.offset)
    	    if (type == 'artists') {
	      cardContainer.appendChild(div);
	    } else
	      div2.appendChild(div);
      }
    }
    if (type == 'playlists' || type == 'all') {
    	if (obj.playlists)
	    var len = obj.playlists.items.length
	else
	    var len = obj.items.length;
      if (len > 0) {
	  if (!request.data.offset) {
	    if (type == 'playlists') {
		var header = document.createElement('div');
		header.innerHTML = "<h5>Playlists</h5>";
		header.classList.add('group-header');
		cardContainer.appendChild(header);

		var headcnt = document.createElement('div');
    		headcnt.classList.add('header-count');
    		headcnt.innerHTML = len + ' / ' + obj.totalNumberOfItems;
		header.appendChild(headcnt);
	    } else {
		var div2 = document.createElement('div');
		div2.classList.add('tab-pane');
//		if (i == 0) div2.classList.add('active');
		div2.setAttribute('id','nav-tsplaylists');
		div2.setAttribute('role','tabpanel');
		div2.setAttribute('aria-labelledby','nav-tsplaylists-tab');
		tabcontent.appendChild(div2);
	    }
	    var div = document.createElement('div');
    	    div.classList.add('row');
    	    if (phone) div.classList.add('phone');
	    cardContainer.setAttribute('data-offset',len);
	  } else {
	    div = cardContainer.getElementsByClassName('row')[0];
	    var offset = parseInt(cardContainer.getAttribute('data-offset'));

	    var headcnt = cardContainer.getElementsByClassName('header-count')[0];
	    headcnt.innerHTML = offset+' / ' + obj.totalNumberOfItems;

	    offset = offset + len;
	    cardContainer.setAttribute('data-offset',offset);
	  }
//    	}
	for (var i = 0; i < len; i++) {
	    if (obj.playlists)
		var item = obj.playlists.items[i]
	    else
		var item = obj.items[i];
    	    img = item.squareImage;
    	    if (img == null) {
    		var link = 'icons/disc.svg';
    	    } else {
    		img = img.replace(/-/g,'\/');
    		var link = 'https://resources.tidal.com/images/'+img+'/160x160.jpg';
    	    }
	    var card = document.createElement('div');
    	    card.classList.add('my-item');
    	    card.classList.add('grid-item');
	    icon = 'favorite_border';
    	    str = '<div class="card1">' +
                             ' <a class="clickable" onclick=\'appGoto("Tidal","page","playlist__'+item.uuid+'");\'>'+
                             ' <div class="item-wrapper'+(phone ? ' ensemble':'')+'">'+
                             ' <img class="lozad" src="icons/disc.svg" data-src="'+link+'" width="100%" height="100%" data-loaded="false">';
            if (phone)
    		str +=  ' <div class="aplay">'+
                        '     <button class="btn material-icons shadow-none" type="button" role="button" onclick=\'Tidal("play","playlist","'+item.uuid+'",event);\' title="Play">play_arrow</button>'+
                        ' </div>'
            else
                str +=  ' <div class="overlay">'+
                        '     <button class="btn favbtn material-icons shadow-none" type="button" role="button" onclick=\'Tidalfav("playlist","'+item.uuid+'",event,this);\' title="">'+icon+'</button>'+
                        '     <button class="btn material-icons shadow-none" type="button" role="button" onclick=\'Tidal("play","playlist","'+item.uuid+'",event);\' title="Play">play_arrow</button>'+
                        '     <button class="btn material-icons shadow-none" type="button" role="button" onclick="showMenu2(this,event);" title="Show menu">more_vert</button>'+
                        ' </div>';
            str += '</div></a>'+
                   ' <span class="item-title talb clickable" onclick=\'appGoto("Tidal","page","playlist__'+item.uuid+'");\' title="'+item.title+'">' + item.title + '</span>' +
                   '</div>'; 
            card.innerHTML = str;
	    div.appendChild(card);
	}
//        if (type == "playlists" && !request.data.offset)
	  if (!request.data.offset)
    	    if (type == 'playlists') {
	      cardContainer.appendChild(div);
	    } else 
	      div2.appendChild(div);
      }
    }
    if (type == 'tracks' || type == 'all') {
	if (obj.tracks) 
	    var len = obj.tracks.items.length
	else
	    var len = obj.items.length;
      if (len > 0) {
	if(!request.data.offset) {
	    if (type == 'tracks') {
		var header = document.createElement('div');
		header.innerHTML = "<h5>Tracks</h5>";
		header.classList.add('group-header');
		cardContainer.appendChild(header);

		var headcnt = document.createElement('div');
    		headcnt.classList.add('header-count');
    		headcnt.innerHTML = len + ' / ' + obj.totalNumberOfItems;
		header.appendChild(headcnt);
	    } else {
		var div2 = document.createElement('div');
		div2.classList.add('tab-pane');
//		if (i == 0) div2.classList.add('active');
		div2.setAttribute('id','nav-tstracks');
		div2.setAttribute('role','tabpanel');
		div2.setAttribute('aria-labelledby','nav-tstracks-tab');
		tabcontent.appendChild(div2);
	    }

	    var tbl = document.createElement('ul');
	  
    	    var tr = document.createElement('li');
    	    tr.innerHTML = '<span class="track-cover"></span>'+
    	    '<div class="track-title-mobile">'+
		'<span class="track-title">Title</span><span class="track-artist">Artist</span>'+
	    '</div>'+
	    '<span class="track-album">Album</span><span class="track-duration">Time</span><span class="track-fav"></span><span class="track-action"></span>'
    	    tr.classList.add('tracklist-label');
    	    tbl.appendChild(tr);
	    cardContainer.setAttribute('data-offset',len);
    	} else {
    	    tbl = cardContainer.getElementsByClassName('tracklist')[0];
	    var offset = parseInt(cardContainer.getAttribute('data-offset'));

	    var headcnt = cardContainer.getElementsByClassName('header-count')[0];
	    headcnt.innerHTML = offset+' / ' + obj.totalNumberOfItems;

	    offset = offset + len;
	    cardContainer.setAttribute('data-offset',offset);
    	}
	for (var i = 0; i < len; i++) {
	    if (obj.tracks)
		var item = obj.tracks.items[i]
	    else
		var item = obj.items[i];
	    img = item.album.cover;
	    if (img == null) {
		var link = 'icons/disc.svg';
	    } else {
    		img = img.replace(/-/g,'\/');
    		var link = 'https://resources.tidal.com/images/'+img+'/80x80.jpg';
    	    }
	    var tr = document.createElement('li');
	    tr.classList.add('track-item');
	    tr.setAttribute('data-type','track');
	    tr.setAttribute('data-title',item.title);
	    tr.setAttribute('data-id',item.id);
	    tr.innerHTML = '<span class="track-cover">'+
	    '<div class="imgmini2">'+
	    '<div class="item-wrapper">'+
	    '<a class="clickable" onclick=\'Tidal("play","track","'+item.id+'",event);return false;\' title="Play">'+
	    '<img class="lozad" src="icons/disc.svg" data-src="'+link+'" width="50px" height="50px" data-loaded="false">'+
	    '<div class="overlay">'+
                '<button class="btn material-icons shadow-none" type="button" role="button">play_arrow</button>'+
	    '</div>'+
	    '</a></div></div></span>'+
    	    '<div class="track-title-mobile">'+
	    '<span class="track-title"><a onclick=\'Tidal("play","track","'+item.id+'",event); return false;\' title="'+item.title+'">'+item.title+'</a></span>'+
	    '<span class="track-artist"><a onclick=\'appGoto("Tidal","page","artist__'+item.artists[0].id+'");\' title="'+item.artists[0].name+'">'+item.artists[0].name+'</a></span>'+
	    '</div>'+
	    '<span class="track-album"><a onclick=\'appGoto("Tidal","page","album__'+item.album.id+'");\' title="'+item.album.title+'">'+item.album.title+'</a></span>'+
	    '<span class="track-duration">'+HHMMSS(item.duration)+'</span>'+
	    '<span class="track-fav"><a class="material-icons" onclick=\'Tidal("add","track","'+item.id+'",event); return false;\' title="Add to Queue">add</a></span>'+
	    '<span class="track-action"><a class="material-icons" onclick="showMenu2(this.parentNode,event);" title="Show menu">more_vert</a></span>';
    	    tbl.appendChild(tr);
    	    
    	}
    	tbl.classList.add('tracklist');
//        if (type == "tracks" && !request.data.offset)
        if (!request.data.offset)
    	    if (type == "tracks") {
    	       cardContainer.appendChild(tbl);
    	    } else {
    	       div2.appendChild(tbl);
    	    }
      }
    }
    observer.observe();
    modalLoader.hide();
    scrollFlag = false;
}

function parseFilmSearch(obj, request){
    var cardContainer = document.getElementById('Filmsearchbody');
//    obj.title,desc_header,desc,duration,cover
    cardContainer.innerHTML = '';
    cardContainer.classList.remove('hide');
    if (obj.items) {
	var grid = document.createElement('div');
	grid.classList.add('row');
	cardContainer.appendChild(grid);
	len = obj.items.length;
	for (var j=0; j < len; j++) {
	    var item = obj.items[j];
	    var card = document.createElement('div');
	    card.innerHTML = '<div class="card1"><a class="clickable" onclick=\'searchFilm("' + item.url + '",event);return false\'>'+
	    '<div class="item-wrapper"><img src="icons/disc.svg" data-src="' + item.img + '" class="lozad" height="100%">'+
	    '</div></a>'+
	    '<span class="talb clickable" onclick=\'searchFilm("' + item.url + '",event);return false;\'>'+ item.name + '</span>'+
	    '<span class="tart">'+ item.type + '</span>'+
	    (item.info ? '<span class="tart">'+ item.info + '</span>':'')+
	    '<span class="tart">'+ item.str + '</span></div>';
	    card.classList.add('grid-item');
	    grid.appendChild(card);
	}
    } else {
	var div = document.createElement('div');
	var str=
	'<div class="artist-header">'+
	'<div class="artist-image"><img src="' + obj.img + '" width="100%"></div>'+
	'<div class="artist-text"><h4>'+obj.title+'</h4>'+
	'<p>' + obj.desc_header + '</p>'+
	'<p>' + obj.desc + '</p>'+
	'<p>' + HHMMSS(obj.duration) + '</p>';

	var len = obj.streams.length;
	if (len >0) {
	    str += '<div class="input-group" style="width:180px;">'+
	    '<select class="custom-select" id="filmQuality">';
	    for (var i=0; i<len;i++){
		str += '<option value="'+obj.streams[i].res+'">'+obj.streams[i].res+'</option>'
	    }
	    str += '</select>';
	    str += '<div class="input-group-append">'+
	    '<button class="btn btn-primary" type="button" onclick=\'cmdFilm("play")\';">Play</button>'+
	    '</div></div>';
	}
	
	str += '</div></div>';
	
	div.innerHTML = str;
	cardContainer.appendChild(div);
    
    }
    observer.observe();
    modalLoader.hide();
}

function parseYtAdd(obj, request){
    var cardContainer = document.getElementById('channelSecond');
    if (request.data.type == 'videos' || request.data.type == 'playlists') {
	var video = '';
	var next = '';
	if (obj.continuationContents.itemSectionContinuation.continuations) {
	    next = obj.continuationContents.itemSectionContinuation.continuations[0].nextContinuationData.continuation
	}
	cardContainer.setAttribute('data-next',next);
	if (request.data.type == 'videos') video=1;

	var contents = obj.continuationContents.itemSectionContinuation.contents;
	var len = contents.length;
	for (var j = 0; j < len; j++) {
	    if (request.data.type == "videos") {
		var item = contents[j].compactVideoRenderer;
		var id = item.videoId;
		var link = item.thumbnail.thumbnails[0].url;
		var title = item.title.runs[0].text;
		var dur = item.lengthText.runs[0].text;
		var badges = item.viewCountText.runs[0].text+ ' &middot; ' + item.publishedTimeText.runs[0].text;
	    }
    	    if (request.data.type == "playlists") {
		if (contents[j].compactPlaylistRenderer) {
		    console.log('playlist');
    		    var item = contents[j].compactPlaylistRenderer;
		    var id = item.playlistId;
		    var link = item.thumbnail.thumbnails[0].url.split('?')[0];
		    var count = item.videoCountText.runs[0].text;
		}
		if (contents[j].compactShowRenderer) {
		    console.log('show');
    		    var item = contents[j].compactShowRenderer;
		    var id = item.navigationEndpoint.browseEndpoint.browseId;
    		    var link = item.thumbnailRenderer.showCustomThumbnailRenderer.thumbnail.thumbnails[0].url;
    		    var count = item.thumbnailOverlays[0].thumbnailOverlayBottomPanelRenderer.text.runs[0].text;
    		}
		var title = item.title.runs[0].text;
		var badges = (item.publishedTimeText ? item.publishedTimeText.runs[0].text :'');
    	    }
	    link = link.replace(/\/default/,'/mqdefault');
	    link = link.replace(/\/hqdefault/,'/mqdefault');
	    var card = document.createElement('div');
	    card.classList.add('video-item');
    	    card.innerHTML = '<div class="card1">' +
                    ' <a class="clickable" data-type="'+(video ? 'video':'playlist')+'" data-id="'+ id + '" onclick=\'playYoutube("' + (video ? 'video':'playlist') + '","'+id+'",event);\'>' +
                    ' <div class="item-wrapper">'+
		    '<img src="icons/disc.svg" data-src="'+link+'" width="100%" height="100%" class="lozad">'+
//                             (!phone && flag ? 'class="swiper-lazy">':'class="lozad">') +
//                             (!video ? 'class="swiper-lazy">' : 'class="lozad">') +
                    ' <div class="overlay">' +
                    '     <button class="btn material-icons shadow-none" type="button" role="button" onclick=\'playYoutube("'+(video ? 'video':'playlist') +'","'+ id +'",event)\' title="Play">play_arrow</button>' +
                    ' </div>'+
                    (video ? '<div class="item-time">'+ dur +'</div>' : '')+
        	    (video ? '' : '<div class="item-plist"><div class="item-plist-wrapper"><div class="item-plist-center"><i class="material-icons">playlist_play</i><br>'+count+'</div></div></div>')+
                    '</div>'+
                    '</a>'+
                    '  <span class="talb clickable" '+(video ? 'onclick=\'playYoutube("video","'+id+'");\'': 'onclick=\'appGoto("Youtube","page","playlist__'+id+'");\'') + ' title="' + title+'">' + title + '</span>' +
                    (badges ? '  <span class="item-title tart" title="'+badges+'">' + badges + '</span>' : '') +
                    '</div>';
            cardContainer.append(card);
	}
    }
    observer.observe();
    modalLoader.hide();
    scrollFlag = false;
}

function parseYtChannel(obj, request){

    if (request.data.cmd == 'channel') {
    // set active nav link
	var Container = document.getElementById('Youtubebody');
	Container.setAttribute('data-tab',request.data.id);
	var links = Container.getElementsByClassName('nav-link');
	var lnk = links.length;
	for (var a = 0; a < lnk; a++) {
	    links[a].classList.remove('active');
	    var url = links[a].getAttribute('data-url');
	    if (request.data.id == url)
		links[a].classList.add('active');
	}

	document.getElementById('channelHome').classList.add('hide');
	var cardContainer = document.getElementById('channelSecond');
//	if (request.data.id == 'videos') {
	    cardContainer.classList.add('row');
//	} else {
//	    cardContainer.classList.remove('row');
//	}
	cardContainer.innerHTML = '';
	cardContainer.classList.remove('hide');
	var len = obj.contents.singleColumnBrowseResultsRenderer.tabs.length;
	for (var i=0; i < len; i++) {
	    var tab = obj.contents.singleColumnBrowseResultsRenderer.tabs[i].tabRenderer;
	    var url = tab.endpoint.commandMetadata.webCommandMetadata.url;
	    url = url.split('/').pop();
	    if (url == request.data.id) {

 		var len3 = tab.content.sectionListRenderer.contents.length;
		for (var k = 0; k < len3; k++) {
// 		  if (request.data.id == 'videos') {
		    var shelf = ''
		    if (tab.content.sectionListRenderer.contents[k].itemSectionRenderer)
			var contents = tab.content.sectionListRenderer.contents[k].itemSectionRenderer.contents;

		    if (tab.content.sectionListRenderer.contents[k].shelfRenderer) {
			var contents = tab.content.sectionListRenderer.contents[k].shelfRenderer.content.verticalListRenderer.items;
			var header = document.createElement('div');
			var headertxt = tab.content.sectionListRenderer.contents[k].shelfRenderer.title.runs[0].text;
			header.innerHTML = '<h5>'+ headertxt + '</h5>';
			cardContainer.appendChild(header);
			shelf = 1;
			var gr = document.createElement('div');
			gr.classList.add('row');
			cardContainer.appendChild(gr);
		    }
			
		    var htitle = '';
		    var len2 = contents.length;

		  var next = '';
		  if (request.data.id == "videos") {
		    if (tab.content.sectionListRenderer.contents[k].itemSectionRenderer)
		     if (tab.content.sectionListRenderer.contents[k].itemSectionRenderer.continuations) 
			next = tab.content.sectionListRenderer.contents[k].itemSectionRenderer.continuations[0].nextContinuationData.continuation;
		  }
		  if (request.data.id == "playlists") {
		    if (tab.content.sectionListRenderer)
		     if (tab.content.sectionListRenderer.continuations) 
			next = tab.content.sectionListRenderer.continuations[0].nextContinuationData.continuation;
		  }
		  cardContainer.setAttribute('data-next',next);
		
		  for (var j = 0; j < len2; j++) {
		    var video = '';
		    if (request.data.id == "videos") {
    			var subitem = contents[j].compactVideoRenderer;
			var id = subitem.videoId;
			var link = subitem.thumbnail.thumbnails[0].url.split('?')[0];
			var title = subitem.title.runs[0].text;
			var badges = (subitem.viewCountText ? subitem.viewCountText.runs[0].text:'')+ ' &middot; ' + (subitem.publishedTimeText ? subitem.publishedTimeText.runs[0].text:'');
			var dur = (subitem.lengthText ? subitem.lengthText.runs[0].text:'');
			video = 1;
		    }
    		    if (request.data.id == "playlists") {
//    			var subitem = grid.items[j].compactPlaylistRenderer;
			if (contents[j].compactPlaylistRenderer) {
    			    var subitem = contents[j].compactPlaylistRenderer;
			    var id = subitem.playlistId;
			    var link = subitem.thumbnail.thumbnails[0].url.split('?')[0];
			    var count = (subitem.videoCountText ? subitem.videoCountText.runs[0].text:'');
			}
			if (contents[j].compactShowRenderer) {
    			    var subitem = contents[j].compactShowRenderer;
			    var id = subitem.navigationEndpoint.browseEndpoint.browseId;
    			    var link = subitem.thumbnailRenderer.showCustomThumbnailRenderer.thumbnail.thumbnails[0].url;
    			    var count = (subitem.thumbnailOverlays[0].thumbnailOverlayBottomPanelRenderer ? subitem.thumbnailOverlays[0].thumbnailOverlayBottomPanelRenderer.text.runs[0].text:'');
    			}
			var title = subitem.title.runs[0].text;
			var badges = (subitem.publishedTimeText ? subitem.publishedTimeText.runs[0].text :'');
    		    }
		    link = link.replace(/\/default/,'/mqdefault');
		    link = link.replace(/\/hqdefault/,'/mqdefault');
		    var card = document.createElement('div');
		    card.classList.add('video-item');
    		    card.innerHTML = '<div class="card1">' +
                    ' <a class="clickable" data-type="'+(video ? 'video':'playlist')+'" data-id="'+ id + '" onclick=\'playYoutube("' + (video ? 'video':'playlist') + '","'+id+'",event);\'>' +
                    ' <div class="item-wrapper">'+
		    '<img src="icons/disc.svg" data-src="'+link+'" width="100%" height="100%" class="lozad">'+
//                             (!phone && flag ? 'class="swiper-lazy">':'class="lozad">') +
//                             (!video ? 'class="swiper-lazy">' : 'class="lozad">') +
                    ' <div class="overlay">' +
                    '     <button class="btn material-icons shadow-none" type="button" role="button" onclick=\'playYoutube("'+(video ? 'video':'playlist') +'","'+ id +'",event)\' title="Play">play_arrow</button>' +
                    ' </div>'+
                    (video ? '<div class="item-time">'+ dur +'</div>' : '')+
        	    (video ? '' : '<div class="item-plist"><div class="item-plist-wrapper"><div class="item-plist-center"><i class="material-icons">playlist_play</i><br>'+count+'</div></div></div>')+
                    '</div>'+
                    '</a>'+
                    '  <span class="talb clickable" '+(video ? 'onclick=\'playYoutube("video","'+id+'");\'': 'onclick=\'appGoto("Youtube","page","playlist__'+id+'");\'') + ' title="' + title+'">' + title + '</span>' +
                    (badges ? '  <span class="item-title tart" title="'+badges+'">' + badges + '</span>' : '') +
                    '</div>';
//		    if (htitle) {
//            	      swiper.appendChild(card);
//		    } else {
		      if (shelf) {
		        gr.appendChild(card);
		      } else {
            	        cardContainer.appendChild(card);
            	      }
//            	    }
		  } //for
//		  if (htitle) {
//        	    cardContainer.appendChild(swiper);
//
//        	  }
		} //for
	      break;
	    } //if
	}
    }
    observer.observe();
    modalLoader.hide();
}

function parseYtDDD(obj, request){
    var cardContainer = document.getElementById('Youtubebody');
    cardContainer.innerHTML = '';
    cardContainer.classList.remove('hide');
//    cardContainer.classList.add('row');
    var div = document.createElement('div');
    div.innerHTML = '<h5>' + obj.name + '</h5>';
    div.classList.add('group-header');
    cardContainer.appendChild(div);
    var len = obj.items.length;
    var bb = document.createElement('div');
    bb.classList.add('row');
    cardContainer.appendChild(bb);
    for (var j = 0; j < len; j++){
    	var item = obj.items[j];
    	var link = item.cover;
    	var dur = '';
	var card = document.createElement('div');
	    card.classList.add('video-item');
    	    card.innerHTML = '<div class="card1">' +
            ' <a class="clickable" data-type="video" data-id="'+ item.id + '" onclick=\'playYoutube("video","'+item.id+'",event);\'>' +
            ' <div class="item-wrapper">'+
	    '<img src="icons/disc.svg" data-src="'+link+'" width="100%" height="100%" class="lozad">'+
//                             (!phone && flag ? 'class="swiper-lazy">':'class="lozad">') +
//                             (!video ? 'class="swiper-lazy">' : 'class="lozad">') +
                    ' <div class="overlay">' +
                    '     <button class="btn material-icons shadow-none" type="button" role="button" onclick=\'playYoutube("video","'+ item.id +'",event)\' title="Play">play_arrow</button>' +
                    ' </div>'+
                    (item.duration ? '<div class="item-time">'+ HHMMSS(item.duration) +'</div>' : '')+
                    '</div>'+
                    '</a>'+
                    '  <span class="talb clickable" onclick=\'playYoutube("video","'+item.id+'");\' title="' + item.title+'">' + item.title + '</span>' +
                    '  <span class="item-title tart clickable" onclick=\'appGoto("Youtube","page","channel__'+item.ownerid+'");\' title="' + item.owner+'">' + item.owner + '</span>' +
                    '</div>';
         bb.appendChild(card);
    }
    observer.observe();
    modalLoader.hide();
}

function parseYoutube(obj, request){
    var type = request.data.type;
    var cardContainer = document.getElementById('Youtubebody');
    cardContainer.classList.remove('hide');

    while (cardContainer.firstChild) {
    	cardContainer.removeChild(cardContainer.firstChild);
    };
    
    if (request.data.cmd == 'page') {
      if (type == 'playlist') {
	var len = obj.header.stats.length;
	var badges = '';
        for (var j = 0; j < len; j++){
    	    var item = obj.header.stats[j];
    	    if (item.simpleText) {
    		badges += (j>0 ? ' &middot; ' : '') + item.simpleText;
    	    } else {
    	    	badges += (j>0 ? ' &middot; ' : '')+ item.runs[0].text;
    	    }
	}
	var desc = '';
	if (obj.header.desc) {
	  var len = obj.header.desc.runs.length;
          for (var j = 0; j < len; j++){
    	    var item = obj.header.desc.runs[j];
    	    var de = item.text.replace(/\n\n\n/g,'');
    	    desc += de.replace(/\n/g,'<br>');
          }
        }
//	.owner
//        var channelCover = obj.owner.cover.split('?')[0];
	var cover = obj.header.cover.split('?')[0];
	cover = cover.replace(/\/default/,'/mqdefault');

	var div = document.createElement('div');
	div.classList.add('youtubelist_header');
	div.innerHTML = '<a href=""  onclick=\'playYoutube("playlist","' + obj.header.id + '",event);\'>'+
	 '<div class="item-wrapper2">'+
	'<img src="' + cover + '" width="300px"></div>'+
	'<div class="overlay">'+
              '<button class="btn material-icons shadow-none" type="button" role="button">play_arrow</button>'+
	'</div></a>'+
	'<h4>' + obj.header.title + '</h4>'+
	'<span class="tart">'+badges+'</span>'+
	(desc ? '<p>' + desc + '</p>':'')+
	'<h4 class="clickable" onclick=\'appGoto("Yotube","channel__'+ obj.owner.id + '",event\')>'+obj.owner.name+'</h4>';
//	div.classList.add('video-item');
	cardContainer.appendChild(div);

//	.items
	var len2 = obj.items.length;

	var tbl = document.createElement('ul');
	tbl.classList.add('tracklist');
	tbl.classList.add('youtubelist');

    	var tr = document.createElement('li');
    	tr.innerHTML = '<span class="track-cover"></span>'+
//	'<div class="track-title-mobile">'+
    	'<span class="track-artist"> Title / Channel</span>'+
//    	'</div>'+
    	'<span class="track-duration">Time</span>';
    	tr.classList.add('tracklist-label');
    	tbl.appendChild(tr);
        cardContainer.appendChild(tbl);
        
        for (var j = 0; j < len2; j++){
    	  var item = obj.items[j].playlistVideoRenderer;
    	  if (!item.shortBylineText) continue;

	  var tr = document.createElement('li'); 
    	     
    	  var img = item.thumbnail.thumbnails[0].url.split('?')[0];
	  if (img == null) {
    	    var img = 'icons/disc.svg';
    	  }
//    	  var title = item.title.simpleText;
    	  var title = item.title.runs[0].text;
    	  var id = item.videoId;
    	  var channel ='';
    	  var channelId ='';
    	  var channel = item.shortBylineText.runs[0].text;
          var channelId = item.shortBylineText.runs[0].navigationEndpoint.browseEndpoint.browseId;
    	  tr.classList.add('tracklist-item');

    	  tr.setAttribute('data-type','video');
	  tr.setAttribute('data-title',title);
	  tr.setAttribute('data-id',id);
	  tr.innerHTML = '<span class="track-cover">'+
	  '<div class="imgmini2">'+
	  '<div class="item-wrapper">'+
	  '<a class="clickable" data-type="track" data-id="'+id+'" onclick=\'playYoutube("video","'+ id+'",event); return false\' title="Play">'+
	  '<img class="lozad" src="icons/disc.svg" data-src="'+img+'" width="50px" height="50px">'+
	  '<div class="overlay">'+
              '<button class="btn material-icons shadow-none" type="button" role="button">play_arrow</button>'+
	  '</div>'+
	  '</a></div></div></span>'+
	  '<div class="track-title-mobile">'+
	  '<span class="track-title"><a class="clickable" onclick=\'playYoutube("video","'+id+'",event); return false\' title="' + title + '">' + title + '</a></span>' +
	  '<span class="track-artist"><a class="clickable" onclick=\'appGoto("Youtube","page","channel__' + channelId + '");\' title="' + channel + '">' + channel + '</a></span>' +
	  '</div>'+
	  '<span class="track-duration">' + (item.lengthText ? item.lengthText.runs[0].text:'') + '</span>';
//	    	'<span class="track-fav">'+(item.id == 0 ? '':'<a class="clickable material-icons" onclick="Tidal(\'add\',\'track\',\''+item.id+'\',event);return false;" title="Add to Queue">add</a>')+'</span>'+
//		'<span class="track-action"><a class="clickable material-icons" onclick="showMenu2(this.parentNode,event);" title="Show menu">more_vert</a></span>';

    	  tbl.appendChild(tr);
        } //for

      } else if (type == 'channel') {
	cardContainer.setAttribute('data-tab','featured');

	var header = document.createElement('div');
	var meta = obj.metadata.channelMetadataRenderer;
        var chanId = meta.externalId;
	header.innerHTML = '<div style="width:100%;display:flex;"><div style="float:left;"><img src="' + meta.avatar.thumbnails[0].url + '" width="200px"></div>'+
	'<div style="float:left;padding:20px;"><p>' + meta.title + '</p>'+
	    '<p>' + meta.description + '</p>'+
	    (obj.header.c4TabbedHeaderRenderer.subscriberCountText ? '<span class="tart">'+ obj.header.c4TabbedHeaderRenderer.subscriberCountText.runs[0].text + '</span>':'')+
	    '<div></div>';
        cardContainer.appendChild(header);
	var tabs = obj.contents.singleColumnBrowseResultsRenderer.tabs;
	var len = tabs.length;
        
        var ul = document.createElement('div');
        ul.classList.add('nav');
        ul.classList.add('nav-tabs');
        cardContainer.appendChild(ul);

        var main = document.createElement('div');
        main.setAttribute('id','channelHome');
        cardContainer.appendChild(main);
        for (var j = 0; j < len; j++) {
//    	  var items = tabs[j].tabRenderer.content.sectionListRenderer.contents;
	  if (tabs[j].tabRenderer) {
	    var tab = tabs[j].tabRenderer;
	    var li = document.createElement('li'); 
//	    var div = document.createElement('div');
	    var title = tab.title;
	    var url = tab.endpoint.commandMetadata.webCommandMetadata.url;
	    url = url.split('/').pop();
	    li.classList.add('nav-item');
	    if (url == 'videos' || url=='playlists' || url == 'featured') {
		li.innerHTML = '<a class="nav-link'+(j==0 ? ' active':'')+'" data-url="'+url+'" onclick=\'YoutubeChannel("'+chanId+'","'+url+'",event)\'>' + title + '</a>';
	    } else {
		li.innerHTML = '<a class="nav-link" data-url="'+url+'">' + title + '</a>';
	    }
	    console.log(title);
            ul.appendChild(li);
//            console.log(tab.content.sectionListRenderer);
//            if (tab.content.sectionListRenderer.contents) {
            if (tab.content.sectionListRenderer.contents) {
   		var items = tab.content.sectionListRenderer.contents;
		var len2 = items.length;
   		console.log(len2);
    		for (var i = 0; i < len2; i++){
//    		    if (items[i].itemSectionRenderer) {
    		    if (items[i].shelfRenderer) {
//    			var item = items[i].itemSectionRenderer.contents[0];
    			var item = items[i].shelfRenderer.content;
/*    			if (item.channelVideoRenderer) {
			  var div = document.createElement('div');
			  div.innerHTML = '<p>' + item.channelVideoRenderer.title.runs[0].text + '</p';
        		  cardContainer.appendChild(div);    			
    			}*/
//    		        if (item.shelfRenderer) {
//    		        if (item.channelFeaturedVideoRenderer) {
			  var header = document.createElement('div');
			  header.innerHTML = '<h5>' + items[i].shelfRenderer.title.runs[0].text + '</h5>';
			  header.classList.add('group-header');
        		  main.appendChild(header);

			  var swiper = document.createElement('div');
			  swiper.classList.add('swiper-container');
			  swiper.classList.add('swiper-1x');
			  var wrapper = document.createElement('div');
			  wrapper.classList.add('swiper-wrapper');
			  swiper.appendChild(wrapper);
			  
//        		  if (item.shelfRenderer.content.horizontalListRenderer || item.shelfRenderer.content.expandedShelfContentsRenderer) {
//			    if (item.shelfRenderer.content.horizontalListRenderer)
//        			var subitems = item.shelfRenderer.content.horizontalListRenderer.items;
        		  if (item.verticalListRenderer || item.expandedShelfContentsRenderer) {
			    if (item.verticalListRenderer)
        			var subitems = item.verticalListRenderer.items;
        		    if (item.expandedShelfContentsRenderer)
        			var subitems = item.expandedShelfContentsRenderer.items;
        		    var len3 = subitems.length;
        		    console.log(len3);
    			    for (var k = 0; k < len3; k++){
    				var video = '';
//    				if (subitems[k].gridVideoRenderer) {
    				if (subitems[k].compactVideoRenderer || subitems[k].videoRenderer) {
    				  var subitem = (subitems[k].videoRenderer ? subitems[k].videoRenderer : subitems[k].compactVideoRenderer);
    				  var subitem = subitems[k].compactVideoRenderer;
				  var id = subitem.videoId;
				  var link = subitem.thumbnail.thumbnails[0].url.split('?')[0];
				  link = link.replace(/\/default/,'/mqdefault');
//				  var title = subitem.title.simpleText;
				  var title = subitem.title.runs[0].text;
				  var badges = (subitem.videoCountText ? subitem.viewCountText.runs[0].text:'') + ' &middot; ' + (subitem.publishedTimeText ? subitem.publishedTimeText.runs[0].text:'');
				  var dur =( subitem.lengthText ? subitem.lengthText.runs[0].text:'');
				  video=1;
    				}
//    				if (subitems[k].gridPlaylistRenderer) {
    				if (subitems[k].compactPlaylistRenderer) {
    				  var subitem = subitems[k].compactPlaylistRenderer;
				  var id = subitem.playlistId;
				  var link = subitem.thumbnail.thumbnails[0].url.split('?')[0];
				  link = link.replace(/\/default/,'/mqdefault');
				  var title = subitem.title.runs[0].text;
				  var badges = (subitem.videoCountText ? subitem.videoCountText.runs[0].text:'');
    				}
    				if (subitems[k].compactStationRenderer) {
    				  var subitem = subitems[k].compactStationRenderer;
				  var id = subitem.navigationEndpoint.watchEndpoint.playlistId;
				  var link = subitem.thumbnail.thumbnails[0].url;
//				  link = link.replace(/\/maxresdefault/,'/default');
				  link = link.replace(/\/default/,'/mqdefault');
				  var title = subitem.title.simpleText;
				  var badges = (subitem.videoCountText ? subitem.videoCountText.runs[0].text:'');
    				}
				var card = document.createElement('div');
				card.classList.add('swiper-slide');
				card.classList.add('video-item');
    				card.innerHTML = '<div class="card1">' +
                                ' <a class="clickable" data-type="'+(video ? 'video':'playlist')+'" data-id="'+ id + '" onclick=\'playYoutube("' + (video ? 'video':'playlist') + '","'+id+'",event);\'>' +
                                ' <div class="item-wrapper">'+
				  '<img src="icons/disc.svg" data-src="'+link+'" width="100%" height="100%" class="swiper-lazy">'+
//                             (!phone && flag ? 'class="swiper-lazy">':'class="lozad">') +
//                             (!phone? 'class="swiper-lazy">':'class="lozad">') +
                                ' <div class="overlay">' +
                                '     <button class="btn material-icons shadow-none" type="button" role="button" onclick=\'playYoutube("'+(video ? 'video':'playlist') +'","'+ id+'",event)\' title="Play">play_arrow</button>' +
                               ' </div>'+
                               (video ? '<div class="item-time">'+ dur +'</div>' : '')+
        	    	       (video ? '' : '<div class="item-plist"><div class="item-plist-wrapper"><div class="item-plist-center"><i class="material-icons">playlist_play</i><br>'+badges+'</div></div></div>')+
                               '</div>'+
                               '</a>'+
                               '  <span class="talb clickable" '+(video ? 'onclick=\'playYoutube("video","'+id+'");\'': 'onclick=\'appGoto("Youtube","page","playlist__'+id+'");\'') + ' title="' + title+'">' + title + '</span>' +
                               (video ? '  <span class="item-title tart" title="'+badges+'">' + badges + '</span>' : '') +
                               '</div>';
				  
//				  card.innerHTML = '<p>' + subitem.videoId + '</p>';
        			wrapper.appendChild(card);
        		    }
			    var pagina = document.createElement('div');
			    pagina.classList.add('swiper-scrollbar');
			    swiper.appendChild(pagina);
			    var but = document.createElement('div');
			    but.classList.add('swiper-button-next');
			    swiper.appendChild(but);
			    var but = document.createElement('div');
			    but.classList.add('swiper-button-prev');
			    swiper.appendChild(but);
        		    main.appendChild(swiper);
        		  }
//        		}
        	    }
		} //for
	    } //if
	  } //if
   		//.contents
	} //for
	var swiper1x = new Swiper('.swiper-1x', {
    	  slidesPerView: 'auto',
          slidesPerColumn: 1,
          slidesPerGroup: 3,
//    	freeMode: true,
          scrollbar: {
    	    el: '.swiper-scrollbar',
    	    hide: true,
          },
          navigation: {
    	    nextEl: '.swiper-button-next',
    	    prevEl: '.swiper-button-prev',
          },
//        preloadImages: false,
          lazy:true,
          watchSlidesVisibility:true
	});

      } //if
      
    }
    var div = document.createElement('div');
//    div.classList.add('row');
    div.setAttribute('id','channelSecond');
    
    cardContainer.append(div);
    observer.observe();
    modalLoader.hide();
}

function parseYoutubeSearch(obj, request){
    var len = 0;
    var cardContainer = document.getElementById('Youtubesearchbody');

//    var head = document.getElementById('ytSearchHeader');
//    head.classList.remove('hide');

    if (!request.data.nextpage) {
	while (cardContainer.firstChild) {
    	    cardContainer.removeChild(cardContainer.firstChild);
	};
    }
    cardContainer.classList.remove('hide');
//    cardContainer.setAttribute('data-nextpage',obj.nextPageToken);
    cardContainer.setAttribute('data-nextpage',obj.next);
    if (request.data.type == 'video' || request.data.type == 'playlist') {
	len = obj.items.length;
	if (!request.data.nextpage) {
	    cardContainer.classList.add('row');
    	    if (phone) cardContainer.classList.add('phone');
	}
//	var type = 'video';
	for (var i = 0; i < len; i++) {
	    var item = obj.items[i];
	    if (item.type == 'shelf') continue;
	    if (item.type == 'channel') {
		var link = 'https:'+item.cover;
	    } else {
		var link = item.cover.split('?')[0];
	    }
	    var div = document.createElement('div');
	    div.classList.add('video-item');
	    var str = '<div class="card1">';
	    var count = '';
	    if (item.count) {
		if (item.count.simpleText) {
		    count = item.count.simpleText;
		} else {
		    var len2=item.count.runs.length;
		    for (var j = 0; j < len2; j++) {
			count += item.count.runs[j].text;
		    }
		}
	    }
	    var pubtime ='';
	    if (item.pubtime) {
		if (item.pubtime.simpleText) {
		    pubtime = item.pubtime.simpleText;
		} else {
		    var len2=item.pubtime.runs.length;
		    for (var j = 0; j < len2; j++) {
			pubtime += item.pubtime.runs[j].text;
		    }
		}
	    }
	    var dur = '';
	    if (item.duration) {
		if (item.duration != null) dur = item.duration;
	    }
	    var badges = '';
	    if (item.badges){
		if (item.badges != null) {
		    var len2=item.badges.length;
		    for (var j = 0; j < len2; j++) {
			badges += (j>0 ? ' &middot; ':'')+item.badges[j].metadataBadgeRenderer.label;
		    }
		}
	    
	    }

//	    if (type == 'channel') {
//                str += ' <a class="clickable" onclick=\'appGoto("Youtube","page","' + type +'_'+item.id.channelId+'",event)\'>';
//	    } else {
	    if (item.type != 'shelf') {
		    var id = item.id;
            	    str += (item.type == 'channel' ? '<a class="clickable" onclick=\'appGoto("Youtube","page","' + item.type +'__' + item.id + '")\'>':' <a class="clickable" onclick=\'playYoutube("'+item.type+'","'+id +'",event)\'>');
            str +=  ' <div class="item-wrapper'+(item.type == 'channel' ? ' item-channel' :'')+'">' +
                    ' <img src="'+link+'" width='+(item.type == 'channel' ? '"60%"':'"100%" height="100%"')+' class="lozad">' +
                    ' <div class="overlay">';
	    if (item.type != 'channel')
                str += '     <button class="btn material-icons clickable" type="button" role="button" onclick=\'playYoutube("'+item.type+'","'+id+'",event)\'>play_arrow</button>';
    	    str +=   ' </div>'+
        	     (dur ? '<div class="item-time">'+ dur  +'</div>':'')+
        	     (!dur && badges ? '<div class="item-time">'+ badges  +'</div>':'')+
        	     (item.type == 'playlist' || item.type == 'radio'? '<div class="item-plist"><div class="item-plist-wrapper"><div class="item-plist-center"><i class="material-icons">playlist_play</i><br>'+count+'</div></div></div>':'')+
                     (dur && badges ? '  <div class="item-badges">' +  badges + '</div>':'')+
                     '</div>'+
                     '</a>';
//            if (type == 'channel') {
//                str += '  <span class="talb" title="'+item.title+'">' + item.title + '</span>';
//            } else {
                str += '  <span class="talb clickable" title="'+item.title+'"'+ (item.type == 'channel' || item.type == 'playlist' ? ' onclick=\'appGoto("Youtube","page","' + item.type +'__' + item.id + '")\'>':' onclick=\'playYoutube("'+item.type+'","'+id+'",event)\'>') + item.title + '</span>' +
                       (item.type != 'channel' && item.type != 'radio' ? '  <span class="item-title tart clickable" title="'+item.owner+'" onclick=\'appGoto("Youtube","page","channel__'+item.ownerid+'");\'>' + item.owner+'</span>':'')+
                       (item.type == 'channel' && item.subs != null ? '  <span class="item-title tart" title="'+item.subs+'" >' + item.subs+'</span>':'')+
                       (count && item.type != 'playlist' ?'  <span class="item-title tart">' + count + (pubtime ? ' &middot; '+ pubtime:'')  +'</span>':'');
//            }
            str += '</div>';
	    div.innerHTML = str;
	
	    cardContainer.appendChild(div);
	    } // !=shelf
	}
    }
    modalLoader.hide();
}

function parseQobuzSearch(obj, request){
var img='';
var size=0;
var imgc='';
var inner='';
var a=0,b=0,c=0, d=0;
    document.getElementById('qsearchbtn').focus();

    if (request.data.query == '') {
//	modalQSearch('show');
	return;
    }
    else {
	var cardContainer = document.getElementById('qobuzModalSearch');
	while (cardContainer.firstChild) {
    	    cardContainer.removeChild(cardContainer.firstChild);
	};
    }
    if (obj.albums) {
	var div = document.createElement('div');
	div.innerHTML = '<h6>Albums</h6><a class="clickable" onclick=\'QSearchMore("albums","'+request.data.query+'")\'>Show all</a>';
	div.classList.add('group-header');
	var len = obj.albums.items.length;
	if (len > 0) {
	a = len;
	cardContainer.appendChild(div);
	for (var i = 0; i < len; i++) {
	    var item = obj.albums.items[i];
	    img = item.image.thumbnail;
    	    if (img == null) {
    		var link = 'icons/disc.svg';
    	    }
	    else {
    		var link = img;
    	    }
	    //id,title,artists[0].name,cover
	    var div = document.createElement('div');
	    div.innerHTML = '<div class="imgmini"><div class="item-wrapper"><a onclick=\'Qobuz("play","album","'+item.id+'",event);\' title="Play">'+
	    '<img class="lozad" src="icons/disc.svg" data-src="'+link+'">'+
	    '<div class="overlay">'+
                '<button class="btn material-icons shadow-none" type="button" role="button" title="Play">play_arrow</button>'+
	    '</div></a>'+
	    '</div></div>'+
	    '<div class="search-right">'+
	    '<span class="item-title clickable" onclick=\'appGoto("Qobuz","page","album__' + item.id + '");\' title="'+item.title+'">'+item.title+'</span>'+
	    '<span class="item-title tart clickable" onclick=\'appGoto("Qobuz","page","artist__' + item.artist.id + '");\' title="'+item.artist.name+'">'+item.artist.name+'</span>'+
	    '</div>';
	    div.classList.add('search-res');
	    cardContainer.appendChild(div);
	}
	var div = document.createElement('hr');
	cardContainer.appendChild(div);
	}
    }
    if (obj.artists) {
	var div = document.createElement('div');
	div.innerHTML = '<h6>Artists</h6><a class="clickable" onclick=\'QSearchMore("artists","'+request.data.query+'")\'>Show all</a>';
	div.classList.add('group-header');
	var len = obj.artists.items.length;
	if (len > 0) {
	b = len;
	cardContainer.appendChild(div);
	for (var i = 0; i < len; i++) {
	    var item = obj.artists.items[i];
    	    img = item.picture;
    	    if (img == null) {
    		var link = 'icons/disc.svg';
    	    }
	    else {
    		var link = img;
    	    }
	//id,name,picture
	    var div = document.createElement('div');
	    div.innerHTML = '<div class="imgmini"><div class="artist-wrapper"><a onclick=\'appGoto("Qobuz","page","artist__' + item.id + '");\'>'+
	    '<img class="lozad" src="icons/disc.svg" data-src="'+link+'">'+
	    '<div class="overlay">'+
	    '</div></a>'+
	    '</div></div>'+
	    '<div class="search-right">'+
	    '<span class="item-title clickable" onclick=\'appGoto("Qobuz","page","artist__' + item.id + '");\' title="'+item.name+'">'+item.name+'</span>'+
	    '</div>';
	    div.classList.add('search-art');
	    cardContainer.appendChild(div);
	}
	var div = document.createElement('hr');
	cardContainer.appendChild(div);
	}
    }

    if (obj.playlists) {
	var div = document.createElement('div');
	div.innerHTML = '<h6>Playlists</h6><a class="clickable" onclick=\'QSearchMore("playlists","'+request.data.query+'")\'>Show all</a>';
	div.classList.add('group-header');
	var len = obj.playlists.items.length;
	c = len;
	if (len > 0) {
	cardContainer.appendChild(div);
	for (var i = 0; i < len; i++) {
	    var item = obj.playlists.items[i];
	    //item.uuid, item.image, title
    	    img = item.images[0];
    	    if (img == null) {
    		var link = 'icons/disc.svg';
    	    } else {
    		var link = img;
    	    }
	    var div = document.createElement('div');
	    div.innerHTML = '<div class="imgmini"><div class="item-wrapper"><a onclick=\'Qobuz("play","playlist","'+item.id+'",event);\' title="Play">'+
	    '<img class="lozad" src="icons/disc.svg" data-src="'+link+'">'+
	    '<div class="overlay">'+
                '<button class="btn material-icons shadow-none" type="button" role="button">play_arrow</button>'+
	    '</div></a>'+
	    '</div></div>'+
	    '<div class="search-right">'+
	    '<span class="item-title clickable" onclick=\'appGoto("Qobuz","page","playlist__' + item.id + '");\' title="'+item.name+'">'+item.name+'</span>'+
	    '</div>';
	    div.classList.add('search-art');
	    cardContainer.appendChild(div);
	}
	var div = document.createElement('hr');
	cardContainer.appendChild(div);
	}
    }
    if (obj.tracks) {
	var div = document.createElement('div');
	div.innerHTML = '<h6>Tracks</h6><a class="clickable" onclick=\'QSearchMore("tracks","'+request.data.query+'")\'>Show all</a>';
	div.classList.add('group-header');
	var len = obj.tracks.items.length;
	d = len;
	if (len > 0) {
	cardContainer.appendChild(div);
	for (var i = 0; i < len; i++) {
	    var item = obj.tracks.items[i];
	    img =  item.album.image.thumbnail;
	    if (img == null) {
		var link = 'icons/disc.svg';
	    } else {
    		var link = img;
    	    }
	    
	    var div = document.createElement('div');
	    div.innerHTML = '<div class="imgmini"><div class="item-wrapper"><a onclick=\'Qobuz("play","track","'+item.id+'",event);\'>'+
	    '<img class="lozad" src="icons/disc.svg" data-src="'+link+'">'+
	    '<div class="overlay">'+
                '<button class="btn material-icons shadow-none" type="button" role="button">play_arrow</button>'+
	    '</div></a>'+
	    '</div></div>'+
	    '<div class="search-right">'+
	    '<span class="item-title clickable" onclick=\'Qobuz("play","track","'+item.id+'",event);\'>'+item.title+'</span>'+
	    '<span class="item-title tart clickable" onclick=\'appGoto("Qobuz","page","artist__' + item.performer.id + '");\'>'+item.performer.name+'</span>'+
	    '</div>';
	    div.classList.add('search-res');
	    cardContainer.appendChild(div);
	}
	}
    }
    if (a+b+c+d == 0) {
	cardContainer.innerHTML = '<p>Nothing found</p>'
    }
    observer.observe();
    modalLoader.hide();
//    cardContainer.classList.remove('hide');
    modalQSearch('show');

}

function parseTidalSearch(obj, request){
var img = '';
var size = 0;
var imgc = '';
var inner = '';
var a = 0, b = 0, c = 0, d = 0;
    document.getElementById('tsearchbtn').focus();

//    console.log('---parsetidalSearch---');
    if (request.data.query == '') {
//	modalSearch('show');
	return;
    }
    else {
	var cardContainer = document.getElementById('tidalModalSearch');
	while (cardContainer.firstChild) {
    	    cardContainer.removeChild(cardContainer.firstChild);
	};
    }
    if (obj.topHit) {
	var div = document.createElement('div');
	div.innerHTML = "<h6>Top results</h6>";
	div.classList.add('header-s');
	cardContainer.appendChild(div);
	var item = obj.topHit.value;
	var button = '';
	imgc = 'imgmini item-wrapper';
	if (obj.topHit.type == "ALBUMS") {
	    img = item.cover;
	    size = 80;
	    inner = '<span class="item-title clickable" onclick=\'appGoto("Tidal","page","album__' + item.id + '");\' title="'+item.title+'">'+item.title+'</span>'+
	    '<span class="item-title tart clickable" onclick=\'appGoto("Tidal","page","artist__' + item.artists[0].id + '");\' title="'+item.artists[0].name+'">'+item.artists[0].name+'</span>';
            button = '<button class="btn material-icons clickable" type="button" role="button" onclick=\'Tidal("play","album","'+item.id+'",event);\' title="Play">play_arrow</button>';
	}
	else if (obj.topHit.type == "ARTISTS") {
	    img = item.picture;
	    size = 160;
	    imgc = 'imgmini artist-wrapper';
	    inner = '<span class="item-title clickable" onclick=\'appGoto("Tidal","page","artist__' + item.id + '");\'>'+item.name+'</span>';
            button = '<button class="btn material-icons clickable" type="button" role="button" onclick=\'Tidal("page","artist","'+item.id+'",event);\' title="Goto artist">play_arrow</button>';
	}
	else if (obj.topHit.type == "PLAYLISTS") {
	    img = item.squareImage;
//	    imgc = '';
	    size = 160;
	    inner = '<span class="item-title clickable" onclick=\'appGoto("Tidal","page","playlist__' + item.uuid + '");\' title="'+item.title+'">'+item.title+'</span>';
            button = '<button class="btn material-icons clickable" type="button" role="button" onclick=\'Tidal("play","playlist","'+item.uuid+'",event);\' title="Play">play_arrow</button>';
	}
	else if (obj.topHit.type == "TRACKS") {
	    img = item.album.cover;
	    size = 80;
//	    imgc = '';
	    inner = '<span class="item-title clickable" onclick=\'Tidal("play","track","'+item.id+'",event); return false;\' title="'+item.title+'">'+item.title+'</span>'+
	    '<span class="item-title tart clickable" onclick=\'appGoto("Tidal","page","artist__' + item.artists[0].id + '");\' title="'+item.artists[0].name+'">'+item.artists[0].name+'</span>';
            button = '<button class="btn material-icons clickable" type="button" role="button" onclick=\'Tidal("play","track","'+item.id+'",event)\' title="Play">play_arrow</button>';	
	}
    	if (img == null) {
    	    var link = 'icons/disc.svg';
    	} else {
    	    img = img.replace(/-/g,'\/');
    	    var link='https://resources.tidal.com/images/'+img+'/'+size+'x'+size+'.jpg';
    	}
    	    
	var div = document.createElement('div');
	var str =
	 (imgc ? '<div class="'+imgc+'">' : '<div class="imgmini">')+'<a onclick=""><img class="lozad" src="icons/disc.svg" data-src="' + link +'">'+
	    '<div class="overlay">'+
	    button +
	    '</div></a>'+
	    '</div>'+
	'<div class="search-right">'+inner+'</div>';
	div.innerHTML = str;
	div.classList.add('search-res');
	cardContainer.appendChild(div);
	var div = document.createElement('hr');
	cardContainer.appendChild(div);
	
    }
    if (obj.albums) {
	var len = obj.albums.items.length;
	a = len;
	if (len>0){
	var div = document.createElement('div');
//	div.innerHTML = '<h6>Albums</h6><a class="clickable" onclick=\'QSearchMore("albums","'+request.data.query+'")\'>Show all</a>';
	div.innerHTML = '<h6>Albums</h6><a class="clickable" onclick=\'SearchMore("albums","'+request.data.query+'")\'>Show all</a>';
	div.classList.add('group-header');
	cardContainer.appendChild(div);
	for (var i = 0; i < len; i++) {
	    var item = obj.albums.items[i];
	    img = item.cover;
    	    if (img == null) {
    		var link = 'icons/disc.svg';
    	    }
	    else {
    		img = img.replace(/-/g,'\/');
    		var link = 'https://resources.tidal.com/images/'+img+'/80x80.jpg';
    	    }
	    //id,title,artists[0].name,cover
	    var div = document.createElement('div');
	    div.innerHTML = '<div class="imgmini"><div class="item-wrapper"><a onclick=\'Tidal("play","album","'+item.id+'",event); return false;\' title="Play">'+
	    '<img class="lozad" src="icons/disc.svg" data-src="'+link+'">'+
	    '<div class="overlay">'+
                '<button class="btn material-icons shadow-none" type="button" role="button" title="Play">play_arrow</button>'+
	    '</div></a>'+
	    '</div></div>'+
	    '<div class="search-right">'+
	    '<span class="item-title clickable" onclick=\'appGoto("Tidal","page","album__' + item.id + '");\' title="'+item.title+'">'+item.title+'</span>'+
	    '<span class="item-title tart clickable" onclick=\'appGoto("Tidal","page","artist__' + item.artists[0].id + '");\' title="'+item.artists[0].name+'">'+item.artists[0].name+'</span>'+
	    '</div><hr>';
	    div.classList.add('search-res');
	    cardContainer.appendChild(div);
	}
	var div = document.createElement('hr');
	cardContainer.appendChild(div);
	}
    }
    if (obj.artists) {
	var len = obj.artists.items.length;
	b = len;
	if (len>0) {
	var div = document.createElement('div');
//	div.innerHTML = '<h6>Artists</h6><a class="clickable" onclick=\'QSearchMore("artists","'+request.data.query+'")\'>Show all</a>';
	div.innerHTML = '<h6>Artists</h6><a class="clickable" onclick=\'SearchMore("artists","'+request.data.query+'")\'>Show all</a>';
	div.classList.add('group-header');
	cardContainer.appendChild(div);
	for (var i = 0; i < len; i++) {
	    var item = obj.artists.items[i];
    	    img = item.picture;
    	    if (img == null) {
    		var link = 'icons/disc.svg';
    	    }
	    else {
    		img = img.replace(/-/g,'\/');
    		var link = 'https://resources.tidal.com/images/'+img+'/160x160.jpg';
    	    }
	//id,name,picture
	    var div = document.createElement('div');
	    div.innerHTML = '<div class="imgmini"><div class="artist-wrapper"><a onclick=\'appGoto("Tidal","page","artist__' + item.id + '");\'>'+
	    '<img class="lozad" src="icons/disc.svg" data-src="'+link+'">'+
	    '<div class="overlay">'+
	    '</div></a>'+
	    '</div></div>'+
	    '<div class="search-right">'+
	    '<span class="item-title clickable" onclick=\'appGoto("Tidal","page","artist__' + item.id + '");\' title="'+item.name+'">'+item.name+'</span>'+
	    '</div>';
	    div.classList.add('search-res');
	    cardContainer.appendChild(div);
	}
	var div = document.createElement('hr');
	cardContainer.appendChild(div);
	}
    }

    if (obj.playlists) {
	var len = obj.playlists.items.length;
	c = len;
	if (len>0){
	var div = document.createElement('div');
	div.innerHTML = '<h6>Playlists</h6><a class="clickable" onclick=\'SearchMore("playlists","'+request.data.query+'")\'>Show all</a>';
	div.classList.add('group-header');
	cardContainer.appendChild(div);
	for (var i = 0; i < len; i++) {
	    var item = obj.playlists.items[i];
	    //item.uuid, item.image, title
    	    img = item.squareImage;
    	    if (img == null) {
    		var link = 'icons/disc.svg';
    	    } else {
    		img = img.replace(/-/g,'\/');
    		var link = 'https://resources.tidal.com/images/'+img+'/160x160.jpg';
    	    }
	    var div = document.createElement('div');
	    div.innerHTML = '<div class="imgmini"><div class="item-wrapper"><a onclick=\'Tidal("play","playlist","'+item.uuid+'",event); return false;\'>'+
	    '<img class="lozad" src="icons/disc.svg" data-src="'+link+'">'+
	    '<div class="overlay">'+
                '<button class="btn material-icons shadow-none" type="button" role="button" title="Play">play_arrow</button>'+
	    '</div></a>'+
	    '</div></div>'+
	    '<div class="search-right">'+
	    '<span class="item-title clickable" onclick=\'appGoto("Tidal","page","playlist__' + item.uuid + '");\'>'+item.title+'</span>'+
	    '</div>';
	    div.classList.add('search-res');
	    cardContainer.appendChild(div);
	}
	var div = document.createElement('hr');
	cardContainer.appendChild(div);
	}
    }
    if (obj.tracks) {
	var len = obj.tracks.items.length;
	d = len;
	if (len>0) {

	var div = document.createElement('div');
	div.innerHTML = '<h6>Tracks</h6><a class="clickable" onclick=\'SearchMore("tracks","'+request.data.query+'")\'>Show all</a>';
	div.classList.add('group-header');
	cardContainer.appendChild(div);
	for (var i = 0; i < len; i++) {
	    var item = obj.tracks.items[i];
	    img =  item.album.cover;
	    if (img == null) {
		var link = 'icons/disc.svg';
	    } else {
    		img = img.replace(/-/g,'\/');
    		var link = 'https://resources.tidal.com/images/'+img+'/80x80.jpg';
    	    }
	    
	    var div = document.createElement('div');
	    div.innerHTML = '<div class="imgmini"><div class="item-wrapper"><a onclick=\'Tidal("play","track","'+item.id+'",event); return false;\'>'+
	    '<img class="lozad" src="icons/disc.svg" data-src="'+link+'">'+
	    '<div class="overlay">'+
                '<button class="btn material-icons shadow-none" type="button" role="button" title="Play">play_arrow</button>'+
	    '</div></a>'+
	    '</div></div>'+
	    '<div class="search-right">'+
	    '<span class="item-title clickable" onclick=\'Tidal("play","track","'+item.id+'",event); return false;\' title="'+item.title+'">'+item.title+'</span>'+
	    '<span class="item-title tart clickable" onclick=\'appGoto("Tidal","page","artist__' + item.artists[0].id + '");\' title="'+item.artists[0].name+'">'+item.artists[0].name+'</span>'+
	    '</div>';
	    div.classList.add('search-res');
	    cardContainer.appendChild(div);
	}
	}
    }
    if (a+b+c+d == 0) {
	cardContainer.innerHTML = '<p>Nothing found</p>';
    } else {
//    cardContainer.classList.remove('hide');
	observer.observe();
    }
    modalLoader.hide();
    modalSearch('show');
}

function openInfo(a) {
    var title = document.getElementById('radTitle');

    var cardContainer = document.getElementById('radInfo');
    cardContainer.innerHTML = "";

    var parent = a.parentNode;
    
    var pd = parent.getElementsByClassName('swiper-bio');
    var name = pd[0].getAttribute("data-name");
    title.innerHTML = name;

    var div = document.createElement('p');
    div.innerHTML = pd[0].innerHTML;
    cardContainer.appendChild(div);
    modalRadio.show();
}

function parseTidalAdd(obj, request){
var cardContainer = document.getElementById('Tidalpage');
var item;
var clas,cmd,icon,favtit;

    var len = obj.items.length;
    if ( len > 0 ) {

	var offset = parseInt(cardContainer.getAttribute('data-offset'));
	
	if (obj.items[0].trackNumber || obj.items[0].item.id) { //tracks 
	  var tbl = cardContainer.getElementsByClassName('tracklist')[0];

	  for (var j = 0; j < len; j++) { // add track to table
	    if (obj.items[0].item) {
		item = obj.items[j].item;
	    } else
		item = obj.items[j];
	    var cover = item.album.cover;
	    if (cover == null) {
		var link = 'icons/disc.svg'; 
	    }
	    else {
		cover = cover.replace(/-/g,'\/');
		var link = 'https://resources.tidal.com/images/' + cover + '/80x80.jpg';
	    }
	    var tr = document.createElement('li');
	    tr.classList.add('track-item');
	    tr.setAttribute('data-type','track');
	    tr.setAttribute('data-title',item.title);
	    tr.setAttribute('data-id',item.id);
	    tr.innerHTML = (app.current.tab == 'my' ? '<span class="track-cover">'+
	    '<div class="imgmini2">'+
	    '<div class="item-wrapper">'+
	    '<a class="clickable" onclick=\'Tidal("play","track","'+item.id+'",event); return false;\'>'+
	    '<img class="lozad" src="icons/disc.svg" data-src="'+link+'" width="50px" height="50px">'+
	    '<div class="overlay">'+
                '<button class="btn material-icons clickable" type="button" role="button" title="Play">play_arrow</button>'+
	    '</div>'+
	    '</a></div></div></span>' : '<span class="track-number">'+(offset+j+1)+'</span>')+
    	    '<div class="track-title-mobile">'+
	    '<span class="track-title"><a class="clickable" onclick=\'Tidal("play","track","'+item.id+'",event); return false;\' title="Play">'+item.title+'</a></span>'+
	    '<span class="track-artist"><a class="clickable" onclick=\'appGoto("Tidal","page","artist__'+item.artists[0].id+'");\'>'+item.artists[0].name+'</a></span>'+
	    '</div>'+
	    '<span class="track-album"><a class="clickable" onclick=\'appGoto("Tidal","page","album__'+item.album.id+'");\' title="'+item.album.title+'">'+item.album.title+'</a></span>'+
	    '<span class="track-duration">'+HHMMSS(item.duration)+'</span>'+
	    '<span class="track-fav"><a class="material-icons" onclick=\'Tidal("add","track","'+item.id+'",event); return false;\' title="Add to Queue">add</a></span>'+
	    '<span class="track-action"><a class="material-icons" onclick="showMenu2(this.parentNode,event);">more_vert</a></span>';
    	    tbl.appendChild(tr);
	  } //for
	} //trackNumber

	offset = offset + len;
	cardContainer.setAttribute('data-offset',offset);

	if (obj.items[0].uuid) { //playlists
	    var	div = cardContainer.getElementsByClassName('row')[0];
	    for (var j = 0; j < len; j++) {
	      item = obj.items[j];
	      var card = document.createElement('div');
    	      card.classList.add('grid-item');
    	      var img = item.squareImage;
	      if (img == null) {
    		var link = 'icons/disc.svg';
    	      }
	      else {
    		img = img.replace(/-/g,'\/');
    		var link = 'https://resources.tidal.com/images/'+img+'/160x160.jpg';
    	      }
	      icon = 'favorite_border';
    	      card.innerHTML = '<div class="card1">' +
                             ' <a class="clickable" data-type="playlist" data-id="'+item.uuid+'" onclick=\'appGoto("Tidal","page","playlist__'+item.uuid+'");\'>'+
                             ' <div class="item-wrapper">'+
                             ' <img class="lozad" src="icons/disc.svg" data-src="'+link+'" width="100%" height="100%" class="swiper-lazy">' +
                             ' <div class="overlay">'+
                             '     <button class="btn favbtn material-icons shadow-none" type="button" role="button" onclick=\'Tidalfav("playlist","'+item.uuid+'",event,this);\' title="">'+icon+'</button>'+
                             '     <button class="btn material-icons shadow-none" type="button" role="button" onclick=\'Tidal("play","playlist","'+item.uuid+'",event);\' title="Play">play_arrow</button>'+
                             '     <button class="btn material-icons shadow-none" type="button" role="button" onclick="showMenu2(this,event)" title="Show menu">more_vert</button>'+
                             ' </div></div></a>'+
                             ' <span class="item-title talb clickable" onclick=\'appGoto("Tidal","page","playlist__'+item.uuid+'");\' title="'+item.title+'">' + item.title + '</span>' +
                             '</div>'; 
    	      div.appendChild(card);
	    
	    } //for j=
	} // uuid
	
	if (obj.items[0].picture) { //artists
	  var div = cardContainer.getElementsByClassName('row')[0];
	  for (var j = 0; j < len; j++) {
	    item = obj.items[j];
	    var card = document.createElement('div');
    	    card.classList.add('grid-item');
    	    //item.cover
    	    var img = item.picture;
    	    if (img == null) {
    		var link = "icons/disc.svg";
    	    } else {
    		img = img.replace(/-/g,'\/');
    		var link = 'https://resources.tidal.com/images/' + img + '/160x160.jpg';
    	    }
	    icon = 'favorite_border';
    	    card.innerHTML = '<div class="card1">' +
                             ' <a class="clickable" data-type="artist" data-id="' + item.id + '" onclick=\'appGoto("Tidal","page","artist__' + item.id+'");\'>'+
                             ' <div class="artist-wrapper">'+
                             ' <img class="lozad" src="icons/disc.svg" data-src="'+link+'" width="100%" height="100%" class="swiper-lazy">' +
                             ' <div class="overlay">'+
                             '     <button class="btn favbtn  material-icons clickable" type="button" role="button" onclick=\'Tidalfav("artist","'+item.id+'",event,this);\' title="">'+icon+'</button>'+
                             ' </div></div></a>'+
                             '  <span class="item-title talb textcenter clickable" onclick=\'appGoto("Tidal","page","artist__' + item.id+'")\' title="'+item.name+'">' + item.name + '</span>' +
                             '</div>'; 
    	    div.appendChild(card);
	  } //for j=
	} //picture
	
	if (obj.items[0].cover) { //albums
	  var div = cardContainer.getElementsByClassName('row')[0];
	  for (var j = 0; j < len; j++) {
	    item = obj.items[j];
	    var card = document.createElement('div');
    	    card.classList.add('grid-item');
    	    
    	    var cover = item.cover;
    	    if (cover == null) {
    		var link = 'icons/disc.svg';
    	    } else {
    		cover = cover.replace(/-/g,'\/');
    		var link = 'https://resources.tidal.com/images/'+cover+'/160x160.jpg';
    	    }
	    icon = 'favorite_border';
    	    card.innerHTML = '<div class="card1">' +
                             (item.audioQuality == "HI_RES" ? ' <i class="hires material-icons">high_quality</i>' : '')+
                             ' <a class="clickable" data-type="album" data-id="'+item.id+'" onclick=\'appGoto("Tidal","page","album__'+item.id+'");\'>' +
                             ' <div class="item-wrapper">' +
                             ' <img class="lozad" src="icons/disc.svg" data-src="'+link+'" width="100%" height="100%" class="swiper-lazy">' +
                             ' <div class="overlay">' +
                             '     <button class="btn favbtn material-icons clickable" type="button" role="button" onclick=\'Tidalfav("album","'+item.id+'",event,this);\' title="">'+icon+'</button>'+
                             '     <button class="btn material-icons clickable" type="button" role="button" onclick=\'Tidal("play","album","'+item.id+'",event);\' title="Play">play_arrow</button>' +
                             '     <button class="btn material-icons clickable" type="button" role="button" onclick="showMenu2(this,event)" title="Show menu">more_vert</button>' +
                             ' </div>'+
                             '</div>'+
                             '</a>'+
                             '  <span class="item-title talb clickable" onclick=\'appGoto("Tidal","page","album__'+item.id+'");\' title="'+item.title+'">' + item.title + '</span>' +
                             '  <span class="item-title tart clickable" onclick=\'appGoto("Tidal","page","artist__'+item.artists[0].id+'");\' title="'+item.artists[0].name+'">' + item.artists[0].name + '</span>' +
                             '</div>';
    	    div.appendChild(card);
	  } //for
	} //cover
    }
    observer.observe();
    modalLoader.hide();
    scrollFlag = false;
}

function parsePlists(obj, request){
//var img;
var clas, icon, favtit;
    var len = obj.groups.length;
    var cardContainer = document.getElementById('Tidalplists');
    cardContainer.innerHTML = '';
    if (!phone)
	document.getElementById('topTitle').innerHTML = 'History'
    else
	document.getElementById('topTitle').innerHTML = '<i class="material-icons">date_range</i>';

    cardContainer.classList.remove('hide');
    
    for (var i = 0; i < len; i++){
	//header
	var header = document.createElement('div');
	var title = obj.groups[i].group;
	var str = '<h5>'+title+'</h5>';

	header.innerHTML = str;
	header.classList.add('group-header');
	cardContainer.appendChild(header);

	var len2 = obj.groups[i].items.length;
	if (phone && obj.groups[i].type != 'list') {
	    var div2 = document.createElement('ul');
    	    div2.classList.add('pl-0');
	} else {
	    var div2 = document.createElement('div');
    	    div2.classList.add('row');
    	}

        for (var j = 0; j < len2; j++){
        //body
              var item = obj.groups[i].items[j];
	      if (obj.groups[i].type == 'list') {
	        var card = document.createElement('div'); 
	        card.classList.add('year-cloud');
	        card.innerHTML = '' +
                             ' <a class="clickable" onclick=\'appGoto("Tidal","page","playlist__'+item.uuid+'");\'>'+
                             '  <span class="cloud-title talb">' + item.title + '</span>' +
                             '</a>'; 

    	        div2.appendChild(card);

	      } else {

    	        if (phone) {
	    	    var card = document.createElement('li'); 
	    	    card.classList.add('w100');
	    	    card.style.display = 'flex';
	    	}
	    	else {
	    	    var card = document.createElement('div'); 
	    	    card.classList.add('grid-small');
	    	}
    	     
    	        var img = item.cover;
	        if (img == null) {
    		  var link = 'icons/disc.svg';
    	        }
	        else {
	    	  if (img.indexOf('jpg')==-1) {
    		    img = img.replace(/-/g,'\/');
    		    var link = 'https://resources.tidal.com/images/'+img + '/160x160.jpg';// (phone ? '/80x80.jpg' : '/160x160.jpg');
    		  } else var link = img;
    	        }
		if (phone) {
    	    	    card.innerHTML = ' <a class="clickable" onclick=\'appGoto("Tidal","page","playlist__'+item.uuid+'");\'>'+
                             ' <img src="icons/disc.svg" data-src="'+link+'" width="80px" height="80px" class="lozad"></a>' +
			     ' <div class="ml-4 mr-2">'+
                             ' <span class="title talb clickable" onclick=\'appGoto("Tidal","page","playlist__'+item.uuid+'");\' title="'+item.title+'">' + item.title + '</span>'+
        		     ' </div>'; 
		
		} else {
		    icon = 'favorite_border';
    	    	    card.innerHTML = '<div class="card1">' +
                             ' <a class="clickable" data-type="playlist" data-id="'+item.uuid+'" onclick=\'appGoto("Tidal","page","playlist__'+item.uuid+'");\'>'+
                             ' <div class="item-wrapper">'+
                             ' <img src="icons/disc.svg" data-src="'+link+'" width="100%" height="100%" ' +
                             'class="lozad">' +
                             ' <div class="overlay">'+
                             '     <button class="btn favbtn material-icons clickable" type="button" role="button" onclick=\'Tidalfav("playlist","'+item.uuid+'",event,this);\' title="">'+icon+'</button>'+
                             '     <button class="btn material-icons clickable" type="button" role="button" onclick=\'Tidal("play","playlist","'+item.uuid+'",event);\' title="Play">play_arrow</button>'+
                             '     <button class="btn material-icons clickable" type="button" role="button" onclick="showMenu2(this,event)" title="Show menu">more_vert</button>'+
                             ' </div></div></a>'+
                             ' <span class="talb clickable" onclick=\'appGoto("Tidal","page","playlist__'+item.uuid+'");\' title="'+item.title+'">' + item.title + '</span>' +
                             '</div>'; 
                }
    	        div2.appendChild(card);
          }
        }
        cardContainer.appendChild(div2);
    }
    observer.observe();
    modalLoader.hide();
}

function parseTWGEEMA(obj, request){
//var img;
var clas, icon, favtit;
    var len = obj.length;
    var cardContainer = document.getElementById('Tidaltwgeema');
    if (!phone)
	document.getElementById('topTitle').innerHTML = 'TWGEEMA'
    else
	document.getElementById('topTitle').innerHTML = '<i class="material-icons">track_changes</i>';
    cardContainer.innerHTML = '';
    cardContainer.classList.remove('hide');
    if (request.data.id) {
	var header = document.createElement('div');
//	var title = obj[i].name;
	var str = '<h5>' + obj.name + '</h5>';'<p>' + obj.desc + '</p>';

	header.innerHTML = str;
	header.classList.add('group-header');
	cardContainer.appendChild(header);
	var p = document.createElement('p');
	p.innerHTML = obj.desc;
	cardContainer.appendChild(p);
	
	var div2 = document.createElement('div');
	div2.classList.add('row');
	cardContainer.appendChild(div2);
	
	var len = obj.items.length;
        for (var i = 0; i < len; i++){
	    item = obj.items[i];
	    var card = document.createElement('div'); 
	    card.classList.add('grid-item');
	    var cover= item.cover;
	    if (cover == "null" || cover == "") {
		var link = 'icons/disc.svg';
	    } else {
    		var link = cover.replace(/-/g,'\/');
    		link = 'https://resources.tidal.com/images/' + link + '/320x320.jpg';
    	    }
    	    var rdate = item.release;
	    rdate = rdate.split("-")[0];
	    var title = item.title +' (' + rdate +')';

    	    var str =  '<div class="card1">'+
        	       ' <a class="clickable" data-type="album" data-id="' + item.id + '" onclick=\'appGoto("Tidal","page","album__' + item.id+'");\'>'+
                             ' <div class="item-wrapper">' +
                             ' <img class="lozad" src="icons/disc.svg" data-src="'+link+'" width="100%" height="100%" class="swiper-lazy">' +
                             ' <div class="overlay">';
	    icon = 'favorite_border';
    	    str +=   '     <button class="btn favbtn material-icons shadow-none" type="button" role="button" onclick=\'Tidalfav("album","'+item.id+'",event,this);\' title="">'+icon+'</button>'+
                             '     <button class="btn material-icons shadow-none" type="button" role="button" onclick=\'Tidal("play","album","'+item.id+'",event);\' title="Play">play_arrow</button>' +
                             '     <button class="btn material-icons shadow-none" type="button" role="button" onclick="showMenu2(this,event)" title="Show menu">more_vert</button>';
            str +=           ' </div></div></a>'+
                             '  <span class="item-title talb clickable" onclick=\'appGoto("Tidal","page","album__'+ item.id+'")\' title="'+title+'">' + title + '</span>'+
                             '  <span class="item-title tart clickable" onclick=\'appGoto("Tidal","page","artist__' + item.artid+'")\' title="'+item.artist+'">' + item.artist + '</span>'+
                             '</div>'; 
	    card.innerHTML = str;
	    div2.appendChild(card);
	}
	var bmenu = document.createElement('div');
	bmenu.innerHTML = '<div class="btn-group" role="group">'+
	    (obj.prev ? '<button type="button" class="btn btn-outline-light" onclick=\'appGoto("Tidal","page","twgeema__' + obj.prev+'");\'>'+obj.prevText+'</button>':'')+
	    (obj.next || obj.prev ? '<button type="button" class="btn btn-outline-light" onclick=\'appGoto("Tidal","page","twgeema");\'>INDEX</button>':'')+
	    (obj.next ? '<button type="button" class="btn btn-outline-light" onclick=\'appGoto("Tidal","page","twgeema__' + obj.next+'");\'>'+obj.nextText+'</button>':'') + '</div>';
	bmenu.classList.add('text-center');
	cardContainer.appendChild(bmenu);
	
    }
    else {
      var header = document.createElement('p');
      header.innerHTML = "Welcome to TWGEEMA – The World's Greatest Ever Electronic Music Albums, home of the world's greatest ever Electronic Music albums chart."+
	"TWGEEMA began and still exists as a group on Facebook, with members from around the world. Among them are many experts in the field of Electronic Music, including music producers, DJs, and record label bosses. Some are names that even the less knowledgeable Electronic Music enthusiast would recognize.";
      cardContainer.appendChild(header);
      for (var i = 0; i < len; i++){
	//header
	var header = document.createElement('div');
//	var title = obj[i].name;
	var str = '<h5>'+obj[i].name+'</h5>';

	header.innerHTML = str;
	header.classList.add('group-header');
	cardContainer.appendChild(header);

	var len2 = obj[i].groups.length;
//	if (phone && obj.groups[i].type != 'list') {
//	    var div2 = document.createElement('ul');
//    	    div2.classList.add('pl-0');
//	} else {
	    var div2 = document.createElement('div');
    	    div2.classList.add('row');
//    	}

        for (var j = 0; j < len2; j++){
        //body
            var item = obj[i].groups[j];
	    var card = document.createElement('div'); 
	    card.classList.add('year-cloud');
	    var t = (item.slug == null ? item.name : item.slug);
	    card.innerHTML = '' +
                             ' <a class="clickable" onclick=\'appGoto("Tidal","page","twgeema__'+item.group+'");\'>'+
                             '  <span class="cloud-title talb">' + t + '</span>' +
                             '</a>'; 

    	    div2.appendChild(card);

        }
        cardContainer.appendChild(div2);
      }
    }
    observer.observe();
    modalLoader.hide();
}


function parseDDD(obj, request){
var len = 0;
var item;
var fl;
var clas, icon, favtit;
var prevelem = '';
    document.getElementById('Tidalddd').classList.remove('hide');
    var cardContainer = document.getElementById('Tidaldddbody');
    cardContainer.innerHTML = '';
    if (!phone)
	document.getElementById('topTitle').innerHTML = 'Digital Dream'
    else
	document.getElementById('topTitle').innerHTML = '<i class="material-icon>flare</i>';

    if (obj.groups) {
      var header = document.createElement('p');
      header.innerHTML = "Digital Dream Door - the list you will find here are created by knowledgeable people and visitors dedicated to"+
	" the best possible rankings of songs, albums, musicians & musical artists of Rock, Blues, Jaz, Classical and their sub-genres and offshoots.";
      cardContainer.appendChild(header);

      len = obj.groups.length;
      for (var i = 0; i < len; i++){
	item = obj.groups[i];
	if (item.id == 'divider') {
	    if (prevelem == 'item') cardContainer.appendChild(div0);
	    if (item.name) {
		var dv = document.createElement('div');
		dv.classList.add('group-header');
		dv.innerHTML = '<h5>'+item.name+'</h5>';
		cardContainer.appendChild(dv);
	    }
	    continue;
	}
	if (item.subgroups) {
	    // create block
//	    console.log('group');
	    if (prevelem == 'item' || prevelem == '') {
		if (i>0) cardContainer.appendChild(div0);
		var div0 = document.createElement('div');
	    }
	    var elem = document.createElement('div');
	    elem.classList.add('w100');
	    elem.innerHTML = '<span class="cloud-title">'+item.name+'</span>';
	    cardContainer.appendChild(elem);
	    prevelem = 'group';
	} else {
//	    console.log('item');
	    if (prevelem == 'group' || prevelem == '') {
    		var div0 = document.createElement('ul');
    		div0.classList.add('playlistbox');
    	    }
    	    var elem = document.createElement('li');
	    elem.classList.add('list-group-item');
	    elem.innerHTML = '<a class="clickable" onclick=\'appGoto("Tidal","page","ddd__'+item.id+'");\'><span class="cloud-title">'+item.name+'</span></a>';
	    div0.appendChild(elem);
	    prevelem = 'item';
	}

	if (item.subgroups) {
	    fl = false;
	    var s = item.name;
	    if (s.indexOf(" Year")!==-1 || s.indexOf(" Decade")!==-1) fl = true;
	    if (fl) {
		var div2 = document.createElement('div');
		div2.classList.add('row');
	    }
	    else {
		var div2 = document.createElement('ul');
		div2.classList.add('playlistbox');
		div2.classList.add('ml-4');
	    }
	    var len2 = item.subgroups.length;
	    for (var j = 0; j < len2; j++) { 
//		var type = 'albums';
		var item2 = item.subgroups[j];
	        var card = document.createElement((fl ? 'div' : 'li')); 
	        if (fl) { card.classList.add('year-cloud');} else { card.classList.add('list-group-item'); }
	        card.innerHTML = '<a class="clickable" onclick=\'appGoto("Tidal","page","ddd__'+item2.id+'");\'><span class="cloud-title" title="'+item2.desc+'">'+item2.name+'</span></a>';
		div2.appendChild(card);
	    }
	    cardContainer.appendChild(div2);
//	    div0.appendChild(div2);
	}
	
      }
      cardContainer.appendChild(div0);
      
    } 
    else {
	len = obj.items.length;
        var div = document.createElement('div');
        div.classList.add('card-header');
        var str = (obj.desc ? obj.desc : obj.name);
	document.getElementById('topTitle').innerHTML = 'Digital Dream: '+str ;
        div.innerHTML = '<h5>' + str + '</h5>';
        cardContainer.appendChild(div);
        if (obj.type == 'albums' || obj.type == 'artists') {
          var div2 = document.createElement('div');
          div2.classList.add('row');
    	  if (phone) div2.classList.add('phone');
          cardContainer.appendChild(div2);
          for (var i = 0; i < len; i++){
	    item = obj.items[i];
	    var card = document.createElement('div'); 
	    card.classList.add('grid-item');
	    var cover= item.cover;
	    if (cover == "null" || cover == "") {
		var link = 'icons/disc.svg';
	    } else {
    		var link = cover.replace(/-/g,'\/');
    		link = 'https://resources.tidal.com/images/' + link + '/320x320.jpg';
    	    }
    	    var str =  '<div class="card1">'+
        	       ' <a class="clickable" data-type="'+ (obj.type == 'albums'? 'album':'artist') + '" data-id="' + (obj.type == 'albums' ? item.albid : item.id) + '"'+ (obj.type == 'albums' ? ' onclick=\'appGoto("Tidal","page","album__' + item.albid+'");\'>' : ' onclick=\'appGoto("Tidal","page","artist__' + item.id+'");\'>')+
                             ' <div class="'+(obj.type == 'albums' ? 'item':'artist')+'-wrapper">' +
                             ' <img class="lozad" src="icons/disc.svg" data-src="'+link+'" width="100%" height="100%" class="swiper-lazy">' +
                             ' <div class="overlay">';
	    icon = 'favorite_border';
            if (obj.type == 'albums'){ 
        	    str +=   '     <button class="btn favbtn material-icons shadow-none" type="button" role="button" onclick=\'Tidalfav("album","'+item.albid+'",event,this);\' title="">'+icon+'</button>'+
                             '     <button class="btn material-icons shadow-none" type="button" role="button" onclick=\'Tidal("play","album","'+item.albid+'",event);\' title="Play">play_arrow</button>' +
                             '     <button class="btn material-icons shadow-none" type="button" role="button" onclick="showMenu2(this,event)" title="Show menu">more_vert</button>';
            }
            else {
        	str +=  '     <button class="btn favbtn material-icons shadow-none" type="button" role="button" onclick=\'Tidalfav("artist","'+item.id+'",event,this);\' title="">'+icon+'</button>';
            }
            str +=           ' </div></div></a>'+
                             (obj.type == 'albums' ? '  <span class="item-title talb clickable" onclick=\'appGoto("Tidal","page","album__'+ item.albid+'")\' title="'+item.album+'">' + item.album + '</span>' : '')+
                             '  <span class="item-title '+(obj.type == 'albums' ? 'tart' : 'talb')+' clickable" onclick=\'appGoto("Tidal","page","artist__' + (obj.type == 'albums' ? item.artid : item.id)+'")\' title="'+item.artist+'">' + item.artist + '</span>'+
                             '</div>'; 
	    card.innerHTML = str;
	    div2.appendChild(card);
	  }
        }
        if (obj.type == 'tracks') {
    	    var covers = false;
    	    if (str.indexOf('Cover Songs')!==-1 || str.indexOf('Double-Sided')!==-1) covers = true;
	    var div = document.createElement('div');

    	    div.innerHTML = '<div class="header-controls">'+
		'<button class="btn play material-icons" type="button" role="button" onclick=\'Tidal("play","ddplaylist","'+obj.id+'",event);\' title="Play">play_arrow</button>'+
	     '</div>';
    	    cardContainer.appendChild(div);

	    var tbl = document.createElement('ul');
    	    var tr = document.createElement('li');
    	    tr.innerHTML = '<span class="track-cover"></span>'+
	    '<div class="track-title-mobile">'+
    	    '<span class="track-title">Title</span><span class="track-artist">Artist</span>'+
    	    '</div>'+
//    	    '<span class="track-artist">Album</span>'+
    	    '<span class="track-duration">Time</span>'+
    	    '<span class="track-fav"></span>'+
    	    '<span class="track-action"></span>';
    	    tr.classList.add('tracklist-label');
    	    tbl.appendChild(tr);
    	    var oldnum = 0;
	    for (var j = 0; j < len; j++) {
		var item = obj.items[j];
		if (covers && j>0) {
		    if (item.num != oldnum) {
			var hr = document.createElement('hr');
//			hr.classList.add('divider');
    			tbl.appendChild(hr);
		    }
		}
		var tr = document.createElement('li');
		var cover = item.cover;
		if (cover == "null") {
		    var link = 'icons/disc.svg';
		} else {
    		    cover = cover.replace(/-/g,'\/');
    		    var link = 'https://resources.tidal.com/images/' + cover + '/80x80.jpg';
    		}
		tr.classList.add('track-item');
		tr.setAttribute('data-type','track');
		tr.setAttribute('data-title',item.title);
		tr.setAttribute('data-id',item.id);
		tr.innerHTML = '<span class="track-cover">'+
		'<div class="imgmini2">'+
		'<div class="item-wrapper">'+
		'<a class="clickable" data-type="track" data-id="'+item.id+'" onclick=\'Tidal("play","track","'+item.id+'",event); return false\' title="Play">'+
		'<img class="lozad" src="icons/disc.svg" data-src="'+link+'">'+
		'<div class="overlay">'+
            	    '<button class="btn material-icons shadow-none" type="button" role="button">play_arrow</button>'+
		'</div></a></div></div></span>'+
		'<div class="track-title-mobile">'+
		'<span class="track-title"><a class="clickable" onclick=\'Tidal("play","track","'+item.id+'",event); return false\' title="' + item.title + '">' + item.title + '</a></span>' +
		'<span class="track-artist"><a class="clickable" onclick=\'appGoto("Tidal","page","artist__' + item.artid + '");\' title="' + item.artist + '">' + item.artist + '</a></span>' +
		'</div>'+
//		'<span class="track-album"><a class="clickable" onclick=\'appGoto("Tidal","page","album__' + item.albid + '");\' title="' + item.album + '">' + item.album + '</a></span>' +
		'<span class="track-duration">' + (item.duration ? HHMMSS(item.duration):'0:00') + '</span>'+
	    	'<span class="track-fav">'+(item.id == 0 ? '':'<a class="clickable material-icons" onclick=\'Tidal("add","track","'+item.id+'",event);return false;\' title="Add to Queue">add</a>')+'</span>'+
		'<span class="track-action"><a class="clickable material-icons" onclick="showMenu2(this.parentNode,event);" title="Show menu">more_vert</a></span>';
    		tbl.appendChild(tr);
    		oldnum = item.num;
	    }
	    tbl.classList.add('tracklist');
    	    cardContainer.appendChild(tbl);
          
        }
    }
    observer.observe();
    modalLoader.hide();
}

function parseApple(obj, request){
var len = 0;
    document.getElementById('Tidalapple').classList.remove('hide');
    
    var header = document.getElementById('Tidalappleheader');
    var cardContainer = document.getElementById('Tidalapplebody');
    cardContainer.innerHTML = '';
    header.innerHTML = '';
    if (!phone)
	document.getElementById('topTitle').innerHTML = 'Apple Music'
    else
	document.getElementById('topTitle').innerHTML = '<i class="material-icons">center_focus_weak</i>';
    if (obj.ModDate) {
// playlist
        var img = obj.img;
    	if (img == "null") {
    	  img = 'icons/disc.svg';
    	} else {
	  img = img.replace(/{w}/g,'240');
    	  img = img.replace(/{h}/g,'240');
    	}
	len = obj.items.length;
	var tim = 0 ;
	if (len>0) {
	  if (obj.items[0].duration) {
	  for (var j = 0; j < len; j++) {
	    tim += parseInt(obj.items[j].duration);
	  }
	  }
	}
    	if (phone) {
    	    header.innerHTML=' <div style="width:30%">'+
	    '<img src="'+img+'" width="100%">'+
	    '<div class="header-controls ml-4">'+
		'<button class="btn play material-icons" type="button" role="button" onclick=\'Tidal("play","aplaylist","'+obj.id+'",event)\' title="Play">play_arrow</button>'+
	     '</div>'+
	    '</div>'+
	    '<div class="artist-text ml-4"><h2>'+obj.name+'</h2>'+
	    '<div class="bio">'+(obj.desc == "null" ? '':obj.desc)+'</div>'+
	    '<div>'+len+' tracks - '+ HHMMSS(tim);
	    '</div>';
    	} else {
    	    header.innerHTML=' <div class="grid-item"><div class="wrapper">'+
	    '<img src="'+img+'" width="100%"></div></div>'+
	    '<div class="artist-text"><h2>'+obj.name+'</h2>'+
	    '<div class="bio">'+(obj.desc == "null" ? '' : obj.desc)+'</div>'+
	    '<div>'+len+' tracks - '+ HHMMSS(tim);
	    '<div class="header-controls">'+
		'<button class="btn play material-icons" type="button" role="button" onclick=\'Tidal("play","aplaylist","'+obj.id+'",event);\' title="Play">play_arrow</button>'+
	     '</div>'+
	    '</div>';
	}
	var tbl = document.createElement('ul');
    	var tr = document.createElement('li');
    	tr.innerHTML = '<span class="track-cover"></span>'+
	'<div class="track-title-mobile">'+
    	'<span class="track-title">Title</span><span class="track-artist">Artist</span>'+
    	'</div>'+
    	'<span class="track-artist">Album</span><span class="track-duration">Time</span>'+
    	'<span class="track-fav"></span>'+
    	'<span class="track-action"></span>'
    	tr.classList.add('tracklist-label');
    	tbl.appendChild(tr);
	for (var j = 0; j < len; j++) {
	    var item = obj.items[j];
	    var tr = document.createElement('li');
	    var cover = item.cover;
	    if (cover == "null") {
		var link = 'icons/disc.svg';
	    } else {
    		cover = cover.replace(/-/g,'\/');
    		var link = 'https://resources.tidal.com/images/' + cover + '/80x80.jpg';
    	    }
	    tr.classList.add('track-item');
	    tr.setAttribute('data-type','track');
	    tr.setAttribute('data-title',item.title);
	    tr.setAttribute('data-id',item.id);
	    tr.innerHTML = '<span class="track-cover">'+
	    '<div class="imgmini2">'+
	    '<div class="item-wrapper">'+
	    '<a class="clickable" data-type="track" data-id="'+item.id+'" onclick=\'Tidal("play","track","'+item.id+'",event); return false\' title="Play">'+
	    '<img class="lozad" src="icons/disc.svg" data-src="'+link+'" width="50px" height="50px">'+
	    '<div class="overlay">'+
                '<button class="btn material-icons shadow-none" type="button" role="button">play_arrow</button>'+
	    '</div>'+
	    '</a></div></div></span>'+
	    '<div class="track-title-mobile">'+
	    '<span class="track-title"><a class="clickable" onclick=\'Tidal("play","track","'+item.id+'",event); return false\' title="' + item.title + '">' + item.title + '</a></span>' +
	    '<span class="track-artist"><a class="clickable" onclick=\'appGoto("Tidal","page","artist__' + item.artid + '");\' title="' + item.artist + '">' + item.artist + '</a></span>' +
	    '</div>'+
	    '<span class="track-album"><a class="clickable" onclick=\'appGoto("Tidal","page","album__' + item.albid + '");\' title="' + item.album + '">' + item.album + '</a></span>' +
	    '<span class="track-duration">' + (item.duration ? HHMMSS(item.duration):'&nbsp;') + '</span>'+
	    '<span class="track-fav"><a class="clickable material-icons" onclick=\'Tidal("add","track","'+item.id+'",event); return false;\' title="Add to Queue">add</a></span>'+
	    '<span class="track-action"><a class="clickable material-icons" onclick="showMenu2(this.parentNode,event);" title="Show menu">more_vert</a></span>';
    	    tbl.appendChild(tr);
	}
	tbl.classList.add('tracklist');
        cardContainer.appendChild(tbl);
    }
    else if (request.data.id) {
//header  .curator,.notes,.img
//        var div = document.createElement('div');
        var img = obj.img;
    	if (img == "null") {
    	  img = 'icons/disc.svg';
	} else {
	    img = img.replace(/{w}/g,'240');
    	    img = img.replace(/{h}/g,'240');
    	}
    	if (phone){
    	    var div2 = document.createElement('ul');
    	    div2.classList.add('pl-0');
    	    header.innerHTML=' <div style="width:30%"><div class="artist-wrapper">'+
	    '<img src="'+img+'" width="100%"></div></div>'+
	    '<div class="artist-text"><h2>'+obj.curator+'</h2>'+
	    '<p>'+(obj.notes == "null" ? '': obj.notes)+'</p>'+
	    '</div>';
	}
    	else {
    	    header.innerHTML=' <div class="grid-item"><div class="artist-wrapper">'+
	    '<img src="'+img+'" width="100%"></div></div>'+
	    '<div class="artist-text"><h2>'+obj.curator+'</h2>'+
	    '<p>'+(obj.notes == "null" ? '': obj.notes)+'</p>'+
	    '</div>';
	}
//	header.appendChild(div);
	
	len = obj.playlists.length;
	for (var j = 0; j < len; j++) {
	    var item = obj.playlists[j];
//	    card = document.createElement('div');
//    		card.classList.add('my-item');
    	    if (phone) {
		var card = document.createElement('li');
    		card.classList.add('w100');
    		card.classList.add('mb-2');
    		card.style.display = 'flex';
    	    } else {
		var card = document.createElement('div');
    		card.classList.add('grid-small');
//    		card.classList.add('my-item');
    	    }
    	    var img = item.img;
    	    if (img == "null") {
    		img = 'icons/disc.svg';
    	    }
	    else {
	    	img = img.replace(/{w}/g,'240');
    		img = img.replace(/{h}/g,'240');
    	    }
	    if (phone) {

    		card.innerHTML = ' <a class="clickable" data-type="playlist" data-id="'+item.id+'" data-name="' + item.name + '" onclick=\'appGoto("Tidal","page","aplaylist__'+ item.id+'");\'>'+
                             ' <img class="lozad pl-1" src="icons/disc.svg" data-src="'+img+'" width="80px" height="80px" class="swiper-lazy"></a>' +
                             '<div class="ml-2 mr-4">'+
                             '  <span class="title talb clickable" title="'+item.name+'" onclick=\'appGoto("Tidal","page","aplaylist__'+ item.id+'");\'>' + item.name + '</span>' +
                             '</div>'; 
	    } else {
    		card.innerHTML = '<div class="card1">' +
                             ' <a class="clickable" data-type="playlist" data-id="'+item.id+'" data-name="' + item.name + '" onclick=\'appGoto("Tidal","page","aplaylist__'+ item.id+'");\'>'+
                             ' <div class="item-wrapper">'+
                             ' <img class="lozad" src="icons/disc.svg" data-src="'+img+'" width="100%" height="100%" class="swiper-lazy">' +
                             ' <div class="overlay">'+
                             '     <button class="btn material-icons shadow-none" type="button" role="button" onclick=\'Tidal("play","aplaylist","'+ item.id+'",event);\' title="Play">play_arrow</button>'+
                             ' </div></div></a>'+
                             '  <span class="talb clickable" title="'+item.name+'" onclick=\'appGoto("Tidal","page","aplaylist__'+ item.id+'");\'>' + item.name + '</span>' +
                             '</div>'; 
            }
    	    if (phone) {div2.appendChild(card);} else {cardContainer.appendChild(card);}
	}
	if (phone) cardContainer.appendChild(div2);
    } else {
	if (phone) {
	    var div2 =  document.createElement('ul');
    	    div2.classList.add('pl-0'); 
	}
        var len = obj.items.length;
	for (var j = 0; j < len; j++) {
	    var item = obj.items[j];
    	    if (phone) {
		var card = document.createElement('li');
    		card.classList.add('w100'); 
	    	card.style.display = 'flex';
//    		card.classList.add('mb-2');
    	    } else {
		var card = document.createElement('div');
    		card.classList.add('grid-item'); 
    	    }
    	    
    	    //item.cover
    	    var img = item.img;
    	    if (img == "null") {
    		img = "icons/disc.svg";
    	    } else {
    		img = img.replace(/{w}/g,'240');
    		img = img.replace(/{h}/g,'240');
    	    }
    	    if (phone) {
    		card.innerHTML = '<a class="clickable" onclick=\'appGoto("Tidal","page","apple__' + item.id+'");\'>'+
    			    '<img class="lozad pl-1" src="icons/disc.svg" data-src="'+img+'" width="80px" height="80px" class="swiper-lazy"></a>' +
    			    '<div class="ml-2">'+
                             '  <span class="item-title talb textcenter clickable" onclick=\'appGoto("Tidal","page","apple__' + item.id+'")\' title="'+item.name+'">' + item.name + '</span>' +
                             '</div>'; 
    			    
    	    } else {
    		card.innerHTML = '<div class="card1 pad20" id="cardTA' + item.id + '">' +
                             ' <a class="clickable" data-type="artist" data-id="' + item.id + '" onclick=\'appGoto("Tidal","page","apple__' + item.id+'");\'>'+
                             ' <div class="artist-wrapper">'+
                             ' <img class="lozad" src="icons/disc.svg" data-src="'+img+'" width="100%" height="100%" class="swiper-lazy">' +
                             ' <div class="overlay">'+
                             ' </div></div></a>'+
                             '  <span class="item-title talb textcenter clickable" onclick=\'appGoto("Tidal","page","apple__' + item.id+'")\' title="'+item.name+'">' + item.name + '</span>' +
                             '</div>'; 
            }
            if (phone) { 
        	div2.appendChild(card); 
    	    } else {
    		cardContainer.appendChild(card);
    	    }
	}
        if (phone) { 
    	    cardContainer.appendChild(div2);
	}
    }
    observer.observe();
    modalLoader.hide();
}

function parseTidalECM(obj, request){
var page = request.data.page;
var clas, icon, favtit;
    if (page == 'ecm') {
	if (!phone)
	    document.getElementById('topTitle').innerHTML = 'ECM Label catalog'
	else
	    document.getElementById('topTitle').innerHTML = '<i class="material-icons">label</i>';
//	var years = ["2010","2000","1990","1980","1970","1960"];
	var cardContainer = document.getElementById('Tidalecmbody');
	if (phone) document.getElementById('ecmYears').parentNode.classList.add('phone');
	document.getElementById('Tidaldaaudio').classList.add('hide');
	document.getElementById('Tidalecm').classList.remove('hide');
    }
    if (page == '1001') {
	if (!phone)
	    document.getElementById('topTitle').innerHTML = '1001 Albums You Must Hear Before...'
	else
	    document.getElementById('topTitle').innerHTML = '<i class="material-icons">pan_tool</i>';
//	var years = ["2000s","1990s","1980s","1970s","1960s","1950s"];
	var cardContainer = document.getElementById('Tidal1001body');
	if (phone) document.getElementById('a1001Years').parentNode.classList.add('phone');
	document.getElementById('Tidal1001').classList.remove('hide');
    }
    if (page == 'daaudio') {
	if (!phone) 
	    document.getElementById('topTitle').innerHTML = 'Dastereo user choice...'
	else
	    document.getElementById('topTitle').innerHTML = '<i class="material-icons">thumb_up</i>';
	
	var cardContainer = document.getElementById('Tidaldabody');
	document.getElementById('Tidalecm').classList.add('hide');
	document.getElementById('Tidaldaaudio').classList.remove('hide');
//	cardContainer.parentNode.classList.remove('hide');
    }
    if (phone) cardContainer.classList.add('phone');

/*  if (cardContainer.getElementsByTagName('div').length == 0) {
    modalLoader.hide();
  }*/
  if (obj.length) {
    var len = obj.length;
    if (len > 0) {
	if (request.data.offset == 0) {
    	    while (cardContainer.firstChild) {
    		cardContainer.removeChild(cardContainer.firstChild);
    	    };
	    cardContainer.setAttribute('data-offset',len);

	    var div = document.createElement('div');
    	    div.classList.add('row');
    	    if (phone) div.classList.add('phone');
	} else {
	    var div = cardContainer.getElementsByClassName('row')[0];
	    var offset = parseInt(cardContainer.getAttribute('data-offset'));
	    offset = offset + len;
	    cardContainer.setAttribute('data-offset',offset);
	}

	for (var j = 0; j < len; j++) {
	    var item = obj[j];
	    if (!obj[j].id == 0) {
	      var card = document.createElement('div');
    	      card.classList.add('grid-item');
    	    
	      if (page == 'ecm') {
    	        var rdate = obj[j].releaseDate;
    	        var rdate = rdate.substring(0,rdate.indexOf('-'));
    	      }
    	      var cover = item.cover;
    	      if (cover == null) {
    		var link = 'icons/disc.svg';
    	      } else {
    		cover = cover.replace(/-/g,'\/');
    		var link = 'https://resources.tidal.com/images/'+cover+'/160x160.jpg';
    	      }
	      icon = 'favorite_border';
	      var str = '<div class="card1">' +
//                   (item.audioQuality == "HI_RES" ? ' <i class="hires material-icons">high_quality</i>' : '')+
                    ' <a class="clickable" data-type="album" data-id="'+item.id+'" onclick=\'appGoto("Tidal","page","album__'+item.id+'");\'>' +
                    ' <div class="item-wrapper">' +
                    ' <img class="lozad" src="icons/disc.svg" data-src="'+link+'" width="100%" height="100%" class="swiper-lazy">';
	      if (phone)
    		str +=  ' <div class="aplay">'+
                        '     <button class="btn material-icons shadow-none" type="button" role="button" onclick=\'Tidal("play","album","'+item.id+'",event);\' title="Play">play_arrow</button>' +
                        ' </div>'+
        		'</div></a>'+
                        '<div class="card-tit">'+
                        ' <div>'+
                        '  <span class="item-title talb clickable" title="'+item.album+'" onclick=\'appGoto("Tidal","page","album__'+item.id+'");\'>' + item.album + '</span>' +
                        '  <span class="item-title tart' + (page == 'ecm' ? '' : ' clickable') +'" title="'+item.artist+'" '+(page == 'ecm' ? '':'onclick=\'appGoto("Tidal","page","artist__' + item.artid+'");\'')+'>' + item.artist + '</span>' +
                             (page == 'ecm' ? '  <span class="item-title tart">' + item.catId + ' ('+rdate+')'+'</span>':'') +
                        ' </div>'+
                        ' <div class="title-button"><button class="btn material-icons shadow-none" onclick="showMenu2(this,event)">more_vert</button></div>' +
                        '</div>'+
                	'</div>'
	      else
                str +=  ' <div class="overlay">' +
                        '     <button class="btn favbtn material-icons shadow-none" type="button" role="button" onclick=\'Tidalfav("album","'+item.id+'",event,this);\' title="">'+icon+'</button>'+
                        '     <button class="btn material-icons shadow-none" type="button" role="button" onclick=\'Tidal("play","album","'+item.id+'",event);\' title="Play">play_arrow</button>' +
                        '     <button class="btn material-icons shadow-none" type="button" role="button" onclick="showMenu2(this,event)" title="Show menu">more_vert</button>' +
                        ' </div>'+
                        '</div></a>'+
                        '  <span class="item-title talb clickable" title="'+item.album+'" onclick=\'appGoto("Tidal","page","album__'+item.id+'");\'>' + item.album + '</span>' +
                        '  <span class="item-title tart' + (page == 'ecm' ? '' : ' clickable') +'" title="'+item.artist+'" '+(page == 'ecm' ? '':'onclick=\'appGoto("Tidal","page","artist__' + item.artid+'");\'')+'>' + item.artist + '</span>' +
                             (page == 'ecm' ? '  <span class="item-title tart">' + item.catId + ' ('+rdate+')'+'</span>':'') +
                        '</div>';
              card.innerHTML = str;
    	      div.appendChild(card);
    	    }
	  } //for
	if (request.data.offset == 0)
    	    cardContainer.appendChild(div);
	}
    }
    observer.observe();
    modalLoader.hide();
    scrollFlag = false;
}


function parseTidal(obj, request){
//	var str = "Home|Explore|Album|Artist| pages_"; //page
var t0 = performance.now();
var narr = ["Concerts","Podcasts","New Shows","Shows","Video Playlists"];
var narr2 = ["Videos","Shows & Podcasts","TIDAL X"];
var hddr = '';
var clas, icon, favtit;

    console.log('---parseTidal----');
    var len = 0;
    var item;
    var node;
    var flag = false;
    var apipath = true;
    if (request.data.page)
	var page = request.data.page;

    var tMenu = document.getElementById('tidalMenu');
    var style = getComputedStyle(tMenu);

    if (page == "explore" || page == "home") {
      var cardContainer = document.getElementById('Tidal'+page);
      if (!phone)
        document.getElementById('topTitle').innerHTML = ''
      else
        document.getElementById('topTitle').innerHTML = '<i class="material-icons">'+page+'</i>';

    }
    else {
      var cardContainer = document.getElementById('Tidalpage');

      if (!request.data.offset) {
        while (cardContainer.firstChild) {
    	    cardContainer.removeChild(cardContainer.firstChild);
        };
        if (page.indexOf('artist')==-1 && page.indexOf('album')==-1 && page.indexOf('playlist')==-1) {
//    	    var card = document.createElement('h5');
    	    hddr = obj.title;
//    	    card.innerHTML = '<h5>'+obj.title+'</h5>';
//    	    card.innerHTML = obj.title;
//    	    card.classList.add('group-header');
//    	    cardContainer.appendChild(card);
	} else {
	    var typ ='';
	    if (page.indexOf('artist')>-1) typ='Artist';
	    if (page.indexOf('album')>-1) typ='Album';
    	    document.getElementById('topTitle').innerHTML = typ + (!phone ? ': '+obj.title :'');
	    if (page.indexOf('playlist')>-1) { 
		typ='Playlist';
    		document.getElementById('topTitle').innerHTML = typ + (!phone ? ': '+obj.header.title:'');
	    }
    	}
      
      } // offset = 0
    }

    if (page.indexOf("mix")>-1) {
	//rows[0].modules[0] - header  .mix.title, subTitle, graphic.images, graphic.text
	//rows[0].modules[1] - list   .pagedList.items       .id,.title,.duration,.album.id,.album.title,.album.cover, artists[0].name, artists[0].id
        var cardContainer = document.getElementById('Tidalpage');
        cardContainer.parentNode.classList.remove('hide');
        cardContainer.classList.remove('hide');
        //header
	var div = document.createElement('div');
        
        var mix = obj.rows[0].modules[0].mix;
    	document.getElementById('topTitle').innerHTML = 'Mix'+(!phone ? ': ' + mix.title:'');

	var str = '<div class="artist-image">';
//	var j = 0;
//	var len2 = mix.graphic.images.length;
//	while (j<len2 && j<4) {
//	    var img = mix.graphic.images[j].id;
//	    if (img == null) {
//		var link = 'icons/disc.svg';
//	    } else {
//    		img = img.replace(/-/g,'\/');
//    		var link = 'https://resources.tidal.com/images/'+img+'/320x320.jpg';
//    	    }
	    var link = mix.images.SMALL.url;
	    str += '<img class="lozad" src="icons/disc.svg" data-src="'+link+'" width="100%">';
//	    j = j + 1;
//	}
	str += '</div><div class="artist-text"><h2 title="'+mix.title+'">'+ mix.title+'</h2>'+
	'<div>'+ mix.subTitle +'</div>';
	
	str += '</div>';
	var div2 = document.createElement('div');
	div2.innerHTML = '<div class="header-controls"><button class="btn play material-icons" type="button" role="button" onclick=\'Tidal("play","mix","'+mix.id+'",event);\' title="Play">play_arrow</button></div>';
	div2.classList.add('w-100');
	if (phone) cardContainer.classList.add('phone');

	div.innerHTML = str;
	div.classList.add('artist-header');
	cardContainer.appendChild(div);
	cardContainer.appendChild(div2);

	var bg = document.createElement('div');
	bg.classList.add('artist-bg');
	div.appendChild(bg);
	
        var list = obj.rows[1].modules[0].pagedList;
	
	var tbl = document.createElement('ul');
    	var tr = document.createElement('li');
    	tr.innerHTML = '<span class="track-cover"></span>'+
	'<div class="track-title-mobile">'+
    	'<span class="track-title">Title</span><span class="track-artist">Artist</span>'+
    	'</div>'+
    	'<span class="track-album">Album</span><span class="track-duration">Time</span>'+
    	'<span class="track-fav"></span><span class="track-action"></span>'
    	tr.classList.add('tracklist-label');
    	tbl.appendChild(tr);
	len = list.items.length;
	for (var j = 0; j < len; j++) {
	    item = list.items[j];
	    var tr = document.createElement('li');
	    var cover = item.album.cover;
	    if (cover == null) {
		var link = 'icons/disc.svg';
	    } else {
    		cover = cover.replace(/-/g,'\/');
    		var link = 'https://resources.tidal.com/images/' + cover + '/80x80.jpg';
    	    }
	    tr.classList.add('track-item');
	    tr.setAttribute('data-type','track');
	    tr.setAttribute('data-title',item.title);
	    tr.setAttribute('data-id',item.id);
	    tr.innerHTML = '<span class="track-cover">'+
	    '<div class="imgmini2">'+
	    '<div class="item-wrapper">'+
	    '<a class="clickable" data-type="track" data-id="'+item.id+'" onclick=\'Tidal("play","track","'+item.id+'",event); return false\' title="Play">'+
	    '<img class="lozad" src="icons/disc.svg" data-src="'+link+'" width="50px" height="50px">'+
	    '<div class="overlay">'+
                '<button class="btn material-icons shadow-none" type="button" role="button">play_arrow</button>'+
	    '</div>'+
	    '</a></div></div></span>'+
	    '<div class="track-title-mobile">'+
	    '<span class="track-title"><a class="clickable" onclick=\'Tidal("play","track","'+item.id+'",event); return false\' title="' + item.title + '">' + item.title + '</a></span>' +
	    '<span class="track-artist"><a class="clickable" onclick=\'appGoto("Tidal","page","artist__' + item.artists[0].id + '");\' title="' + item.artists[0].name + '">' + item.artists[0].name + '</a></span>' +
	    '</div>'+
	    '<span class="track-album"><a class="clickable" onclick=\'appGoto("Tidal","page","album__' + item.album.id + '");\' title="' + item.album.title + '">' + item.album.title + '</a></span>' +
	    '<span class="track-duration">' + HHMMSS(item.duration) + '</span>'+
	    '<span class="track-fav"><a class="clickable material-icons" onclick=\'Tidal("add","track","'+item.id+'",event); return false;\' title="Add to Queue">add</a></span>'+
	    '<span class="track-action"><a class="clickable material-icons" onclick="showMenu2(this.parentNode,event);" title="Show menu">more_vert</a></span>';
    	    tbl.appendChild(tr);
	}
	tbl.classList.add('tracklist');
        cardContainer.appendChild(tbl);
//	console.log('playlist '+page);

	observer.observe();
	modalLoader.hide();
	return;
	
    }
    if (page.indexOf("playlist")>-1 && page.indexOf("_playlists")==-1) {
        var cardContainer = document.getElementById('Tidalpage');
        cardContainer.parentNode.classList.remove('hide');
        cardContainer.classList.remove('hide'); //wtf?
        //obj.header.title,numberOfTracks,description,duration,lastUpdated
	var div = document.createElement('div');
	var video = false;
	if (obj.tracks.items[0].type == 'video') video = true;
	var img = obj.header.squareImage;
	if (img == null) {
	    var link = 'icons/disc.svg';
	} else {
    	    img = img.replace(/-/g,'\/');
    	    var link = 'https://resources.tidal.com/images/'+img+'/320x320.jpg';
    	}
        var fav = checkTFav('playlist',obj.header.uuid);
	if (fav) {
	    clas = ' fav'; icon = 'favorite'; favtit = 'Remove from My Collection';
	} else {
	    clas = ''; icon = 'favorite_border'; favtit = 'Add to My Collection';
	}
	if (!phone) {
	    var str = '<div class="artist-image"><img class="lozad" src="icons/disc.svg" data-src="'+link+'" width="100%"></div>';
	    str += '<div class="artist-text"><h2 title="'+obj.header.title+'">'+ obj.header.title+'</h2>'+
	    '<div class="swiper-bio">'+obj.header.description+'</div>'+
	    '<br/><div>'+(video ? obj.header.numberOfVideos : obj.header.numberOfTracks)+' Tracks - '+HHMMSS(obj.header.duration)+'</div>';
	     str += '<div class="header-controls">'+
	    '  <button class="btn play material-icons" type="button" role="button" onclick=\'Tidal("play","'+(video ? 'v':'')+'playlist","'+obj.header.uuid+'",event);\' title="Play">play_arrow</button>'+
//	    '<button class="btn hfav material-icons'+clas+'" type="button" role="button" onclick=\'Tidalfav("playlist","'+obj.header.uuid+'",event,this);\' title="'+favtit+'">'+icon+'</button>'+
	    '  <button class="btn favbtn material-icons '+clas+'" type="button" role="button" onclick=\'Tidalfav("playlist","'+obj.header.uuid+'",event,this);\' title="'+favtit+'">'+icon+'</button>'+
	    '</div>'+
	    '</div>';
	    div.innerHTML = str;
	    div.classList.add('artist-header');
	    cardContainer.appendChild(div);
	}
	else {
	    div.classList.add('swiper-container');
    	    div.classList.add('swiper-header');

	    var bg = document.createElement('div');
    	    bg.classList.add('bg-header');
	    bg.style.background = 'url("'+link+'")';
	    bg.style.backgroundSize = 'cover';
	    bg.style.backgroundPositionY = '50%';
	    div.appendChild(bg);

	    var div2 = document.createElement('div');
	    div2.classList.add('swiper-wrapper');
	    div.appendChild(div2);
	    var card = document.createElement('div');
	    card.classList.add('swiper-slide');
	    card.classList.add('card-body-image');
	    card.innerHTML = '<div class="grid-item" style="margin:0 auto;">'+
	    '<img class="swiper-lazy" src="icons/disc.svg" data-src="'+link+'" width="100%;">'+
	    '<span class="item-title talb">'+obj.header.title+'</span>'+
	    '</div>';
	    div2.appendChild(card);

	    var card2 = document.createElement('div');
	    card2.classList.add('swiper-slide');
	    card2.classList.add('card-body-header');
	    var str = '<h5 title="'+obj.header.title+'">'+ obj.header.title+'</h5>'+
	    '<div class="swiper-bio">'+obj.header.description+'</div>'+
	    '<br/><div style="font-size:small">'+(video ? obj.header.numberOfVideos : obj.header.numberOfTracks) + ' Tracks - ' + beautifyDuration(obj.header.duration) + '</div>';
	    card2.innerHTML = str;

	    div2.appendChild(card2);
	    cardContainer.appendChild(div);

	    var pg = document.createElement('div');
	    pg.classList.add('swiper-pagination');
	    div.appendChild(pg);

	    var dv2 = document.createElement('div');
	    dv2.innerHTML = '<button class="btn float-left material-icons'+clas+'" type="button" role="button" onclick=\'Tidalfav("playlist","'+obj.header.uuid+'",event,this);\' title="'+favtit+'">'+icon+'</button>'+
	    '<button class="btn float-right play material-icons" type="button" role="button" onclick=\'Tidal("play","'+(video ? 'v':'')+'playlist","'+obj.header.uuid+'",event);\' title="Play">play_arrow</button>';

	    dv2.classList.add('header-controls');
	    dv2.classList.add('w-100');

	    var dv = document.createElement('div');
	    dv.style.height = '20px';
	    dv.style.width = '100%';
	    
	    var swiperhead = new Swiper('.swiper-header', {
		slidesPerView: 1,
    		loop: false,
    		lazy:true,
    		pagination: {
        	el: '.swiper-pagination',
        	     clickable: true,
    		},
	    });

	    cardContainer.appendChild(dv2);
	    cardContainer.appendChild(dv);
	    cardContainer.classList.add('phone');
	}
	
	var tbl = document.createElement('ul');
    	var tr = document.createElement('li');
    	tr.innerHTML = '<span class="track-number">#</span>'+
	'<div class="track-title-mobile">'+
    	'<span class="track-title">Title</span><span class="track-artist">Artist</span>'+
    	'</div>'+
    	(video ? '' : '<span class="track-album">Album</span>')+
    	'<span class="track-duration">Time</span>'+
    	'<span class="track-fav"></span><span class="track-action"></span>'
    	tr.classList.add('tracklist-label');
    	tbl.appendChild(tr);
	len = obj.tracks.items.length;
	cardContainer.setAttribute('data-offset',len);
	cardContainer.setAttribute('data-total',obj.tracks.totalNumberOfItems);
	for (var j = 0; j < len; j++) {
	    item = obj.tracks.items[j].item;
	    var tr = document.createElement('li');
	    var cover = (video ? item.imageId : item.album.cover);
	    if (cover == null) {
		var link = 'icons/disc.svg';
	    } else {
    		cover = cover.replace(/-/g,'\/');
    		var link = 'https://resources.tidal.com/images/' + cover + '/80x80.jpg';
    	    }
	    tr.classList.add('track-item');
	    tr.setAttribute('data-type','track');
	    tr.setAttribute('data-title',item.title);
	    tr.setAttribute('data-id',item.id);
	    tr.innerHTML = '<span class="track-number">'+(j+1)+'</span>'+
//	    tr.innerHTML = '<span class="track-cover">'+
//	    '<div class="imgmini2">'+
//	    '<div class="item-wrapper">'+
//	    '<a class="clickable" data-type="track" data-id="'+item.id+'" onclick=\'Tidal("play",' + (video ? '"video"' : '"track"')+',"'+item.id+'",event); return false\' title="Play">'+
//	    '<img class="lozad" src="icons/disc.svg" data-src="'+link+'">'+
//	    '<div class="overlay">'+
//                '<button class="btn material-icons shadow-none" type="button" role="button">play_arrow</button>'+
//	    '</div></a></div></div></span>'+
	    '<div class="track-title-mobile">'+
	      '<span class="track-title"><a class="clickable" onclick=\'Tidal("play",'+(video ? '"video"' : '"track"')+',"'+item.id+'",event); return false\' title="' + item.title + '">' + item.title + '</a></span>' +
	      '<span class="track-artist"><a class="clickable" onclick=\'appGoto("Tidal","page","artist__' + item.artists[0].id + '");\' title="' + item.artists[0].name + '">' + item.artists[0].name + '</a></span>' +
	    '</div>'+
	    (video ? '' : '<span class="track-album"><a class="clickable" onclick=\'appGoto("Tidal","page","album__' + item.album.id + '");\' title="' + item.album.title + '">' + item.album.title + '</a></span>') +
	    '<span class="track-duration">' + HHMMSS(item.duration) + '</span>'+
	    (video ? '' : '<span class="track-fav"><a class="clickable material-icons" onclick=\'Tidal("add","track","'+item.id+'",event); return false;\' title="Add to Queue">add</a></span>')+
	    '<span class="track-action"><a class="clickable material-icons" onclick="showMenu2(this.parentNode,event);" title="Show menu">more_vert</a></span>';
    	    tbl.appendChild(tr);
	}
	tbl.classList.add('tracklist');
        cardContainer.appendChild(tbl);
//	console.log('playlist '+page);

	observer.observe();
	modalLoader.hide();
	return;
    }

    if (page.indexOf('mood_')==-1 && page.indexOf('single-')==-1 && 
      page.indexOf('_playlists')==-1) {
        flag = true;
    }
    if (page == 'artist' || page == 'album') {
	apipath = false;
	cardContainer.removeAttribute('data-apipath');
    }

    cardContainer.classList.remove('hide');

    if (cardContainer.getElementsByTagName('div').length == 0) {
      if (obj.status) {
        if (obj.status == 404) {
    	    cardContainer.innerHTML = '&nbsp;'+obj.userMessage;
    	    modalLoader.hide();
	    return;
        }
      }
      var nr = obj.rows.length;
      for (var i = 0; i < nr; i++) {
	node = obj.rows[i].modules[0];

	if (node.type == "PAGE_LINKS_CLOUD" || node.type == "PAGE_LINKS") {
	  if (node.title) {
	    var card = document.createElement('div');
	    card.innerHTML = '<h5>'+node.title+'</h5>';
	    card.classList.add('group-header');
            cardContainer.appendChild(card);
          }
	  var div = document.createElement('div');
    	  div.classList.add('row');
	  len = node.pagedList.items.length;
	  for (var j = 0; j < len; j++) {
	    item = node.pagedList.items[j];
	    //item.title , apiPath
	    item = node.pagedList.items[j];
	    if (narr2.indexOf(item.title) == -1) {
	      var spath = item.apiPath.split('/').pop();
	      var card = document.createElement('div'); // no need two div !!!
	      card.classList.add('card-cloud');
//	      card.innerHTML = '<div class="card-cloud" id="cardTELink' + item.id + '">' +
	      card.innerHTML = '' +
//                             ' <a class="clickable" data-name="' + item.apiPath + '" onclick=\'TidalPage("'+spath+'")\'>'+
                             ' <a class="clickable" onclick=\'appGoto("Tidal","page","'+spath+'");\'>'+
                             '  <span class="cloud-title talb">' + item.title + '</span>' +
                             '</div>'; 

    	      div.appendChild(card);
    	    }
	  } //for j=
          cardContainer.appendChild(div);
	} //if node.type ==
	else if (node.type == "ALBUM_LIST" || node.type == "VIDEO_LIST") {
	  var video = false;
	  if (node.type == "VIDEO_LIST") video = true;
//	  if (node.title)
	    var title = node.title;
//	  else
//	    var title = obj.title;
	  if (!title) title = hddr;
//	  if (hddr != title) {
	    var header = document.createElement('div');
	    title = title.replace('Suggested ','');
	    var str = '<h5>'+title+'</h5>'

	    var more = node.showMore;
	    if (more) {
	      str += '<a class="clickable" onclick=\'appGoto("Tidal","page","'+more.apiPath +'");\'>'+more.title+'</a>';
	    }

	    header.innerHTML = str;
	    header.classList.add('group-header');
	    cardContainer.appendChild(header);
//	  }
	  len = node.pagedList.items.length;

	  var div = document.createElement('div');
	  if (!phone) {
//	    if (len>6) {
	    if (flag) {
    		div.classList.add('swiper-container');
//    		div.classList.add('swiper-2x');
    		div.classList.add('swiper-1x');
    	    }
	    var div2 = document.createElement('div');
	    if (flag) {
		div2.classList.add('swiper-wrapper');
	    } else  {
    		div2.classList.add('row');
	    }
	    div.appendChild(div2);
	    
	  } else { //phone
	    var div2 = document.createElement('div');
    	    div2.classList.add('row');
    	    div2.classList.add('phone');
	  }
	  if (apipath && len > 0) { 
		cardContainer.setAttribute('data-total',node.pagedList.totalNumberOfItems);
		cardContainer.setAttribute('data-offset',len);
		cardContainer.setAttribute('data-apipath',node.pagedList.dataApiPath);
	  }
	  for (var j = 0; j < len; j++) {
	    item = node.pagedList.items[j];
	    var card = document.createElement('div');
//    	    card.classList.add('my-item');
    	    if (!phone && flag) card.classList.add('swiper-slide');
    	    if (video){
    		card.classList.add('video-item');
    	    } else { 
    		card.classList.add('grid-item');
    	    }
    	    
    	    var cover = (video ? item.imageId : item.cover);
    	    if (cover == null) {
    		var link = 'icons/disc.svg';
    	    } else {
    		cover = cover.replace(/-/g,'\/');
    		var link = 'https://resources.tidal.com/images/' + cover + (video ? '/320x180.jpg' : '/160x160.jpg');
    	    }
	    icon = 'favorite_border';

    	    var str = '<div class="card1">' +
                             (item.audioQuality == "HI_RES" ? ' <i class="hires material-icons">high_quality</i>' : '')+
                             ' <a class="clickable" data-type="'+(video ? "video" : "album")+'" data-id="'+item.id+ (video ? '" onclick=\'Tidal("play","video","'+item.id+'",event);\'>' : '" onclick=\'appGoto("Tidal","page","album__'+item.id+'");\'>') +
                             ' <div class="item-wrapper'+(video? ' ensemble':'')+'">'+
//                             ' <img src="'+link+'" width="100%" height="100%" class="swiper-lazy">' +
				'<img src="icons/disc.svg" data-src="'+link+'" width="100%" height="100%" '+
                             (!phone && flag ? 'class="swiper-lazy">':'class="lozad">');
            if (phone) {
        	if (!video)
    		  str +=  ' <div class="aplay">'+
                          '     <button class="btn material-icons shadow-none" type="button" role="button" onclick=\'Tidal("play","album","'+item.id+'",event);\' title="Play">play_arrow</button>' +
                          ' </div>';
        	str +=  (video ? '<div class="item-time">'+HHMMSS(item.duration)+'</div>' : '')+
            		'</div></a>'+
                        '<div class="card-tit">'+
                        ' <div>'+
                	'  <span class="item-title talb clickable" '+(video ? '' : 'onclick=\'appGoto("Tidal","page","album__'+item.id+'");\'') + ' title="'+item.title+'">' + item.title + '</span>' +
                	'  <span class="item-title tart clickable" onclick=\'appGoto("Tidal","page","artist__'+item.artists[0].id+'");\' title="'+item.artists[0].name+'">' + item.artists[0].name + '</span>' +
                        ' </div>'+
                        ' <div class="title-button"><button class="btn material-icons shadow-none" onclick="showMenu2(this,event)">more_vert</button></div>' +
                        '</div>'+
                	'</div>';
            }
	    else
		str +=  ' <div class="overlay">' +
                        '     <button class="btn favbtn material-icons shadow-none" type="button" role="button" onclick=\'Tidalfav("'+(video ? 'video' : 'album')+'","'+item.id+'",event,this);\' title="">'+icon+'</button>'+
                        '     <button class="btn material-icons shadow-none" type="button" role="button" onclick=\'Tidal("play","' + (video ? 'video' : 'album')+'","'+item.id+'",event);\' title="Play">play_arrow</button>' +
                        '     <button class="btn material-icons shadow-none" type="button" role="button" onclick="showMenu2(this,event)" title="Show menu">more_vert</button>' +
                        ' </div>'+
                        
        	    (video ? '<div class="item-time">'+HHMMSS(item.duration)+'</div>' : '')+
                    '</div></a>'+
                    '  <span class="item-title talb clickable" '+(video ? '' : 'onclick=\'appGoto("Tidal","page","album__'+item.id+'");\'') + ' title="'+item.title+'">' + item.title + '</span>' +
                    '  <span class="item-title tart clickable" onclick=\'appGoto("Tidal","page","artist__'+item.artists[0].id+'");\' title="'+item.artists[0].name+'">' + item.artists[0].name + '</span>' +
                    '</div>';
            card.innerHTML = str;
    	    div2.appendChild(card);
    	    if (!apipath && phone && j == 5) break;
	  } //for
	  if (!phone) {
	    if (flag) {
		var pagina = document.createElement('div');
		pagina.classList.add('swiper-scrollbar');
		div.appendChild(pagina);
		var but = document.createElement('div');
		but.classList.add('swiper-button-next');
		div.appendChild(but);
		var but = document.createElement('div');
		but.classList.add('swiper-button-prev');
		div.appendChild(but);
	    }
            cardContainer.appendChild(div);
          } else { //phone
            cardContainer.appendChild(div2);
          }
	} // if node.type

	else if (node.type == "ARTIST_HEADER") {
	    console.log('artist_header');
	    //node.artist.name, .picture, bio.text
	  var div = document.createElement('div');
	  var img = node.artist.picture;
	  if (img == null) {
	    var link = 'icons/disc.svg';
	  } else {
    	    img = img.replace(/-/g,'\/');
    	    var link ='https://resources.tidal.com/images/'+img+'/320x320.jpg';
    	  }
	  var text = node.bio.text;
	  if (text) {
	    text = text.replace(/\"/g,'');
	    text = text.replace(/\[wimpLink artistId=/g,"<a class='clickable' onclick='appGoto(\"Tidal\",\"page\",\"artist__");
	    text = text.replace(/\[wimpLink albumId=/g,"<a class='clickable' onclick='appGoto(\"Tidal\",\"page\",\"album__");
	    text = text.replace(/\[\/wimpLink\]/g,'</a>');
	    text = text.replace(/\]/g,'");\'>');
	  }
	  var fav = checkTFav('artist',node.artist.id);
	  if (fav) {
	    clas = ' fav'; icon = 'favorite'; favtit = 'Remove from My Collection';
	  } else {
	    clas = ''; icon = 'favorite_border'; favtit = 'Add to My Collection';
	  }
    	  if (!phone) {
	    var str = '<div class="artist-image">'+
	    '<img class="lozad" src="icons/disc.svg" data-src="'+link+'" width="100%"></div>'+
	    '<div class="artist-text"><h2 title="'+node.artist.name+'">'+ node.artist.name+'</h2><ul class="roles">';
	    len = node.artist.artistTypes.length;
	    for (var j = 0; j < len; j++) {
		str+= '<li>'+node.artist.artistTypes[j]+'</li>';
	    }
	    str+='</ul>';
	    if (text) {
		str+='<div class="swiper-bio" data-name="'+node.artist.name+'">'+text+'</div>';
		str+='<a class="clickable" title="Open full text" onclick="openInfo(this);">Read more</a>';
	    }

	    str+='<div class="header-controls">'+
		'<button class="btn play material-icons" type="button" role="button" onclick=\'Tidal("play","artist","'+node.artist.id+'",event);\' title="Play top tracks">play_arrow</button>'+
		'<button class="btn material-icons '+clas+'" type="button" role="button" onclick=\'Tidalfav("artist","'+node.artist.id+'",event,this);\' title="'+favtit+'">'+icon+'</button>'+
		'<button class="btn material-icons" type="button" role="button" onclick=\'Tidal("play","artistradio","'+node.artist.id+'",event);\' title="Artist Radio">radio</button>'+
	    '</div>'+
	    '</div>';
	  // artistTypes
	    div.innerHTML = str;
	    div.classList.add('artist-header');
	    cardContainer.appendChild(div);
	  } else {
	    div.classList.add('swiper-container');
    	    div.classList.add('swiper-header');
    	    
    	    var bg = document.createElement('div');
    	    bg.classList.add('bg-header');
	    bg.style.background = 'url("'+link+'")';
	    bg.style.backgroundSize = 'cover';
	    bg.style.backgroundPositionY = '50%';
	    div.appendChild(bg);

	    var div2 = document.createElement('div');
	    div2.classList.add('swiper-wrapper');
	    div.appendChild(div2);
	    var card = document.createElement('div');
	    card.classList.add('swiper-slide');
	    card.classList.add('card-body-image');
	    card.innerHTML = '<div class="grid-item" style="margin:0 auto;">'+
	    '<img class="swiper-lazy" src="icons/disc.svg" data-src="'+link+'" width="100%;">'+
	    '<span class="item-title talb">'+node.artist.name+'</span>'+
	    '</div>';
	    div2.appendChild(card);

	    var card2 = document.createElement('div');
	    card2.classList.add('swiper-slide');
	    card2.classList.add('card-body-header');
	    var str = '<h5>'+node.artist.name+'</h5>';
	    str+='<ul class="roles">';
	    len = node.artist.artistTypes.length;
	    for (var j = 0; j < len; j++) {
		str+= '<li>'+node.artist.artistTypes[j]+'</li>';
	    }
	    str+='</ul>';
	    if (text) {
		str+='<div class="swiper-bio" data-name="'+node.artist.name+'">'+text+'</div>';
		str+='<a class="clickable" title="Open full text" onclick="openInfo(this);">Read more</a>';
	    }
	    card2.innerHTML = str;

	    div2.appendChild(card2);
	    cardContainer.appendChild(div);

	    var pg = document.createElement('div');
	    pg.classList.add('swiper-pagination');
	    div.appendChild(pg);

	    var dv2 = document.createElement('div');
	    dv2.innerHTML =  '<button class="btn float-left material-icons'+clas+'" type="button" role="button" onclick=\'Tidalfav("artist","'+node.artist.id+'",event,this);\' title="'+favtit+'">'+icon+'</button>'+
		'<button class="btn play float-right material-icons" type="button" role="button" onclick=\'Tidal("play","artist","'+node.artist.id+'",event);\' title="Play top tracks">play_arrow</button>'+
		'<button class="btn btn-small float-right material-icons" type="button" role="button" onclick=\'Tidal("play","artistradio","'+node.artist.id+'",event);\' title="Artist Radio">radio</button>';
	    dv2.classList.add('header-controls');
	    dv2.classList.add('w-100');

	    var dv = document.createElement('div');
	    dv.style.height = '20px';
	    dv.style.width = '100%';
	    
	    var swiperhead = new Swiper('.swiper-header', {
		slidesPerView: 1,
    		loop: false,
    		lazy:true,
    		pagination: {
        	el: '.swiper-pagination',
        	     clickable: true,
    		},
	    });

	    cardContainer.appendChild(dv2);
	    cardContainer.appendChild(dv);

	    cardContainer.classList.add('phone');
	  }
	}
	else if (node.type == "ALBUM_HEADER") {
//	    album.title, album.duration, album.tracks, release_date, copyright
	  var div = document.createElement('div');
	  var img = node.album.cover;
	  if (img == null)
    	    var link = 'icons/disc.svg'
	  else {
    	    img = img.replace(/-/g,'\/');
    	    var link = 'https://resources.tidal.com/images/'+img+'/320x320.jpg';
    	  }
	  icon = 'favorite_border';
	  var fav = checkQFav('album',node.album.id);
	  if (fav) {
	    clas = ' fav'; icon = 'favorite'; favtit = 'Remove from My Collection';
	  } else {
	    clas = ''; icon = 'favorite_border'; favtit = 'Add to My Collection';
	  }

          if (!phone) {
	    var str = '<div class="artist-image"><img class="lozad" src="icons/disc.svg" data-src="'+link+'" width="100%;"></div>'+
	    '<div class="artist-text"><h2>'+node.album.title+'</h2>'+
	    '<div>Released by ';
	    var alen = node.album.artists.length;
	    for (var k = 0; k < alen; k++) {
		str += (k > 0 ? ',&nbsp':'')+'<a class="clickable" onclick=\'appGoto("Tidal","page","artist__' + node.album.artists[k].id+'");\' title="'+node.album.artists[k].name+'">'+node.album.artists[k].name+'</a>';
	    }
	    str += '</div><div>'+node.album.numberOfTracks+' Tracks - '+ node.album.numberOfVolumes +' Volumes - '+HHMMSS(node.album.duration)+'</div>'+
	    '<br/><div>'+node.album.copyright+'</div>'+
	    '<div>Release: '+formatDate(node.album.releaseDate)+'</div>'+
	    '<div class="header-controls">'+
	    '  <button class="btn play material-icons" type="button" role="button" onclick=\'Tidal("play","album","'+node.album.id+'",event);\' title="Play">play_arrow</button>'+
	    '  <button class="btn favbtn material-icons '+clas+'" type="button" role="button" onclick=\'Tidalfav("album","'+node.album.id+'",event,this);\' title="">'+icon+'</button>'+
	    '  <button class="btn material-icons" type="button" role="button" onclick="creditsTidal(\''+node.album.id+'\');" title="Credits">info</button>'+
	    '  <button class="btn material-icons" type="button" role="button" onclick=\'Tidal("add","playlist","' + node.album.id+'",event);\' title="Add to Queue">playlist_add</button>'+
//	    '<button class="btn material-icons" type="button" role="button" onclick="">more_horiz</button>'+
	    '</div>'+
	    '</div>';
	    div.innerHTML = str;
	    div.classList.add('artist-header');
	    cardContainer.appendChild(div);
	  } else {
	    div.classList.add('swiper-container');
    	    div.classList.add('swiper-header');

	    var bg = document.createElement('div');
    	    bg.classList.add('bg-header');
	    bg.style.background = 'url("'+link+'")';
	    bg.style.backgroundSize = 'cover';
	    bg.style.backgroundPositionY = '50%';
	    div.appendChild(bg);
	    
	    var div2 = document.createElement('div');
	    div2.classList.add('swiper-wrapper');
	    div.appendChild(div2);
	    var card = document.createElement('div');
	    card.classList.add('swiper-slide');
	    card.classList.add('card-body-image');
	    card.innerHTML = '<div class="grid-item" style="margin:0 auto;">'+
	    '<img class="swiper-lazy" src="icons/disc.svg" data-src="'+link+'" width="100%;">'+
	    '<span class="item-title talb">'+node.album.title+'</span>'+
	    '<span class="item-title tart" onclick=\'appGoto("Tidal","page","artist__' + node.album.artists[0].id+'");\'>'+node.album.artists[0].name+'</span>';
	    '</div>';
	    div2.appendChild(card);

	    var card2 = document.createElement('div');
	    card2.classList.add('swiper-slide');
	    card2.classList.add('card-body-header');
	    var str ='<h5>'+node.album.title+'</h5>'+
	    '<small>'+node.album.type+'</small>'+
	    '<div>Release by ';
	    var alen = node.album.artists.length;
	    for (var k = 0; k < alen; k++) {
		str += (k > 0 ? ',&nbsp':'')+'<a class="clickable" onclick=\'appGoto("Tidal","page","artist__' + node.album.artists[k].id+'");\' title="'+node.album.artists[k].name+'">'+node.album.artists[k].name+'</a>';
	    }

	    str +='</div>'+ 
	    '<div style="font-size:small;">'+node.album.numberOfTracks+' Tracks - '+beautifyDuration(node.album.duration)+(node.album.numberOfVolumes >1 ? ' - '+ node.album.numberOfVolumes +' Volumes':'')+'</div>'+
	    '<br/><div style="font-size:small;">'+node.album.copyright+'</div>'+
	    '<div>'+formatDate(node.album.releaseDate)+'</div>';
	    card2.innerHTML = str;
	    
	    div2.appendChild(card2);
	    cardContainer.appendChild(div);

	    var pg = document.createElement('div');
	    pg.classList.add('swiper-pagination');
	    div.appendChild(pg);
	    
	    var dv2 = document.createElement('div');
	    dv2.innerHTML = '<button class="btn float-left material-icons '+clas+'" type="button" role="button" onclick=\'Tidalfav("album","'+node.album.id+'",event,this);\' title="'+favtit+'">'+icon+'</button>'+
	    '<button class="btn float-right play material-icons" type="button" role="button" onclick=\'Tidal("play","album","'+node.album.id+'",event);\' title="Play">play_arrow</button>'+
	    '<button class="btn btn-small float-right btn-text" type="button" role="button" onclick="creditsTidal(\''+node.album.id+'\');" title="Credits">i</button>';
	    dv2.classList.add('header-controls');
	    dv2.classList.add('w-100');
	    
	    var dv = document.createElement('div');
	    dv.style.height = '20px';
	    dv.style.width = '100%';


	    var swiperhead = new Swiper('.swiper-header', {
		slidesPerView: 1,
    		loop: false,
    		lazy:true,
    		pagination: {
        	el: '.swiper-pagination',
        	     clickable: true,
    		},
	    });
	    cardContainer.appendChild(dv2);
	    cardContainer.appendChild(dv);
	    
	    cardContainer.classList.add('phone');

	  }

	  var discs = node.album.numberOfVolumes;
	  if (discs > 1) {
	    var div = document.createElement('nav');
	    var str = '<div class="nav nav-tabs" role="tablist">';
	    for (var j = 0; j < discs; j++) {
		str += '<a class="nav-item2 nav-link clickable' + (j==0 ? ' active' : '') + '" id="Vol'+j+'-tab" aria-controls="Vol'+(j+1)+'" data-toggle="tab" role="tab" onclick=\'tabshow("album-content",this);\'>CD '+(j+1)+'</a>';
	    }
	    str += '</div>';
	    div.innerHTML = str;
    	    cardContainer.appendChild(div);
	  }
/*	  var bg = document.createElement('div');
	  bg.classList.add('artist-bg');
	  bg.style.background = 'url('+link+')';
	  div.appendChild(bg);*/

	}
	else if (node.type == "ALBUM_ITEMS") {
    	  if (phone && tbl) tbl.classList.add('phone');
	  len = node.pagedList.items.length;
	  if (discs > 1) {
	    var div = document.createElement('div');
	    div.id = 'album-content';
	    div.classList.add('tab-content');
    	    var nvol = 0;
	    for (var j = 0; j < len; j++) {
	      item = node.pagedList.items[j].item;
	      var nvol0 = item.volumeNumber;
	      if (nvol !== nvol0) {
		var page1 = document.createElement('div');
		page1.id = 'Vol'+ nvol0;
		page1.classList.add('tab-pane');
		if (nvol == 0) page1.classList.add('active');
		var tbl = document.createElement('ul');
    		var tr = document.createElement('li');
    		tr.innerHTML = '<span class="track-number">#</span>'+
    		'<div class="track-title-mobile">'+
    		'  <span class="track-title">Title</span><span class="track-artist">Artist</span>'+
    		'</div>'+
    		'<span class="track-duration">Time</span><span class="track-fav"></span><span class="track-action"></span>'
    		tr.classList.add('tracklist-label');
    		tbl.appendChild(tr);
		tbl.classList.add('tracklist');
		tbl.classList.add('album-tracklist');
    		page1.appendChild(tbl);
		    
		nvol = nvol0;
        	div.appendChild(page1);
	      }

	      var tr = document.createElement('li');
	      tr.classList.add('track-item');
	      tr.setAttribute('data-type','track');
	      tr.setAttribute('data-title',item.title);
	      tr.setAttribute('data-id',item.id);
	      var str = '<span class="track-number">'+item.trackNumber+'</span>'+
    	      '<div class="track-title-mobile">'+
	      '  <span class="track-title clickable" title="'+item.title+'"><a onclick=\'Tidal("play","track","'+item.id+'",event); return false;\' title="'+item.title+'">'+item.title+'</a></span>'+
	      '  <span class="track-artist clickable">';
	      var alen = item.artists.length;
	      for (var k = 0; k < alen; k++) {
	        str += (k >0 ? ',&nbsp':'')+'<a onclick=\'appGoto("Tidal","page","artist__' + item.artists[k].id+'");\' title="'+item.artists[k].name+'">'+item.artists[k].name+'</a>';
	      }
	      str += '</span></div>'+
	      '<span class="track-duration">'+HHMMSS(item.duration)+'</span>'+
	      '<span class="track-fav clickable"><a class="material-icons" onclick=\'Tidal("add","track","'+item.id+'",event);\' title="Add to Queue">add</a></span>'+
	      '<span class="track-action clickable"><a class="material-icons" onclick="showMenu2(this.parentNode,event);" title="Show menu">more_vert</a></span>';
    	      tr.innerHTML = str;
    	      tbl.appendChild(tr);
	    }
    	    cardContainer.appendChild(div);
	  }
	  else {
	    var tbl = document.createElement('ul');
    	    var tr = document.createElement('li');
    	    tr.innerHTML = '<span class="track-number">#</span>'+
    	  '<div class="track-title-mobile">'+
    	    '<span class="track-title">Title</span><span class="track-artist">Artist</span>'+
    	  '</div>'+
    	  '<span class="track-duration">Time</span><span class="track-fav"></span><span class="track-action"></span>'
    	    tr.classList.add('tracklist-label');
    	    tbl.appendChild(tr);
	    for (var j = 0; j < len; j++) {
	      item = node.pagedList.items[j].item;

	      var tr = document.createElement('li');
	      tr.classList.add('track-item');
	      tr.setAttribute('data-type','track');
	      tr.setAttribute('data-title',item.title);
	      tr.setAttribute('data-id',item.id);
	      var str = '<span class="track-number">'+item.trackNumber+'</span>'+
    	      '<div class="track-title-mobile">'+
	      '  <span class="track-title clickable" title="'+item.title+'"><a onclick=\'Tidal("play","track","'+item.id+'",event); return false;\' title="'+item.title+'">'+item.title+'</a></span>'+
	      '  <span class="track-artist clickable">';
	      var alen = item.artists.length;
	      for (var k = 0; k < alen; k++) {
	        str += (k >0 ? ',&nbsp':'')+'<a onclick=\'appGoto("Tidal","page","artist__' + item.artists[k].id+'");\' title="'+item.artists[k].name+'">'+item.artists[k].name+'</a>';
	      }

	      str += '</span></div>'+
	      '<span class="track-duration">'+HHMMSS(item.duration)+'</span>'+
	      '<span class="track-fav clickable"><a class="material-icons" onclick=\'Tidal("add","track","'+item.id+'",event);\' title="Add to Queue">add</a></span>'+
	      '<span class="track-action clickable"><a class="material-icons" onclick="showMenu2(this.parentNode,event);" title="Show menu">more_vert</a></span>';
	      tr.innerHTML = str;
    	    tbl.appendChild(tr);
	  }
	  tbl.classList.add('tracklist');
	  tbl.classList.add('album-tracklist');
          cardContainer.appendChild(tbl);
          }
	}

	else if (node.type == "ARTIST_LIST") {
//	  console.log('artist_list '+page);
	  var card = document.createElement('div');
	  var str = '<h5>'+node.title+'</h5>';
	  var more = node.showMore;
	  if (more) {
	      str += '<a class="clickable" onclick=\'appGoto("Tidal","page","'+more.apiPath +'");\'>'+more.title+'</a>';
	  }

	  card.innerHTML = str;
    	  card.classList.add('group-header');
	  cardContainer.appendChild(card);
	  
	  if (!phone) {
	    var div = document.createElement('div');
	    if (flag) {
    		div.classList.add('swiper-container');
    		div.classList.add('swiper-1x');
    	    }
	    var div2 = document.createElement('div');
	    if (flag)
    		div2.classList.add('swiper-wrapper')
    	    else
    		div2.classList.add('row')
            div.appendChild(div2);
    	  }
          else {
	    var div2 = document.createElement('div');
    	    div2.classList.add('row')
    	    div2.classList.add('phone')
    	  }
	  len = node.pagedList.items.length;
	  if (apipath && len>0) { 
		cardContainer.setAttribute('data-total',node.pagedList.totalNumberOfItems);
		cardContainer.setAttribute('data-offset',len);
		cardContainer.setAttribute('data-apipath',node.pagedList.dataApiPath);
	  }
	  for (var j = 0; j < len; j++) {
	    item = node.pagedList.items[j];
	    var card = document.createElement('div');
//    	    card.classList.add('my-item');
    	    if (!phone && flag) card.classList.add('swiper-slide');
    	    
    	    card.classList.add('grid-item');
    	    //item.cover
    	    var img = item.picture;
    	    if (img == null) {
    		var link = "icons/disc.svg";
    	    } else {
    		img = img.replace(/-/g,'\/');
    		var link = 'https://resources.tidal.com/images/' + img + '/160x160.jpg';
    	    }
	    icon = 'favorite_border'; 
    	    card.innerHTML = '<div class="card1">' +
                             ' <a class="clickable" onclick=\'appGoto("Tidal","page","artist__' + item.id+'");\'>'+
                             ' <div class="artist-wrapper">'+
                             ' <img src="icons/disc.svg" data-src="'+link+'" width="100%" height="100%" ' +
                             (!phone && flag ? 'class="swiper-lazy">':'class="lozad">') +
                             ' <div class="overlay">'+
                             '     <button class="btn material-icons shadow-none" type="button" role="button" onclick=\'Tidal("play","artist","'+item.id+'",event);\' title="Play Artist Radio">play_arrow</button>'+
                             '     <button class="btn favbtn material-icons shadow-none" type="button" role="button" onclick=\'Tidalfav("artist","'+item.id+'",event,this);\' title="">'+icon+'</button>'+
                             ' </div></div></a>'+
                             '  <span class="item-title talb textcenter clickable" onclick=\'appGoto("Tidal","page","artist__' + item.id+'")\' title="'+item.name+'">' + item.name + '</span>' +
                             '</div>'; 
    	    div2.appendChild(card);
	  } //for j=
	  if (!phone) {
	    if (flag) {
		var pagina = document.createElement('div');
		pagina.classList.add('swiper-scrollbar');
		div.appendChild(pagina);

		var but = document.createElement('div');
		but.classList.add('swiper-button-next');
		div.appendChild(but);
		var but = document.createElement('div');
		but.classList.add('swiper-button-prev');
		div.appendChild(but);
	    }

	    cardContainer.appendChild(div);
	  } else {
	    cardContainer.appendChild(div2);
	  }
	} // if node.type

	else if (node.type == "TRACK_LIST") {
//	  console.log('track_list '+page);
	  len = node.pagedList.items.length;

//	  if (!request.data.offset) {
	    var header = document.createElement('div');
	    var str = '';
	    var title = node.title;
	    if (typeof title != "undefined") {
		if (!title) title = hddr;
		title = title.replace('Suggested ','');
		str = '<h5>'+title+'</h5>';
	    }

	    var more = node.showMore;
	    if (more)
	      str += '<a class="clickable" onclick=\'appGoto("Tidal","page","'+more.apiPath +'");\'>'+more.title+'</a>';
	    if (page)
	    if (page.indexOf("single-")!==-1)
    	      str += '<button type="button" class="btn btn-outline-light clickable" title="Play All" onclick=\'Tidal("play","pagetracks","",event)\'>Play All</button>';
	 
	    header.innerHTML = str;
	    header.classList.add('group-header');
	    cardContainer.appendChild(header);

	    var tbl = document.createElement('ul');
	    if (phone) tbl.classList.add('phone');

    	    var tr = document.createElement('li');
    	    tr.innerHTML = '<span class="track-cover"></span>'+
    	  '<div class="track-title-mobile">'+
    	  '<span class="track-title">Title</span><span class="track-artist">Artist</span>'+
	  '</div>'+
    	  '<span class="track-album">Album</span><span class="track-duration">Time</span>'+
    	  '<span class="track-fav"></span><span class="track-action"></span>'
    	    tr.classList.add('tracklist-label');
    	    tbl.appendChild(tr);

	    if (apipath && len>0) { 
		cardContainer.setAttribute('data-total',node.pagedList.totalNumberOfItems);
		cardContainer.setAttribute('data-offset',len);
		cardContainer.setAttribute('data-apipath',node.pagedList.dataApiPath);
	    }
/*    	  } else {
	    if (len>0) {
	    	var offset = parseInt(cardContainer.getAttribute('data-offset'));
		offset = offset + len;
		cardContainer.setAttribute('data-offset',offset);
	    }
    	    var tbl = cardContainer.getElementsByClassName('tracklist')[0];
    	  }*/
	  for (var j = 0; j < len; j++) { // add track to table
	    item = node.pagedList.items[j];
	    var cover = item.album.cover;
	    if (cover == null) {
		var link = 'icons/disc.svg'; 
	    }
	    else {
		cover = cover.replace(/-/g,'\/');
		var link = 'https://resources.tidal.com/images/' + cover + '/80x80.jpg';
	    }

	    var tr = document.createElement('li');
	    tr.classList.add('track-item');
	    tr.setAttribute('data-type','track');
	    tr.setAttribute('data-title',item.title);
	    tr.setAttribute('data-id',item.id);
	    tr.innerHTML = '<span class="track-cover">'+
	    '<div class="imgmini2">'+
	    '<div class="item-wrapper">'+
	    '<a class="clickable" onclick=\'Tidal("play","track","'+item.id+'",event); return false;\' title="Play">'+
	    '<img class="lozad" src="icons/disc.svg" data-src="'+link+'">'+
//	    '<img class="lozad" src="icons/disc.svg" data-src="'+link+'" width="50px" height="50px">'+
	    '<div class="overlay">'+
                '<button class="btn material-icons clickable" type="button" role="button">play_arrow</button>'+
	    '</div></a></div></div></span>'+
    	    '<div class="track-title-mobile">'+
	    '<span class="track-title"><a class="clickable" onclick=\'Tidal("play","track","'+item.id+'",event); return false;\' title="'+item.title+'">'+item.title+'</a></span>'+
	    '<span class="track-artist"><a class="clickable" onclick=\'appGoto("Tidal","page","artist__'+item.artists[0].id+'");\' title="'+item.artists[0].name+'">'+item.artists[0].name+'</a></span>'+
	    '</div>'+
	    '<span class="track-album"><a class="clickable" onclick=\'appGoto("Tidal","page","album__'+item.album.id+'");\' title="'+item.album.title+'">'+item.album.title+'</a></span>'+
	    '<span class="track-duration">'+HHMMSS(item.duration)+'</span>'+
	    '<span class="track-fav"><a class="material-icons clickable" onclick=\'Tidal("add","track","'+item.id+'",event); return false;\' title="Add to Queue">add</a></span>'+
	    '<span class="track-action"><a class="material-icons clickable" onclick="showMenu2(this.parentNode,event);" title="Show menu">more_vert</a></span>';
    	    tbl.appendChild(tr);
	  }
//	  if (!request.data.offset) {
	    tbl.classList.add('tracklist');
            cardContainer.appendChild(tbl);
//    	  }
	}
	
	else if (node.type == "PLAYLIST_LIST") {
	  var video = false;
	  if (obj.title == 'Videos') var video = true;
//	  console.log('playlist_list '+page);
	  if (narr.indexOf(node.title) == -1) {
	    len = node.pagedList.items.length;
	    var title = node.title;
	    if (!title) title = obj.title;
//	    if (hddr != node.title) {
	      var header = document.createElement('div');
	      title = title.replace('Suggested ','');
	      var str = '<h5>' + title + '</h5>';

	      var more = node.showMore;
	      if (more) 
	        str += '<a class="clickable" onclick=\'appGoto("Tidal","page","'+more.apiPath +'");\'>'+more.title+'</a>';
	    
	      header.innerHTML = str;
	      header.classList.add('group-header');
	      cardContainer.appendChild(header);
//            }
            if (!phone) {
	      var div = document.createElement('div');
	      if (flag) {
    		div.classList.add('swiper-container');
    		div.classList.add('swiper-1x');
    	      }
	      var div2 = document.createElement('div');
	      if (flag)
    		div2.classList.add('swiper-wrapper')
    	      else
    		div2.classList.add('row');
              div.appendChild(div2);
            } else {
	      var div2 = document.createElement('div');
    	      div2.classList.add('row');
    	      div2.classList.add('phone');
            }
            
	    if (apipath && len>0) { 
		cardContainer.setAttribute('data-total',node.pagedList.totalNumberOfItems);
		cardContainer.setAttribute('data-offset',len);
		cardContainer.setAttribute('data-apipath',node.pagedList.dataApiPath);
	    }
	    for (var j = 0; j < len; j++) {
	      item = node.pagedList.items[j];
	      var card = document.createElement('div');
//    	      card.classList.add('my-item');
	      if (!phone && flag) card.classList.add('swiper-slide');
    	      card.classList.add('grid-item');
    	     
    	      var img = item.squareImage;
	      if (img == null) {
    		var link = 'icons/disc.svg';
    	      }
	      else {
    		img = img.replace(/-/g,'\/');
    		var link = 'https://resources.tidal.com/images/'+img+'/160x160.jpg';
    	      }
	      icon = 'favorite_border';
    	      var str = '<div class="card1">' +
                        ' <a class="clickable" data-type="playlist" data-id="'+item.uuid+'" onclick=\'appGoto("Tidal","page","playlist__'+item.uuid+'");\'>'+
                        ' <div class="item-wrapper'+(video?' ensemble':'')+'">'+
                        ' <img src="icons/disc.svg" data-src="'+link+'" width="100%" height="100%" ' +
                        (!phone && flag ? 'class="swiper-lazy">':'class="lozad">');
              if (phone)
    		str +=  ' <div class="aplay">'+
                        '     <button class="btn material-icons shadow-none" type="button" role="button" onclick=\'Tidal("play",' + (video ? '"v':'"')+ 'playlist","'+item.uuid+'",event);\' title="Play">play_arrow</button>'+
                        ' </div>'
	      else
                str +=  ' <div class="overlay">'+
                        '     <button class="btn favbtn material-icons shadow-none" type="button" role="button" onclick=\'Tidalfav("playlist","'+item.uuid+'",event,this);\' title="">'+icon+'</button>'+
                        '     <button class="btn material-icons shadow-none" type="button" role="button" onclick=\'Tidal("play",' + (video ? '"v':'"')+ 'playlist","'+item.uuid+'",event);\' title="Play">play_arrow</button>'+
                        (video ? '' : '     <button class="btn material-icons clickable" type="button" role="button" onclick="showMenu2(this,event)" title="Show menu">more_vert</button>')+
                        ' </div>';
              str += '</div></a>'+
                     ' <span class="item-title talb clickable" onclick=\'appGoto("Tidal","page","playlist__'+item.uuid+'");\' title="'+item.title+'">' + item.title + '</span>' +
                     '</div>'; 
              card.innerHTML = str;
    	      div2.appendChild(card);
    	      if (!apipath && phone && j == 5) break;
	    
	    } //for j=
	    if (!phone) {
	    if (flag) {
		var pagina = document.createElement('div');
		pagina.classList.add('swiper-scrollbar');
		div.appendChild(pagina);

		var but = document.createElement('div');
		but.classList.add('swiper-button-next');
		div.appendChild(but);
		var but = document.createElement('div');
		but.classList.add('swiper-button-prev');
		div.appendChild(but);
	    }

//	  if (!request.data.offset)
    	    cardContainer.appendChild(div);
    	    } else {
    	    cardContainer.appendChild(div2);
    	    }
	  } //narr.indexof
	} //if node.type
      } //for i=
    
     } //if card.Conteiner

//   cardContainer.classList.remove('hide');
   setPlaying();
   observer.observe();
   modalLoader.hide();

//   if (!phone && flag) {

   if (!phone) {
    var swiper2x = new Swiper('.swiper-2x', {
        slidesPerView: 'auto',
        slidesPerColumn: 2,
        slidesPerGroup: 4,
//    	freeMode: true,
        scrollbar: {
    	 el: '.swiper-scrollbar',
    	 hide: true,
        },
/*	visibilityFullFit: true,
        autoResize: false,*/
        navigation: {
    	nextEl: '.swiper-button-next',
    	prevEl: '.swiper-button-prev',
         },
//        preloadImages: false,
        lazy: true,
        watchSlidesVisibility:true
    });

    var swiper1x = new Swiper('.swiper-1x', {
        slidesPerView: 'auto',
        slidesPerColumn: 1,
        slidesPerGroup: 3,
//    	freeMode: true,
        scrollbar: {
    	 el: '.swiper-scrollbar',
    	 hide: true,
        },
        navigation: {
    	nextEl: '.swiper-button-next',
    	prevEl: '.swiper-button-prev',
         },
//        preloadImages: false,
        lazy:true,
        watchSlidesVisibility:true
    });
    
   }
   var t1 = performance.now();
   console.log('tidal time:'+ (t1-t0));

}

function parseCredits(obj){
    var title = document.getElementById('radTitle');
    var cardContainer = document.getElementById('radInfo');
    cardContainer.innerHTML = "";

    title.innerHTML = 'Tracks details';

    var nr = obj.tracks.items.length;
    var re = ',\sAssociatedPerformer\s-\s/g';
    
    for (var j = 0; j < nr; j++) {
	var item = obj.tracks.items[j];

	var tr = document.createElement('div');
	var str = '<h2>'+(j+1)+'. '+item.title+'</h2>' +
	'<div>Composer: <a class="clickable" onclick=\'appGoto("Qobuz","page","artist__'+ item.composer.id+'");\'>' + item.composer.name  + '</a></div>' +
	'<h2>Credits</h2>';
	var performer = item.performers;
	performer = performer.replace(new RegExp(', AssociatedPerformer - ','g'),'<br>');
	performer = performer.replace(/^(\w+ \w+),\s(\w+)/g,"<b>$1</b> - $2");
	performer = performer.replace(/<br>(\w+ \w+),\s(\w+)/g,"<br><b>$1</b> - $2");
	tr.innerHTML = str + performer;
    	cardContainer.appendChild(tr);

	var hr = document.createElement('hr');
	cardContainer.appendChild(hr);
    }

    modalRadio.show();
}

function parseTCredits(obj){
    var title = document.getElementById('radTitle');
    var cardContainer = document.getElementById('radInfo');
    cardContainer.innerHTML = "";

    title.innerHTML = 'Tracks details';

    var nr = obj.items.length;
    var re = ',\sAssociatedPerformer\s-\s/g';
    
    for (var j = 0; j < nr; j++) {
	var item = obj.items[j].item;

	var tr = document.createElement('div');
	var str = '<h5>'+(j+1)+'. '+item.title+'</h5>';
	var credits = obj.items[j].credits;
	var nr2 = credits.length;
	for (var k = 0; k < nr2; k++) {
	    var item2 = credits[k];
	    str += '<div class="row"><div class="credits-left">'+item2.type+'</div>'+
	    '<div class="credits-right"><ul class="list-unstyled">';
	    var nr3 = item2.contributors.length;
	    for (var m = 0; m < nr3; m++) {
		str += '<li><a class="clickable" onclick=\'appGoto("Tidal","page","artist__'+ item2.contributors[m].id+'");\'>'+item2.contributors[m].name+'</a></li>';
	    }
	    str += '</ul></div></div>';
	    if (k !== nr2-1) str += '<hr>';
	}
	tr.innerHTML = str;
    	cardContainer.appendChild(tr);

	var hr = document.createElement('hr');
	cardContainer.appendChild(hr);
    }

    modalRadio.show();
}

function creditsTidal(id){
    sendAPI({"cmd": "API_TIDAL_PAGID", "data": {"page": "albuminfo","id":id}}, parseTCredits);
}

function openreview(url){
    var win = window.open('http://pitchfork.com' + url, '_blank');
    win.focus();
}

function creditsQobuz(id){
    sendAPI({"cmd": "API_QOBUZ_PAGID", "data": {"page": "album","id":id}}, parseCredits);
}

function parsePitch(obj,request) {
    var cmd = request.data.cmd;
    var cardContainer = document.getElementById('Pitchbody');
    if (phone) cardContainer.classList.add('phone');
    if (!request.data.offset) cardContainer.innerHTML = "";
    document.getElementById('topTitle').innerHTML = '';


    if (cmd == "bestalbums" || cmd == "bestreissue" || cmd == "rating8" ||
    cmd == "sunday") {
// results.list[] | .title |.artists.display_name |.promoDescription |.pubDate
///   |.tombstone.albums.album |. photos.tout.sizes.list-standart
//    |.tombstone.albums.rating.display_rating
	var len = obj.results.list.length;
        
        if (!request.data.offset) {
	    var div = document.createElement('div');
	    div.classList.add('row');
	    if (len>0) {
		cardContainer.setAttribute('data-offset',len);
	    }
	}
	else {
	    if (len>0) {
	    	var offset = parseInt(cardContainer.getAttribute('data-offset'));
		offset = offset + len;
		cardContainer.setAttribute('data-offset',offset);
	    }
	    if (cardContainer.getElementsByClassName('grid-item').length >0) {
		div = cardContainer.getElementsByClassName('row')[0];
	    }
	}
        for (var i = 0; i < len; i++) {
	    var item = obj.results.list[i];
//	    var rdate = item.pubDate;
	    var img = item.tombstone.albums[0].album.photos.tout.sizes.list; //standart
	    if (item.artists[0]) var artname = item.artists[0].display_name
	    else var artname='Various Artists';
	    var id = item.tombstone.albums[0].id;
	    var rating = item.tombstone.albums[0].rating.display_rating;
	    var rdate = item.tombstone.albums[0].album.release_year;
	    var title = item.title + ' ('+rdate+')';
	    var card = document.createElement('div');
    	    card.classList.add('grid-item');
    	    var query = item.title+'|'+artname;
    	    query = query.replace(/"/g,"");
    	    card.innerHTML = '<div class="card1" id="cardPi' + id + '">' +
//                         ' <a class="clickable" onclick=\'Pitch("album","'+query+'",event)\'>' +
                         ' <a class="clickable">' +
                         ' <div class="prate" onclick=\'openreview("' + item.url + '")\' title="Open Review in New Page">' + rating + '</div>' +
                         ' <div class="item-wrapper"><img class="lozad" src="icons/disc.svg" data-src="'+img+'" width="100%" height="100%">'+
                         ' <div class="overlay">' +
                         '     <button class="btn material-icons clickable" type="button" role="button" onclick=\'Pitch("playtidal","album","'+query+'",event)\' title="Play from Tidal">local_taxi</button>'+
                         '     <button class="btn material-icons clickable" type="button" role="button" onclick=\'Pitch("playqobuz","album","'+query+'",event)\' title="Play from Qobuz">album</button>'+
                         ' </div>' +
                         ' </div></a>'+
                         '  <span class="item-title talb" title="'+title+'" onclick=\'Pitch("album","'+query+'",event)\'>' + title + '</span>' +
                         '  <span class="item-title tart" title="'+artname+'" >'+artname+'</span>' +
//                          '  <span class="item-title tart clickable" >'+rdate+'</span>' +
//                         '  <span class="item-title tart">Rating: '+rating+'</span>' +
                         '</div>'; //dimas
            div.appendChild(card);
        
        }
        if (!request.data.offset) cardContainer.appendChild(div);
    }
    if (cmd == "besttracks") {
	var len = obj.results.list.length;
    	var header = document.createElement('div');
//	var str = '<h5>'+cmd+'</h5>';
//	header.innerHTML = str;
	header.classList.add('group-header');
	cardContainer.appendChild(header);
        if (!request.data.offset) {
	    var tbl = document.createElement('ul');
	    cardContainer.setAttribute('data-offset',len);
    	    var tr = document.createElement('li');
    	    tr.innerHTML = '<span class="track-cover"></span>'+
    	'<div class="track-title-mobile">'+
    	'<span class="track-title">Title</span><span class="track-artist">Artist</span>'+
	'</div>'+
    	'<span class="track-album">Description</span><span class="track-genre">Genre</span><span class="track-action"></span>'
    	    tr.classList.add('tracklist-label');
    	    tbl.appendChild(tr);
	} else {
	    if (len>0) {
	    	var offset = parseInt(cardContainer.getAttribute('data-offset'));
		offset = offset + len;
		cardContainer.setAttribute('data-offset',offset);
	    }
	    var tbl = cardContainer.getElementsByClassName('tracklist')[0];
	}
	for (var j = 0; j < len; j++) { // add track to table
	    var item = obj.results.list[j];
	    if (item.artists[0]) var artname = item.artists[0].display_name
	    else var artname='Various Artists';
	    var genre = item.genres[0].display_name;
	    var cover = item.photos.tout.sizes.list;
	    if (cover == null) {
		var cover = 'icons/disc.svg'; 
	    }
	    var dek = item.dek;
	    var title = item.title;
	    title = title.replace(/“/g,"");
	    title = title.replace(/”/g,"");
	    var tr = document.createElement('li');
	    tr.classList.add('track-item');
	    var query = title+'|'+artname;
	    query = query.replace(/"/g,"");
	    tr.innerHTML = '<span class="track-cover">'+
	    '<div class="imgmini2">'+
	    '<div class="item-wrapper">'+
	    '<a class="clickable" onclick=\'Pitch("playtidal","track","'+query+'",event)\'>'+
	    '<img class="lozad" src="icons/disc.svg" data-src="'+cover+'" width="50px" height="50px">'+
	    '<div class="overlay">'+
                '<button class="btn material-icons clickable" type="button" role="button" onclick=\'Pitch("playtidal","track","'+query+'",event)\' title="Play from Tidal">play_arrow</button>'+
	    '</div>'+
	    '</a></div></div></span>'+
    	    '<div class="track-title-mobile">'+
	    '<span class="track-title"><a class="clickable" onclick=\'Pitch("playtidal","track","'+query+'",event)\' title="'+item.title+'">'+item.title+'</a></span>'+
	    '<span class="track-artist"><a class="">'+artname+'</a></span>'+
	    '</div>'+
	    '<span class="track-info">'+dek+'</span>'+
	    '<span class="track-genre">'+genre+'</span>'+
	    '<span class="track-action"></span>';
    	    tbl.appendChild(tr);
	}
	tbl.classList.add('tracklist');
        if (!request.data.offset) cardContainer.appendChild(tbl);

// results.list[] |.id,.title
    }
    observer.observe();
    modalLoader.hide();
    scrollFlag = false;
}

function parseTidalStatus(obj){
    var el = document.getElementById("navt-status");
    console.log(obj);
    if (obj.status) {
	var div = document.createElement('div');
	div.classList.add('modal-body');
	var tabl = document.createElement('table');
	tabl.classList.add('table');
	tabl.classList.add('table-borderless');
	tabl.innerHTML = '<tbody><tr><td>Status</td><td>'+obj.status+'</td></tr>'+
	'<tr><td>Type</td><td>'+obj.subscription.type+'</td></tr>'+
	'<tr><td>Premium</td><td>'+obj.premiumAccess+'</td></tr>'+
	'<tr><td>Valid Until</td><td>'+ formatDate(obj.validUntil,1)+'</td></tr></tbody>';
	div.appendChild(tabl);
	el.appendChild(div);
    }
}

function tabshow(content,tab){
    if (content == "qmy-content") {
	var s = 'my'+tab.getAttribute('data-tab');
	var q = document.getElementById('Q'+s);
	appGoto('Qobuz','my',s,'0/-/');
    }
    if (content == "tmy-content") {
	var s = 'my'+tab.getAttribute('data-tab');
	var q = document.getElementById('T'+s);
	appGoto('Tidal','my',s,'0/-/');
    }
    var id = tab.getAttribute('aria-controls');
    if (content == "navt-content" && id == "navt-status") {
	var el = document.getElementById(id);
	if (el.getElementsByTagName('div').length == 0)
	    sendAPI({"cmd":"API_TIDAL_GROUP","data":{"group":"status"}},parseTidalStatus);
    }
    if (content == "aqtab-content") {
	var el = document.getElementById(id).firstChild;
	var slug = parseInt(el.getAttribute('data-slug'));
	if (slug > 3) {
	    var filter = app.current.filter;
	    if (filter == '-') filter = 'all'
	    if(el.getElementsByTagName('div').length == 0)
		sendAPI({"cmd":"API_QOBUZ_PAGE","data":{"page":"albums_"+slug,"filter":filter,"offset":0}},parseQobuzPlists);
	}
    }
    
    var tabs = tab.parentNode.getElementsByClassName('nav-link');
    var len = tabs.length;
    for (var i = 0; i < len; i++) {
	tabs[i].classList.remove('active');
    }
    tab.classList.add('active');

    var cont = document.getElementById(content);
    var tabsc = cont.getElementsByClassName('tab-pane');
    var len = tabsc.length;
    for (var i = 0; i < len; i++) {
	tabsc[i].classList.remove('active');
	tabsc[i].classList.remove('show');
    }
    document.getElementById(id).classList.add('active');
    document.getElementById(id).classList.add('show');

//    document.getElementById(id).show();
}

function parseQobuzPlists(obj, request){
var clas, icon, favtit;
    var page = request.data.page;
    var ar = page.split("_");
    page = ar[0];
    if (page == 'playlists') {
	var q = document.getElementById('pqtab-content');
//	var div3 = q.getElementsByClassName('active')[0].getElementsByClassName('row')[0];
	var div3 = q.getElementsByClassName('active')[0].firstChild;
    
	var offset = parseInt(div3.getAttribute('data-offset'));
	var nr = obj.playlists.items.length;
	offset = offset + nr;
	div3.setAttribute('data-offset',offset);
	for (var j = 0; j < nr; j++) {
	    var item = obj.playlists.items[j];
	    var card = document.createElement('div');
    	    card.classList.add('grid-item');
	    icon = 'favorite_border';
	    
    	    var str = '<div class="card1">' +
                      ' <a class="clickable" onclick=\'appGoto("Qobuz","page","playlist__'+ item.id+'");\'>' +
                      ' <div class="item-wrapper splaylist"><img src="icons/disc.svg" data-src="'+item.image_rectangle[0]+'" width="100%" height="100%" class="lozad">';
            if (phone)
    		str +=  ' <div class="aplay">'+
                	'     <button class="btn material-icons shadow-none" type="button" role="button" onclick=\'Qobuz("play","playlist","'+item.id+'",event)\' title="Play">play_arrow</button>'+
                    	' </div>'
	    else
                str +=  ' <div class="overlay">' +
                      '     <button class="btn favbtn material-icons shadow-none" type="button" role="button" onclick=\'Qobuzfav("playlist","'+item.id+'",event,this);\' title="">'+icon+'</button>'+
                      '     <button class="btn material-icons shadow-none" type="button" role="button" onclick=\'Qobuz("play","playlist","'+item.id+'",event)\' title="Play">play_arrow</button>'+
                      '     <button class="btn material-icons shadow-none" type="button" role="button" onclick="showMenu2(this,event);">more_vert</button>'+
                      ' </div>';
            str += ' </div></a>' +
                       '  <span class="item-title talb clickable" title="'+item.name+'" onclick=\'appGoto("Qobuz","page","playlist__'+ item.id+'");\' title="' + item.name + '">' + item.name + '</span>' +
                       '</div>'; 
            card.innerHTML = str;
    	    div3.appendChild(card);
        }
    }
    if (page == 'albums') {
	var slug = ar[1];
	var q = document.getElementById('aqtab-content');
//	var div3 = q.getElementsByClassName('active')[0].getElementsByClassName('row')[0];
	var div3 = q.getElementsByClassName('active')[0].firstChild;
    
	var offset = parseInt(div3.getAttribute('data-offset'));
	var nr = obj.albums.items.length;
	if (slug == 3) {
	    for (var j = 0; j < nr; j++) {
		var item = obj.albums.items[j];
		var tr = document.createElement('li');
		var img = item.image.thumbnail;
		tr.innerHTML = '<span class="track-cover">'+
		'<div class="imgmini2">'+
		'<div class="item-wrapper">'+
		'<a class="clickable" onclick=\'Qobuz("play","album","'+item.id+'",event);\'>'+
		'<img class="lozad" src="icons/disc.svg" data-src="'+img+'" width="50px" height="50px">'+
		'<div class="overlay">'+
            	    '<button class="btn material-icons clickable" type="button" role="button">play_arrow</button>'+
		'</div></a></div></div></span>'+
		'<span class="track-top">'+(j + offset + 1)+'</span>'+
    		'<div class="track-title-mobile">'+
		'<span class="track-release" title="'+item.title+'"><a class="clickable" onclick=\'appGoto("Qobuz","page","album__' + item.id+'");\' title="'+item.title+'">'+item.title+'</a></span>'+
		'<span class="track-artist" title="'+item.artist.name+'"><a class="clickable" onclick=\'appGoto("Qobuz","page","artist__' + item.artist.id+'");\' title="'+item.artist.name+'">'+item.artist.name+'</a></span>'+
		'</div>'+
		'<span class="track-label" title="'+item.label.name+'"><a class="clickable" onclick=\'appGoto("Qobuz","page","label__' + item.label.id+'");\' title="'+item.label.name+'">'+item.label.name+'</a></span>'+
		'<span class="track-genre" title="'+item.genre.name+'">'+item.genre.name+'</span>'+
		'<span class="track-fav"><a class="clickable material-icons" onclick=\'Qobuz("add","album","'+item.id+'",event); return false;\' title="Add to Queue">add</a></span>'+
		'<span class="track-action"><a class="clickable material-icons" onclick="showMenu2(this.parentNode,event);" title="Show menu">more_vert</a></span>';
    		tr.classList.add('topborder');
		tr.setAttribute('data-type','album');
		tr.setAttribute('data-title',item.title);
		tr.setAttribute('data-id',item.id);
    		div3.appendChild(tr);
	    }
	} else {
	    for (var j = 0; j < nr; j++) {
		var item = obj.albums.items[j];
		var card = document.createElement('div');
		card.classList.add('grid-item');
		icon = 'favorite_border'; 
        	var str = '<div class="card1">' +
                     ' <a class="clickable" data-id="'+item.id+'" data-type="album" data-name="' + item.title + '" onclick=\'appGoto("Qobuz","page","album__'+ item.id+'");\'>'+
                     ' <div class="item-wrapper"><img src="icons/disc.svg" data-src="'+item.image.small+'" width="100%" height="100%" class="lozad">';
                if (phone)
    		    str +=  ' <div class="aplay">'+
                    	    '     <button class="btn material-icons shadow-none" type="button" role="button" onclick=\'Qobuz("play","album","'+item.id+'",event);\' title="Play">play_arrow</button>'+
                    	    ' </div>'+
                    	    '</div></a>'+
                    	    '<div class="card-tit">'+
                    	    ' <div>'+
                    	    '  <span class="item-title talb clickable" title="'+item.title+'" onclick=\'appGoto("Qobuz","page","album__'+ item.id+'");\' title="' + item.title + '">' + item.title + '</span>' +
                    	    '  <span class="item-title tart clickable" title="'+item.artist.name+'" onclick=\'appGoto("Qobuz","page","artist__'+ item.artist.id+'");\' title="'+item.artist.name+'">'+item.artist.name+'</span>' +
                    	    ' </div>'+
                    	    ' <div class="title-button"><button class="btn material-icons shadow-none" onclick="showMenu2(this,event)">more_vert</button></div>' +
                    	    '</div>'+
                	    '</div>'
		else
                     str += ' <div class="overlay">' +
                     '     <button class="btn favbtn material-icons shadow-none" type="button" role="button" onclick=\'Qobuzfav("album","'+item.id+'",event,this);\' title="">'+icon+'</button>'+
                     '     <button class="btn material-icons shadow-none" type="button" role="button" onclick=\'Qobuz("play","album","'+item.id+'",event);\' title="Play">play_arrow</button>'+
                     '     <button class="btn material-icons shadow-none" type="button" role="button" onclick="showMenu2(this,event);">more_vert</button>'+
                     ' </div>'+
            	     '</div></a>' +
                     '  <span class="item-title talb clickable" title="'+item.title+'" onclick=\'appGoto("Qobuz","page","album__'+ item.id+'");\' title="' + item.title + '">' + item.title + '</span>' +
                     '  <span class="item-title tart clickable" title="'+item.artist.name+'" onclick=\'appGoto("Qobuz","page","artist__'+ item.artist.id+'");\' title="'+item.artist.name+'">'+item.artist.name+'</span>' +
                     '</div>'; 
                card.innerHTML = str;
        	div3.appendChild(card);
	    }
	
	}
	offset = offset + nr;
	div3.setAttribute('data-offset',offset);

    }
    observer.observe();
    modalLoader.hide();
    scrollFlag = false;
}

function parseQobuz(obj, request){
var t0 = performance.now();
var nr = 0, total = 0;
var item;
var node;
var clas, icon, favtit;
    if (request.data.page) var page = request.data.page;

    if (page == "explore") {
	var cardContainer = document.getElementById('Qobuz'+page);
    }
    else {
	var cardContainer = document.getElementById('Qobuzpage');
        
	if (!request.data.offset) {
    	    while (cardContainer.firstChild) {
    		cardContainer.removeChild(cardContainer.firstChild);
    	    };
    	}
    }

    cardContainer.classList.remove('hide');
    if (page == 'playlists') {
	document.getElementById('topTitle').innerHTML = '';
	var card = document.createElement('div');
	card.innerHTML = '<h5>Playlists</h5>';
	card.classList.add('group-header');
	cardContainer.appendChild(card);

	var nav = document.createElement('nav');
	nav.classList.add('sticky');
	var str = '<div id="pqtabs" class="nav nav-tabs" role="tablist">';
	var len = obj.tags.items.length;
        for (var i = 0; i < len; i++) {
	    var item2 = obj.tags.items[i];
	    var label = JSON.parse(item2.name);
    	    str += '<a class="nav-item2 nav-link clickable' + (i==0 ? ' active':'') + '" id="nav-pq'+i+'-tab" data-toggle="tab" aria-controls="nav-pq'+i+'" aria-selected="'+(i==0 ? 'true':'false')+'" role="tab" onclick=\'tabshow("pqtab-content",this)\'>'+label.en+'</a>';
        }
        str+='</div>';
	nav.innerHTML = str;
	cardContainer.appendChild(nav);

	var div = document.createElement('div');
	div.id = 'pqtab-content';
	div.classList.add('tab-content');
	cardContainer.appendChild(div);
        for (var i = 0; i < len; i++) {
	    var item2 = obj.tags.items[i];
	    var div2 = document.createElement('div');
	    div2.classList.add('tab-pane');
	    if (i == 0) div2.classList.add('active');
	    div2.setAttribute('id','nav-pq'+i);
	    div2.setAttribute('role','tabpanel');
	    div2.setAttribute('aria-labelledby','nav-pq'+i+'-tab');
	    div.appendChild(div2);

	    var div3 = document.createElement('div');
	    div3.classList.add('row');

	    div2.appendChild(div3);

	    nr = item2.playlists.items.length;
	    total = item2.playlists.total;
	    div3.setAttribute('data-total',total);
	    div3.setAttribute('data-offset',nr);
	    div3.setAttribute('data-slug',item2.slug);
	    for (var j = 0; j < nr; j++) {
		var item = item2.playlists.items[j];
		var card = document.createElement('div');
    		card.classList.add('grid-item');
		icon = 'favorite_border';
    		var str = '<div class="card1">' +
                      ' <a class="clickable" onclick=\'appGoto("Qobuz","page","playlist__'+ item.id+'");\'>' +
                      ' <div class="item-wrapper splaylist"><img src="icons/disc.svg" data-src="'+item.image_rectangle[0]+'" width="100%" height="100%" class="lozad">';
                if (phone)
    		    str +=  ' <div class="aplay">'+
                    	    '     <button class="btn material-icons shadow-none" type="button" role="button" onclick=\'Qobuz("play","playlist","'+item.id+'",event)\' title="Play">play_arrow</button>'+
                    	    ' </div>'
		else
                    str +=  ' <div class="overlay">' +
                      '     <button class="btn favbtn material-icons shadow-none" type="button" role="button" onclick=\'Qobuzfav("playlist","'+item.id+'",event,this);\' title="">'+icon+'</button>'+
                      '     <button class="btn material-icons shadow-none" type="button" role="button" onclick=\'Qobuz("play","playlist","'+item.id+'",event)\' title="Play">play_arrow</button>'+
                      '     <button class="btn material-icons shadow-none" type="button" role="button" onclick="showMenu2(this,event);">more_vert</button>'+
                      ' </div>';
                str += ' </div></a>' +
                       '  <span class="item-title talb clickable" title="'+item.name+'" onclick=\'appGoto("Qobuz","page","playlist__'+ item.id+'");\' title="' + item.name + '">' + item.name + '</span>' +
                       '</div>'; 
                card.innerHTML = str;
        	div3.appendChild(card);
	    }
//	    div.appendChild(div2);
	}
	cardContainer.appendChild(div);
    }
    else if (page == 'albums') {
	var card = document.createElement('div');
	card.innerHTML = '<h5>Albums</h5>';
	card.classList.add('group-header');
	cardContainer.appendChild(card);
	var nav = document.createElement('nav');
	nav.classList.add('sticky');
	var str = '<div id="aqtabs" class="nav nav-tabs" role="tablist">';
	var len = obj.layouts.length;
	for (var i = 0; i < len; i++) {
	  var key = obj.layouts[i].container_key;
	  var label = '';
	  if (key == 'container-album-new-releases-full') label = 'Qobuz grand selection'
	  else if(key == 'container-album-recent-releases') label = 'Still trending'
	  else if (key == 'container-album-press-awards') label = 'Press-awards'
	  else if (key == 'container-album-charts') label = 'Top releases on Qobuz';
	  if (label) {
    	    str += '<a class="nav-item2 nav-link clickable' + (i==0 ? ' active':'') + '" id="nav-aq'+i+'-tab" data-toggle="tab" aria-controls="nav-aq'+i+'" aria-selected="'+(i==0 ? 'true':'false')+'" role="tab" onclick=\'tabshow("aqtab-content",this)\'>'+label+'</a>';
    	  }
	}
    	str += '<a class="nav-item2 nav-link clickable" id="nav-aq4-tab" data-toggle="tab" aria-controls="nav-aq4" aria-selected="false" role="tab" onclick=\'tabshow("aqtab-content",this)\'>Ideal Discography</a>';
    	str += '<a class="nav-item2 nav-link clickable" id="nav-aq5-tab" data-toggle="tab" aria-controls="nav-aq5" aria-selected="false" role="tab" onclick=\'tabshow("aqtab-content",this)\'>Qobuzissime</a>';
        str+='</div>';
	nav.innerHTML = str;
	cardContainer.appendChild(nav);

	var div = document.createElement('div');
	div.id = 'aqtab-content';
	div.classList.add('tab-content');
	cardContainer.appendChild(div);

	for (var i = 0; i < len; i++) {
	  var key = obj.layouts[i].container_key;
	  if (key == 'container-album-charts') {
	    node = obj.containers[key];
	    if (node.albums.total != 0 ) {
	    nr = node.albums.items.length;
//	    total = node.albums.total;
	    total = 100;

	    var div2 = document.createElement('div');
	    div2.classList.add('tab-pane');
	    if (i == 0) div2.classList.add('active');
	    div2.setAttribute('id','nav-aq'+i);
	    div2.setAttribute('role','tabpanel');
	    div2.setAttribute('aria-labelledby','nav-aq'+i+'-tab');
	    div.appendChild(div2);
	    var tbl = document.createElement('ul');
	    tbl.setAttribute('data-offset',nr);
	    tbl.setAttribute('data-total',total);
	    tbl.setAttribute('data-slug',3);
	  
    	    var tr = document.createElement('li');
    	    tr.innerHTML = '<span class="track-cover"></span><span class="track-top">Top</span>'+
    	    '<div class="track-title-mobile">'+
    	    '<span class="track-release">Release</span><span class="track-artist">Artist</span>'+
    	    '</div>'+
    	    '<span class="track-label">Label</span>'+
    	    '<span class="track-genre">Genre</span>'+
    	    '<span class="track-fav"></span><span class="track-action"></span>'
    	    tr.classList.add('tracklist-label');
	    tr.classList.add('top-tracklist');
    	    tbl.appendChild(tr);
	    for (var j = 0; j < nr; j++) {
		item = node.albums.items[j];

		var tr = document.createElement('li');
		var img = item.image.thumbnail;
		tr.innerHTML = '<span class="track-cover">'+
		'<div class="imgmini2">'+
		'<div class="item-wrapper">'+
		'<a class="clickable" onclick=\'Qobuz("play","album","'+item.id+'",event);\'>'+
		'<img class="lozad" src="icons/disc.svg" data-src="'+img+'" width="50px" height="50px">'+
		'<div class="overlay">'+
            	    '<button class="btn material-icons clickable" type="button" role="button">play_arrow</button>'+
		'</div></a></div></div></span>'+
		'<span class="track-top">'+(j<9 ? '0'+(j+1):(j+1))+'</span>'+
    		'<div class="track-title-mobile">'+
		'<span class="track-release" title="'+item.title+'"><a class="clickable" onclick=\'appGoto("Qobuz","page","album__' + item.id+'");\' title="'+item.title+'">'+item.title+'</a></span>'+
		'<span class="track-artist" title="'+item.artist.name+'"><a class="clickable" onclick=\'appGoto("Qobuz","page","artist__' + item.artist.id+'");\' title="'+item.artist.name+'">'+item.artist.name+'</a></span>'+
		'</div>'+
		'<span class="track-label" title="'+item.label.name+'"><a class="clickable" onclick=\'appGoto("Qobuz","page","label__' + item.label.id+'");\' title="'+item.label.name+'">'+item.label.name+'</a></span>'+
		'<span class="track-genre" title="'+item.genre.name+'">'+item.genre.name+'</span>'+
		'<span class="track-fav"><a class="clickable material-icons" onclick=\'Qobuz("add","album","'+item.id+'",event); return false;\' title="Add to Queue">add</a></span>'+
		'<span class="track-action"><a class="clickable material-icons" onclick="showMenu2(this.parentNode,event);" title="Show menu">more_vert</a></span>';
    		tbl.appendChild(tr);
    		tr.classList.add('topborder');
		tr.setAttribute('data-type','album');
		tr.setAttribute('data-title',item.title);
		tr.setAttribute('data-id',item.id);
	    } //for
	    tbl.classList.add('tracklist');
	    tbl.classList.add('top-tracklist');
            div2.appendChild(tbl);
	    }
	  }
	  
	  if (key == 'container-album-new-releases-full' ||
	  key == 'container-album-recent-releases' ||
	  key == 'container-album-press-awards') {
	    var slug = key.replace('container-album-','');
	    if (slug == 'new-releases-full') {
		slug = 0;
	    } else
	    if (slug == 'recent-releases') {
		slug = 1;
	    } else
	    if (slug == 'press-awards') {
		slug = 2;
	    }
	    node = obj.containers[key];
	    var div2 = document.createElement('div');
	    div2.classList.add('tab-pane');
	    if (i == 0) div2.classList.add('active');
	    div2.setAttribute('id','nav-aq'+i);
	    div2.setAttribute('role','tabpanel');
	    div2.setAttribute('aria-labelledby','nav-aq'+i+'-tab');
	    div.appendChild(div2);
	
	    var div3 = document.createElement('div');
	    div3.classList.add('row');
	    div2.appendChild(div3);
	    if (node.albums) {
		nr = node.albums.items.length;
		total = node.albums.total;
		div3.setAttribute('data-offset',nr);
		div3.setAttribute('data-total',total);
		div3.setAttribute('data-slug',slug);
		for (var j = 0; j < nr; j++) {
		  item = node.albums.items[j];
		  var card = document.createElement('div');
		  card.classList.add('grid-item');
		  icon = 'favorite_border';
        	  var str = '<div class="card1">' +
                     ' <a class="clickable" data-id="'+item.id+'" data-type="album" data-name="' + item.title + '" onclick=\'appGoto("Qobuz","page","album__'+ item.id+'");\'>'+
                     ' <div class="item-wrapper"><img src="icons/disc.svg" data-src="'+item.image.small+'" width="100%" height="100%" class="lozad">';
                  if (phone)
    		    str +=  ' <div class="aplay">'+
                    	    '     <button class="btn material-icons shadow-none" type="button" role="button" onclick=\'Qobuz("play","album","'+item.id+'",event);\' title="Play">play_arrow</button>'+
                    	    ' </div>'+
                    	    '</div></a>'+
                    	    '<div class="card-tit">'+
                    	    ' <div>'+
                    	    '  <span class="item-title talb clickable" title="'+item.title+'" onclick=\'appGoto("Qobuz","page","album__'+ item.id+'");\' title="' + item.title + '">' + item.title + '</span>' +
                    	    '  <span class="item-title tart clickable" title="'+item.artist.name+'" onclick=\'appGoto("Qobuz","page","artist__'+ item.artist.id+'");\' title="'+item.artist.name+'">'+item.artist.name+'</span>' +
                    	    ' </div>'+
                    	    ' <div class="title-button"><button class="btn material-icons shadow-none" onclick="showMenu2(this,event)">more_vert</button></div>' +
                    	    '</div>'+
                	    '</div>'
		  else
                     str += ' <div class="overlay">' +
                     '     <button class="btn favbtn material-icons shadow-none" type="button" role="button" onclick=\'Qobuzfav("album","'+item.id+'",event,this);\' title="">'+icon+'</button>'+
                     '     <button class="btn material-icons shadow-none" type="button" role="button" onclick=\'Qobuz("play","album","'+item.id+'",event);\' title="Play">play_arrow</button>'+
                     '     <button class="btn material-icons shadow-none" type="button" role="button" onclick="showMenu2(this,event);">more_vert</button>'+
                     ' </div>'+
            	     '</div></a>' +
                     '  <span class="item-title talb clickable" title="'+item.title+'" onclick=\'appGoto("Qobuz","page","album__'+ item.id+'");\' title="' + item.title + '">' + item.title + '</span>' +
                     '  <span class="item-title tart clickable" title="'+item.artist.name+'" onclick=\'appGoto("Qobuz","page","artist__'+ item.artist.id+'");\' title="'+item.artist.name+'">'+item.artist.name+'</span>' +
                     '</div>'; 
                  card.innerHTML = str;
        	  div3.appendChild(card);
		} //for
	    } // if
	  } //if

      } //for
//ideal discography
	var div2 = document.createElement('div');
	div2.classList.add('tab-pane');
	div2.setAttribute('id','nav-aq4');
	div2.setAttribute('role','tabpanel');
	div2.setAttribute('aria-labelledby','nav-aq4-tab');

	var div3 = document.createElement('div');
	div3.classList.add('row');
	div3.setAttribute('data-offset',0);
	div3.setAttribute('data-total',100);
	div3.setAttribute('data-slug',4);
	div2.appendChild(div3);

	div.appendChild(div2);

	var div2 = document.createElement('div');
	div2.classList.add('tab-pane');
	div2.setAttribute('id','nav-aq5');
	div2.setAttribute('role','tabpanel');
	div2.setAttribute('aria-labelledby','nav-aq5-tab');

	var div3 = document.createElement('div');
	div3.classList.add('row');
	div3.setAttribute('data-offset',0);
	div3.setAttribute('data-total',100);
	div3.setAttribute('data-slug',5);
	div2.appendChild(div3);

	div.appendChild(div2);
    }
//    if (page == 'explore' || page == 'albums') {
    if (page == 'explore') {
	document.getElementById('topTitle').innerHTML = '';
    if (cardContainer.getElementsByTagName('div').length == 0) {
      var len = obj.layouts.length;
      for (var i = 0; i < len; i++) {
	var key = obj.layouts[i].container_key;
//	console.log(key);
	node = obj.containers[key];
	var label = node.label;
	if (key == 'container-featuredPlaylists') {
	    label = 'The Qozuz Playlists';
	    nr = node.playlists.items.length;
	    var card = document.createElement('div');
	    card.innerHTML = '<h5>'+label+'</h5><a class="clickable" onclick=\'appGoto("Qobuz","page","playlists");\'>See all</a>';
	    card.classList.add('group-header');
            cardContainer.appendChild(card);

	    if (phone) {
	      var div2 = document.createElement('div');
    	      div2.classList.add('row');
    	      div2.classList.add('phone');
	    } else {
	      var div = document.createElement('div');
    	      div.classList.add('swiper-container');
    	      div.classList.add('swiper-1x');
	      var div2 = document.createElement('div');
    	      div2.classList.add('swiper-wrapper');
              div.appendChild(div2);
            }
	    for (var j = 0; j < nr; j++) {
		item = node.playlists.items[j];
		var card = document.createElement('div');
//    		card.classList.add('my-item');
    		if (!phone) card.classList.add('swiper-slide');
    		card.classList.add('grid-item');
    		
		icon = 'favorite_border';
        	var str = '<div class="card1">' +
                             ' <a class="clickable" data-id="'+item.id+'" data-type="playlist" data-name="'+item.name+'" onclick=\'appGoto("Qobuz","page","playlist__'+ item.id+'");\'>' +
                             ' <div class="item-wrapper splaylist"><img src="icons/disc.svg" data-src="'+item.image_rectangle[0]+'" width="100%" height="100%" class="'+(phone ? 'lozad' : 'swiper-lazy')+'">';
                if (phone)
    		    str +=  ' <div class="aplay">'+
                            '     <button class="btn material-icons shadow-none" type="button" role="button" onclick=\'Qobuz("play","playlist","'+item.id+'",event);\' title="Play">play_arrow</button>'+
                    	    ' </div>'
		else
                    str +=  ' <div class="overlay">' +
                             '     <button class="btn favbtn material-icons shadow-none" type="button" role="button" onclick=\'Qobuzfav("playlist","'+item.id+'",event,this);\' title="">'+icon+'</button>'+
                             '     <button class="btn material-icons shadow-none" type="button" role="button" onclick=\'Qobuz("play","playlist","'+item.id+'",event);\' title="Play">play_arrow</button>'+
                             '     <button class="btn material-icons shadow-none" type="button" role="button" onclick="showMenu2(this,event);">more_vert</button>'+
                             ' </div>';
                str += ' </div></a>'+
                       '  <span class="item-title talb clickable" title="'+item.name+'" onclick=\'appGoto("Qobuz","page","playlist__'+ item.id+'");\' title="' + item.name + '">' + item.name + '</span>' +
                       '</div>'; //dimas
                card.innerHTML = str;
        	div2.appendChild(card);
        	if (phone && j==5) break;
	    }
	    if (!phone) {
	      var pagina = document.createElement('div');
	      pagina.classList.add('swiper-pagination');
	      div.appendChild(pagina);

	      var but = document.createElement('div');
	      but.classList.add('swiper-button-next');
	      div.appendChild(but);
	      var but = document.createElement('div');
	      but.classList.add('swiper-button-prev');
	      div.appendChild(but);

              cardContainer.appendChild(div);
	    } else
    	      cardContainer.appendChild(div2);
	}
	if (key == 'container-album-new-releases' || key == 'container-explore' ||
	    (key == 'container-album-of-the-week' && page == 'explore') ||
	    key == 'container-album-new-releases-full' || key == 'container-album-recent-releases' ||
	    key == 'container-album-press-awards') {
	   if (node.albums && node.albums.items) { //check
	    nr = node.albums.items.length;
	    if (key == 'container-album-new-releases') label = 'New releases'
	    else if (key == 'container-album-of-the-week') label = 'Album of the Week'
	    else if (key == 'container-explore') label = 'The Taste of Qobuz';
	    else if (key == 'container-album-new-releases-full') label = 'Qobuz grand selection'
	    else if (key == 'container-album-recent-releases') label = 'Still trending'
	    else if (key == 'container-album-press-awards') label = 'Press-awards'
	    var card = document.createElement('div');
	    
	    if (label == 'New releases')
		card.innerHTML = '<h5>'+label+'</h5><a class="clickable" onclick=\'appGoto("Qobuz","page","albums");\'>See all</a>'
	    else 
		card.innerHTML = '<h5>'+label+'</h5>';
	    card.classList.add('group-header');
            cardContainer.appendChild(card);

	    if (phone) {
	      var div2 = document.createElement('div');
    	      div2.classList.add('row');
    	      div2.classList.add('phone');
    	    } else {
	      var div = document.createElement('div');
    	      div.classList.add('swiper-container');
    	      div.classList.add('swiper-1x');
	      var div2 = document.createElement('div');
    	      div2.classList.add('swiper-wrapper');
              div.appendChild(div2);
            }
	    for (var j = 0; j < nr; j++) {
		item = node.albums.items[j];
		var card = document.createElement('div');
//    		card.classList.add('my-item');
    		if (!phone) card.classList.add('swiper-slide');
    		card.classList.add('grid-item');
		icon = 'favorite_border';
        	var str = '<div class="card1" id="card' + item.id + '">' +
                             ' <a class="clickable" data-id="'+item.id+'" data-type="album" data-name="' + item.title + '" onclick=\'appGoto("Qobuz","page","album__'+ item.id+'");\'>'+
                             ' <div class="item-wrapper"><img src="icons/disc.svg" data-src="'+item.image.small+'" width="100%" height="100%" class="'+(phone ? 'lozad' : 'swiper-lazy')+'">';
                if (phone)
    		    str +=  ' <div class="aplay">'+
                            '     <button class="btn material-icons shadow-none" type="button" role="button" onclick=\'Qobuz("play","album","'+item.id+'",event);\' title="Play">play_arrow</button>'+
                    	    ' </div>'+
                    	    '</div></a>'+
                    	    '<div class="card-tit">'+
                    	    ' <div>'+
                            '  <span class="item-title talb clickable" title="'+item.title+'" onclick=\'appGoto("Qobuz","page","album__'+ item.id+'");\' title="' + item.title + '">' + item.title + '</span>' +
                            '  <span class="item-title tart clickable" title="'+item.artist.name+'" onclick=\'appGoto("Qobuz","page","artist__'+ item.artist.id+'");\' title="'+item.artist.name+'">'+item.artist.name+'</span>' +
                    	    ' </div>'+
                    	    ' <div class="title-button"><button class="btn material-icons shadow-none" onclick="showMenu2(this,event)">more_vert</button></div>' +
                    	    '</div>'+
                	    '</div>'
		else
                    str +=  ' <div class="overlay">' +
                            '     <button class="btn favbtn material-icons shadow-none" type="button" role="button" onclick=\'Qobuzfav("album","'+item.id+'",event,this);\' title="">'+icon+'</button>'+
                            '     <button class="btn material-icons shadow-none" type="button" role="button" onclick=\'Qobuz("play","album","'+item.id+'",event);\' title="Play">play_arrow</button>'+
                            '     <button class="btn material-icons shadow-none" type="button" role="button" onclick="showMenu2(this,event);">more_vert</button>'+
                            ' </div>'+
                	    '</div></a>' +
                            '  <span class="item-title talb clickable" title="'+item.title+'" onclick=\'appGoto("Qobuz","page","album__'+ item.id+'");\' title="' + item.title + '">' + item.title + '</span>' +
                            '  <span class="item-title tart clickable" title="'+item.artist.name+'" onclick=\'appGoto("Qobuz","page","artist__'+ item.artist.id+'");\' title="'+item.artist.name+'">'+item.artist.name+'</span>' +
                            '</div>'; //dimas
//		img.setAttribute('src',item.image.small);
		card.innerHTML = str;
        	div2.appendChild(card);
        	if (phone && j==5) break;
	    }
	    if (!phone) {
	      var pagina = document.createElement('div');
//	    pagina.classList.add('swiper-pagination');
	      pagina.classList.add('swiper-scrollbar');
	      div.appendChild(pagina);

	      var but = document.createElement('div');
	      but.classList.add('swiper-button-next');
	      div.appendChild(but);
	      var but = document.createElement('div');
	      but.classList.add('swiper-button-prev');
	      div.appendChild(but);

              cardContainer.appendChild(div);
            } else {
              cardContainer.appendChild(div2);
            }
           }
	} //if key=
	if (key == 'container-album-charts') {
	    label = 'Top releases on Qobuz';
	    if (node.albums.totaln && node.albums.total != 0 ) {
	    nr = node.albums.items.length;
	    var card = document.createElement('div');
	    card.innerHTML = '<h5>'+label+'</h5>';
//	    card.innerHTML = '<h5>'+label+'</h5><a class="clickable" onclick=\'appGoto("Qobuz","page","playlists");\'>See all</a>';
	    card.classList.add('group-header');
            cardContainer.appendChild(card);

	    var tbl = document.createElement('ul');
	  
    	    var tr = document.createElement('li');
    	    tr.innerHTML = '<span class="track-cover"></span><span class="track-top">Top</span>'+
    	    '<div class="track-title-mobile">'+
    	    '<span class="track-release">Release</span><span class="track-artist">Artist</span>'+
    	    '</div>'+
    	    '<span class="track-label">Label</span>'+
    	    '<span class="track-genre">Genre</span>'+
    	    '<span class="track-fav"></span><span class="track-action"></span>'
    	    tr.classList.add('tracklist-label');
	    tr.classList.add('top-tracklist');
    	    tbl.appendChild(tr);
	    for (var j = 0; j < nr; j++) {
		item = node.albums.items[j];

		var tr = document.createElement('li');
		var img = item.image.thumbnail;
		tr.innerHTML = '<span class="track-cover">'+
		'<div class="imgmini2">'+
		'<div class="item-wrapper">'+
		'<a class="clickable" onclick=\'Qobuz("play","album","'+item.id+'",event);\'>'+
		'<img class="lozad" src="icons/disc.svg" data-src="'+img+'" width="50px" height="50px">'+
		'<div class="overlay">'+
            	    '<button class="btn material-icons clickable" type="button" role="button">play_arrow</button>'+
		'</div>'+
		'</a></div></div></span>'+
		'<span class="track-top">'+(j<9 ? '0'+(j+1):(j+1))+'</span>'+
    		'<div class="track-title-mobile">'+
		'<span class="track-release" title="'+item.title+'"><a class="clickable" onclick=\'appGoto("Qobuz","page","album__' + item.id+'");\' title="'+item.title+'">'+item.title+'</a></span>'+
		'<span class="track-artist" title="'+item.artist.name+'"><a class="clickable" onclick=\'appGoto("Qobuz","page","artist__' + item.artist.id+'");\' title="'+item.artist.name+'">'+item.artist.name+'</a></span>'+
		'</div>'+
		'<span class="track-label" title="'+item.label.name+'"><a class="clickable" onclick=\'appGoto("Qobuz","page","label__' + item.label.id+'");\' title="'+item.label.name+'">'+item.label.name+'</a></span>'+
		'<span class="track-genre" title="'+item.genre.name+'">'+item.genre.name+'</span>'+
		'<span class="track-fav"><a class="clickable material-icons" onclick=\'Qobuz("add","album","'+item.id+'",event); return false;\' title="Add to Queue">add</a></span>'+
		'<span class="track-action"><a class="clickable material-icons" onclick="showMenu2(this.parentNode,event);" title="Show menu">more_vert</a></span>';
    		tbl.appendChild(tr);
    		tr.classList.add('topborder');
	    } //for
	    tbl.classList.add('tracklist');
	    tbl.classList.add('top-tracklist');
            cardContainer.appendChild(tbl);
	    }
	}//if
      } //for
    }
    } //if page ==
    else if (page == 'artist') {
	var div = document.createElement('div');
	var img = obj.image;
	if (img == null) {
	    var link = 'icons/disc.svg';
	} else {
    	    var link = img.large;
    	}
    	var fav = checkQFav('artist',obj.id);
	if (fav) {
	    clas = ' fav'; icon = 'favorite'; favtit = 'Remove from My Collection';
	} else {
	    clas = ''; icon = 'favorite_border'; favtit = 'Add to My Collection';
	}

    	if (!phone) {
	    document.getElementById('topTitle').innerHTML = 'Artist: '+ obj.name;
	    var str = '<div class="artist-image">'+
	    '<img class="lozad" src="icons/disc.svg" data-src="'+link+'" width="100%"></div>'+
	    '<div class="artist-text"><h2 title="' + obj.name + '">' + obj.name + '</h2>';
	  
	    if (obj.biography) {
		str+='<div class="bio">'+obj.biography.summary + '</div>';
		str+='<div class="swiper-bio" data-name="'+obj.name+'" style="display:none;">'+obj.biography.content + '</div>';
		str+='<a class="clickable" title="Open full text" onclick="openInfo(this);">Read more</a>';
	    }
	
	    str+='<div class="header-controls">'+
	    '  <button class="btn play material-icons" type="button" role="button" onclick=\'Qobuz("play","artist","'+obj.id+'",event);\' title="Play artist radio">play_arrow</button>'+
	    '  <button class="btn material-icons '+clas+'" type="button" role="button" onclick=\'Qobuzfav("artist","'+obj.id+'",event,this);\' title="'+favtit+'">'+icon+'</button>'+
	    '</div>'+
	    '</div>';
	    div.innerHTML = str;
	    div.classList.add('artist-header');
	    cardContainer.appendChild(div);
	} else {
	    div.classList.add('swiper-container');
    	    div.classList.add('swiper-header');

	    var bg = document.createElement('div');
    	    bg.classList.add('bg-header');
	    bg.style.background = 'url("'+link+'")';
	    bg.style.backgroundSize = 'cover';
	    bg.style.backgroundPositionY = '50%';
	    div.appendChild(bg);

	    var div2 = document.createElement('div');
	    div2.classList.add('swiper-wrapper');
	    div.appendChild(div2);
	    var card = document.createElement('div');
	    card.classList.add('swiper-slide');
	    card.classList.add('card-body-image');
	    card.innerHTML = '<div class="grid-item" style="margin:0 auto;">'+
	    '<img class="swiper-lazy" src="icons/disc.svg" data-src="'+link+'" width="100%;">'+
	    '<span class="item-title talb">'+obj.name+'</span>'+
	    '</div>';
	    div2.appendChild(card);

	    var card2 = document.createElement('div');
	    card2.classList.add('swiper-slide');
	    card2.classList.add('card-body-header');
	    var str = '<h5>'+obj.name+'</h5>';
	    if (obj.biography){
		str+='<div class="bio">'+obj.biography.summary + '</div>';
		str+='<div class="swiper-bio" data-name="'+obj.name+'" style="display:none;">'+obj.biography.content + '</div>';
		str+='<a class="clickable" title="Open full text" onclick="openInfo(this);">Read more</a>';
	    }
	    card2.innerHTML = str;
	    div2.appendChild(card2);
	    cardContainer.appendChild(div);

	    var pg = document.createElement('div');
	    pg.classList.add('swiper-pagination');
	    div.appendChild(pg);
	    
	    var dv2 = document.createElement('div');
	    dv2.innerHTML = '<button class="btn float-left material-icons'+clas+'" type="button" role="button" onclick=\'Qobuzfav("artist","'+obj.id+'",event,this);\' title="'+favtit+'">'+icon+'</button>'+
	    '<button class="btn float-right play material-icons" type="button" role="button" onclick=\'Qobuz("play","artist","'+obj.id+'",event);\' title="Play artist radio">play_arrow</button>';

	    dv2.classList.add('header-controls');
	    dv2.classList.add('w-100');
	    
	    var dv = document.createElement('div');
	    dv.style.height = '20px';
	    dv.style.width = '100%';

	    var swiperhead = new Swiper('.swiper-header', {
		slidesPerView: 1,
    		loop: false,
    		lazy:true,
    		pagination: {
        	el: '.swiper-pagination',
        	     clickable: true,
    		},
	    });

	    cardContainer.appendChild(dv2);
	    cardContainer.appendChild(dv);
	    cardContainer.classList.add('phone');

	}
	if (obj.albums != null) {
	  var str = '<h5>Albums</h5>'
	  var header = document.createElement('div');

	  header.innerHTML = str;
	  header.classList.add('group-header');
	  cardContainer.appendChild(header);
	  
	  nr = obj.albums.items.length;

	  var div = document.createElement('div');

	  var div2 = document.createElement('div');
	  div2.classList.add('row');
	  div.appendChild(div2);
	  for (var j = 0; j < nr; j++) {
	    item = obj.albums.items[j];
	    var card = document.createElement('div');
//    	    card.classList.add('my-item');
    	    card.classList.add('grid-item');
    	    
    	    var cover = item.image;
    	    if (cover == null) {
    		var link = 'icons/disc.svg';
    	    } else {
    		var link = cover.small;
    	    }
	    icon = 'favorite_border';
    	    var str = '<div class="card1">' +
                             (item.hires ? ' <i class="hires material-icons">high_quality</i>' : '')+
                             ' <a class="clickable" onclick=\'appGoto("Qobuz","page","album__'+item.id+'");\'>' +
                             ' <div class="item-wrapper">' +
                             ' <img src="icons/disc.svg" data-src="'+link+'" width="100%" height="100%" class="lozad">';
            if (phone)
    		str +=  ' <div class="aplay">'+
                        '     <button class="btn material-icons shadow-none" type="button" role="button" onclick=\'Qobuz("play","album","'+item.id+'",event)\' title="Play">play_arrow</button>' +
                	' </div>'+
        		'</div></a>'+
                    	'<div class="card-tit">'+
                    	' <div>'+
                	'  <span class="item-title talb clickable" onclick=\'appGoto("Qobuz","page","album__'+item.id+'");\' title="'+item.title+'">' + item.title + '</span>' +
                	'  <span class="item-title tart clickable" onclick=\'appGoto("Qobuz","page","artist__'+item.artist.id+'");\' title="'+item.artist.name+'">' + item.artist.name + '</span>' +
                    	' </div>'+
                    	' <div class="title-button"><button class="btn material-icons shadow-none" onclick="showMenu2(this,event)">more_vert</button></div>' +
                    	'</div>'+
                	'</div>'
	    else
                str +=  ' <div class="overlay">' +
                        '     <button class="btn favbtn material-icons shadow-none" type="button" role="button" onclick=\'Qobuzfav("album","'+item.id+'",event,this);\' title="">'+icon+'</button>'+
                        '     <button class="btn material-icons shadow-none" type="button" role="button" onclick=\'Qobuz("play","album","'+item.id+'",event)\' title="Play">play_arrow</button>' +
                        '     <button class="btn material-icons shadow-none" type="button" role="button" onclick="showMenu2(this,event);">more_vert</button>'+
                        ' </div>'+
        		'</div></a>'+
                	'  <span class="item-title talb clickable" onclick=\'appGoto("Qobuz","page","album__'+item.id+'");\' title="'+item.title+'">' + item.title + '</span>' +
                	'  <span class="item-title tart clickable" onclick=\'appGoto("Qobuz","page","artist__'+item.artist.id+'");\' title="'+item.artist.name+'">' + item.artist.name + '</span>' +
                	'</div>';
    	    card.innerHTML = str;
    	    div2.appendChild(card);
	  } //for

          cardContainer.appendChild(div);
	}
    }
    else if (page == 'album') {
	var div = document.createElement('div');

	var img = obj.image.large;
	if (img == null) {
    	    var link = 'icons/disc.svg';
    	}
	else {
	    var link = img;
    	}
	var fav = checkQFav('album',obj.id);
	if (fav) {
	    clas = ' fav'; icon = 'favorite'; favtit = 'Remove from My Collection';
	} else {
	    clas = ''; icon = 'favorite_border'; favtit = 'Add to My Collection';
	}
	if (!phone) {
	    document.getElementById('topTitle').innerHTML = 'Album: '+ obj.title;
    	    var str = '<div class="artist-image"><img class="lozad" src="icons/disc.svg" data-src="'+link+'" width="100%"></div>'+
	    '<div class="artist-text"><h2>' + obj.title + '</h2>'+
	    '<h5>' + obj.artist.name+'</h5><div>'+obj.genre.name + ' - '+obj.tracks_count+' Tracks - ' + HHMMSS(obj.duration)+'</div>'+
	    '<div>Released by <a class="clickable" onclick=\'appGoto("Qobuz","page","label__'+ obj.label.id+'");\'>'+obj.label.name+'</a> on ' + obj.release_date_download +'</div>';
	    if (obj.description != "" ) {
		str+='<div class="swiper-bio" data-name="'+obj.title+'">' + obj.description + '</div>';
		str+='<a class="clickable" title="Open full text" onclick="openInfo(this);">Read more</a>';
	    }

	    str+='<div class="header-controls">'+
	    '  <button class="btn play material-icons" type="button" role="button" onclick=\'Qobuz("play","album","' + obj.id+'",event);\' title="Play">play_arrow</button>'+
	    '  <button class="btn material-icons" type="button" role="button" onclick=\'Qobuz("playtidal","album","' + obj.id+'",event);\' title="Play from Tidal">local_taxi</button>'+
	    '  <button class="btn material-icons '+clas+'" type="button" role="button" onclick=\'Qobuzfav("album","' + obj.id+'",event,this);\' title="'+favtit+'">'+icon+'</button>'+
	    '  <button class="btn material-icons" type="button" role="button" onclick=\'creditsQobuz("'+obj.id+'");\' title="Credits">info</button>'+
//	    '<button class="btn material-icons" type="button" role="button" onclick="showMenu2(this,event);">more_vert</button>'+
	    '</div>'+
	    '</div>';
	  
	    div.innerHTML = str;
//	  '<p>Copyright: '+node.album.copyright+'</p></div>';
	    div.classList.add('artist-header');
	    cardContainer.appendChild(div);
	} else {
	    div.classList.add('swiper-container');
    	    div.classList.add('swiper-header');

	    var bg = document.createElement('div');
    	    bg.classList.add('bg-header');
	    bg.style.background = 'url("'+link+'")';
	    bg.style.backgroundSize = 'cover';
	    bg.style.backgroundPositionY = '50%';
	    div.appendChild(bg);

	    var div2 = document.createElement('div');
	    div2.classList.add('swiper-wrapper');
	    div.appendChild(div2);
	    var card = document.createElement('div');
	    card.classList.add('swiper-slide');
	    card.classList.add('card-body-image');
	    card.innerHTML = '<div class="grid-item" style="margin:0 auto;">'+
	    '<img class="swiper-lazy" src="icons/disc.svg" data-src="'+link+'" width="100%;">'+
	    '<span class="item-title talb">'+obj.title+'</span>'+
	    '<span class="item-title tart" onclick=\'appGoto("Qobuz","page","artist__' + obj.artist.id+'");\'>'+obj.artist.name+'</span>';
	    '</div>';
	    div2.appendChild(card);

	    var card2 = document.createElement('div');
	    card2.classList.add('swiper-slide');
	    card2.classList.add('card-body-header');
	    card2.innerHTML = '<h5>'+obj.title+'</h5>'+
	    '<small>'+obj.genre.name+'</small>'+
	    '<div>Release by <a class="clickable" onclick=\'appGoto("Qobuz","page","artist__'+ obj.artist.id+'");\'>' + obj.artist.name+'</a></div>'+
	    '<div style="font-size:small">'+obj.tracks_count+' Tracks - ' + beautifyDuration(obj.duration)+'</div>'+
	    '<br/><div>Released by <a class="clickable" onclick=\'appGoto("Qobuz","page","label__'+ obj.label.id+'");\'>'+obj.label.name+'</a></div>'+
	    '<div>'+formatDate( obj.release_date_download)+'</div>';

	    div2.appendChild(card2);
	    cardContainer.appendChild(div);

	    var pg = document.createElement('div');
	    pg.classList.add('swiper-pagination');
	    div.appendChild(pg);
	    
	    var dv2 = document.createElement('div');
	    dv2.innerHTML = '<button class="btn float-left material-icons'+clas+'" type="button" role="button" onclick=\'Qobuzfav("album","' + obj.id+'",event,this);\' title="'+favtit+'">'+icon+'</button>'+
	    '<button class="btn float-right play material-icons" type="button" role="button" onclick=\'Qobuz("play","album","' + obj.id+'",event);\' title="Play">play_arrow</button>'+
	    '<button class="btn btn-small float-right btn-text" type="button" role="button" onclick=\'creditsQobuz("'+obj.id+'");\' title="Credits">i</button>';
	    dv2.classList.add('header-controls');
	    dv2.classList.add('w-100');
	    
	    var dv = document.createElement('div');
	    dv.style.height = '20px';
	    dv.style.width = '100%';

	    var swiperhead = new Swiper('.swiper-header', {
		slidesPerView: 1,
    		loop: false,
    		lazy:true,
    		pagination: {
        	el: '.swiper-pagination',
        	     clickable: true,
    		},
	    });

	    cardContainer.appendChild(dv2);
	    cardContainer.appendChild(dv);
	    cardContainer.classList.add('phone');
	
	}
	var discs = obj.media_count;
	nr = obj.tracks.items.length;
	if (discs > 1) {
	    var div = document.createElement('nav');
	    var str = '<div class="nav nav-tabs" role="tablist">';
	    for (var j = 0; j < discs; j++) {
		str += '<a class="nav-item2 nav-link clickable' + (j==0 ? ' active' : '') + '" id="QVol'+j+'-tab" aria-controls="QVol'+(j+1)+'" data-toggle="tab" role="tab" onclick=\'tabshow("qalbum-content",this);\'>CD '+(j+1)+'</a>';
	    }
	    str += '</div>';
	    div.innerHTML = str;
    	    cardContainer.appendChild(div);

	    var div = document.createElement('div');
	    div.id = 'qalbum-content';
	    div.classList.add('tab-content');
    	    var nvol = 0;
	    for (var j = 0; j < nr; j++) {
	      item = obj.tracks.items[j];
	      var nvol0 = item.media_number;
	      if (nvol !== nvol0) {
		var page1 = document.createElement('div');
		page1.id = 'QVol'+ nvol0;
		page1.classList.add('tab-pane');
		if (nvol == 0) page1.classList.add('active');
		var tbl = document.createElement('ul');
    		var tr = document.createElement('li');
    		tr.innerHTML = '<span class="track-number">#</span>'+
    		'<div class="track-title-mobile">'+
    		'<span class="track-title">Title</span><span class="track-artist">Artist</span>'+
    		'</div>'+
    		'<span class="track-duration">Time</span><span class="track-fav"></span><span class="track-action"></span>';

    		tr.classList.add('tracklist-label');
    		tbl.appendChild(tr);
		tbl.classList.add('tracklist');
		tbl.classList.add('album-tracklist');
    		page1.appendChild(tbl);
		    
		nvol = nvol0;
        	div.appendChild(page1);
	      }

	      var tr = document.createElement('li');
	      tr.innerHTML = '<span class="track-number">'+(j+1)+'</span>'+
    	      '<div class="track-title-mobile">'+
	      '<span class="track-title" title="'+item.title+'"><a onclick=\'Qobuz("play","track","'+item.id+'",event);\'>'+item.title+'</a></span>'+
	      (item.performer ? '<span class="track-artist"><a onclick=\'appGoto("Qobuz","page","artist__' + item.performer.id+'");\'>'+item.performer.name+'</a></span>':'')+
	      '</div>'+
	      '<span class="track-duration">'+HHMMSS(item.duration)+'</span>'+
	      '<span class="track-fav"><a class="clickable material-icons" onclick=\'Qobuz("add","track","'+item.id+'",event); return false;\' title="Add to Queue">add</a></span>'+
	      '<span class="track-action"><a class="clickable material-icons" onclick="showMenu2(this.parentNode,event);" title="Show menu">more_vert</a></span>';
	      tr.classList.add("track-item");
	      tr.setAttribute('data-type','track');
	      tr.setAttribute('data-id',item.id);
	      tr.setAttribute('data-title',item.title);

    	      tbl.appendChild(tr);
	    }
    	    cardContainer.appendChild(div);
	}
	else {

	    var tbl = document.createElement('ul');
	  
    	    var tr = document.createElement('li');
    	    tr.innerHTML = '<span class="track-number">#</span>'+
    	  '<div class="track-title-mobile">'+
    	  '<span class="track-title">Title</span><span class="track-artist">Artist</span>'+
    	  '</div>'+
    	  '<span class="track-duration">Time</span><span class="track-fav"></span><span class="track-action"></span>';
    	    tr.classList.add('tracklist-label');
    	    tbl.appendChild(tr);
	    for (var j = 0; j < nr; j++) {
		item = obj.tracks.items[j];

		var tr = document.createElement('li');
		tr.innerHTML = '<span class="track-number">'+(j+1)+'</span>'+
    		'<div class="track-title-mobile">'+
		'<span class="track-title" title="'+item.title+'"><a onclick=\'Qobuz("play","track","'+item.id+'",event);\'>'+item.title+'</a></span>'+
		(item.performer ? '<span class="track-artist"><a onclick=\'appGoto("Qobuz","page","artist__' + item.performer.id+'");\'>'+item.performer.name+'</a></span>':'')+
		'</div>'+
		'<span class="track-duration">'+HHMMSS(item.duration)+'</span>'+
		'<span class="track-fav"><a class="clickable material-icons" onclick=\'Qobuz("add","track","'+item.id+'",event); return false;\' title="Add to Queue">add</a></span>'+
		'<span class="track-action"><a class="clickable material-icons" onclick="showMenu2(this.parentNode,event);" title="Show menu">more_vert</a></span>';
		tr.classList.add("track-item");
		tr.setAttribute('data-type','track');
		tr.setAttribute('data-id',item.id);
		tr.setAttribute('data-title',item.title);
    		tbl.appendChild(tr);
	    }
	    tbl.classList.add('tracklist');
	    tbl.classList.add('album-tracklist');
    	    cardContainer.appendChild(tbl);
    	}
          
	var header = document.createElement('div');
// albums
	var str = '<h5>More albums from artist</h5>'

	header.innerHTML = str;
	header.classList.add('group-header');
	cardContainer.appendChild(header);
	  
	nr = obj.albums_same_artist.items.length;

//	  var div = document.createElement('div');

	var div2 = document.createElement('div');
    	div2.classList.add('row');
//	div.appendChild(div2);
	for (var j = 0; j < nr; j++) {
	    item = obj.albums_same_artist.items[j];
	    var card = document.createElement('div');
//    	    card.classList.add('my-item');
    	    card.classList.add('grid-item');
    	    
    	    var cover = item.image;
    	    if (cover == null) {
    		var link = 'icons/disc.svg';
    	    } else {
    		var link = cover.small;
    	    }
	    icon = 'favorite_border';
    	    var str = '<div class="card1">' +
                             (item.hires == "yes" ? ' <i class="hires material-icons">high_quality</i>' : '')+
                             ' <a class="clickable" onclick=\'appGoto("Qobuz","page","album__'+item.id+'");\'>' +
                             ' <div class="item-wrapper">' +
                             ' <img src="icons/disc.svg" data-src="'+link+'" width="100%" height="100%" class="lozad">';
            if (phone)
    		str +=  ' <div class="aplay">'+
                        '     <button class="btn material-icons shadow-none" type="button" role="button" onclick=\'Qobuz("play","album","'+item.id+'",event)\' title="Play">play_arrow</button>' +
                	' </div>'+
        		'</div></a>'+
                    	'<div class="card-tit">'+
                    	' <div>'+
                	'  <span class="item-title talb clickable" onclick=\'appGoto("Qobuz","page","album__'+item.id+'");\' title="'+item.title+'">' + item.title + '</span>' +
                	'  <span class="item-title tart clickable" onclick=\'appGoto("Qobuz","page","artist__'+item.artist.id+'");\' title="'+item.artist.name+'">' + item.artist.name + '</span>' +
                    	' </div>'+
                    	' <div class="title-button"><button class="btn material-icons shadow-none" onclick="showMenu2(this,event)">more_vert</button></div>' +
                    	'</div>'+
                	'</div>'
            else 
                str +=  ' <div class="overlay">' +
                        '     <button class="btn favbtn material-icons shadow-none" type="button" role="button" onclick=\'Qobuzfav("album","'+item.id+'",event,this);\' title="">'+icon+'</button>'+
            		'     <button class="btn material-icons shadow-none" type="button" role="button" onclick=\'Qobuz("play","album","'+item.id+'",event);\'>play_arrow</button>' +
			'     <button class="btn material-icons shadow-none" type="button" role="button" onclick="showMenu2(this,event);">more_vert</button>'+
                        ' </div>'+
        		'</div></a>'+
                	'  <span class="item-title talb clickable" onclick=\'appGoto("Qobuz","page","album__'+item.id+'");\' title="'+item.title+'">' + item.title + '</span>' +
                	'  <span class="item-title tart clickable" onclick=\'appGoto("Qobuz","page","artist__'+item.artist.id+'");\' title="'+item.artist.name+'">' + item.artist.name + '</span>' +
                	'</div>';
            card.innerHTML = str;
    	    div2.appendChild(card);
	} //for
	cardContainer.appendChild(div2);

    }
    else if (page == 'daaudio' || page == '1001') {
	len = obj.length;
	var da = document.getElementById('Qobuz'+page);
	da.classList.remove('hide');
	if (page == 'daaudio') {
	    document.getElementById('topTitle').innerHTML = 'Dastereo user choice... ';
	    var cardContainer = document.getElementById('Qobuzdabody');
	} else {
	    document.getElementById('topTitle').innerHTML = '1001 Albums You Must Hear Before... ';
	    var cardContainer = document.getElementById('Qobuz1001body');
	}
	if (len > 0) {
	    if (request.data.offset == 0) {
    		while (cardContainer.firstChild) {
    		    cardContainer.removeChild(cardContainer.firstChild);
    		};
		cardContainer.setAttribute('data-offset',len);

		var div = document.createElement('div');
    		div.classList.add('row');
    		if (phone) div.classList.add('phone');
	    } else {
		var div = cardContainer.getElementsByClassName('row')[0];
		var offset = parseInt(cardContainer.getAttribute('data-offset'));
		offset = offset + len;
		cardContainer.setAttribute('data-offset',offset);
	    }

	    for (var j = 0; j < len; j++) {
	      var item = obj[j];
	      var card = document.createElement('div');
    	      card.classList.add('grid-item');
    	    
    	      var cover = item.cover;
    	      if (cover == null) {
    		var link = 'icons/disc.svg';
    	      } else {
    		var link = cover;
    	      }

	      icon = 'favorite_border';
    	      var str = '<div class="card1">' +
//                             (item.audioQuality == "HI_RES" ? ' <i class="hires material-icons">high_quality</i>' : '')+
                             ' <a class="clickable" data-type="album" data-id="'+item.id+'" onclick=\'appGoto("Qobuz","page","album__'+item.id+'");\'>' +
                             ' <div class="item-wrapper">' +
                             ' <img class="lozad" src="icons/disc.svg" data-src="'+link+'" width="100%" height="100%" class="swiper-lazy">';
	      if (phone)
    		str +=  ' <div class="aplay">'+
                        '     <button class="btn material-icons shadow-none" type="button" role="button" onclick=\'Qobuz("play","album","'+item.id+'",event)\' title="Play">play_arrow</button>' +
                	' </div>'+
        		'</div></a>'+
                    	'<div class="card-tit">'+
                    	' <div>'+
                        '  <span class="item-title talb clickable" title="'+item.album+'" onclick=\'appGoto("Qobuz","page","album__'+item.id+'");\'>' + item.album + '</span>' +
                        '  <span class="item-title tart clickable" title="'+item.artist+'" onclick=\'appGoto("Qobuz","page","artist__' + item.artid+'");\'>' + item.artist + '</span>' +
                        (page == 'ecm' ? '  <span class="item-title tart">' + item.catId + ' ('+rdate+')'+'</span>':'') +
                    	' </div>'+
                    	' <div class="title-button"><button class="btn material-icons shadow-none" onclick="showMenu2(this,event)">more_vert</button></div>' +
                    	'</div>'+
                	'</div>'
              else 
                str +=  ' <div class="overlay">' +
                        '     <button class="btn favbtn material-icons shadow-none" type="button" role="button" onclick=\'Qobuzfav("album","'+item.id+'",event,this);\' title="">'+icon+'</button>'+
                        '     <button class="btn material-icons shadow-none" type="button" role="button" onclick=\'Qobuz("play","album","'+item.id+'",event);\' title="Play">play_arrow</button>' +
                        '     <button class="btn material-icons shadow-none" type="button" role="button" onclick="showMenu2(this,event)" title="Show menu">more_vert</button>' +
                        ' </div>'+
            		'</div></a>'+
                        '  <span class="item-title talb clickable" title="'+item.album+'" onclick=\'appGoto("Qobuz","page","album__'+item.id+'");\'>' + item.album + '</span>' +
                        '  <span class="item-title tart clickable" title="'+item.artist+'" onclick=\'appGoto("Qobuz","page","artist__' + item.artid+'");\'>' + item.artist + '</span>' +
                        (page == 'ecm' ? '  <span class="item-title tart">' + item.catId + ' ('+rdate+')'+'</span>':'') +
                     '</div>';
              card.innerHTML = str;
    	      div.appendChild(card);
	    } //for
	    if (request.data.offset == 0)
    		cardContainer.appendChild(div);
	} //if (len>0)

    }
    else if (page == 'label') {
	len = obj.albums.items.length;
	if (!phone)
	    document.getElementById('topTitle').innerHTML = 'Label: '+ obj.name;

	if (!request.data.offset) {
	    cardContainer.setAttribute('data-offset',len);

	    var card = document.createElement('div');
	    card.innerHTML = '<h5>'+obj.name+'</h5>';
	    card.classList.add('group-header');
	    cardContainer.appendChild(card);
            
	    var div = document.createElement('div');
    	    div.classList.add('row');
    	    if (phone) div.classList.add('phone');
    	} else {
	    if (len>0) {
	    	var offset = parseInt(cardContainer.getAttribute('data-offset'));
		offset = offset + len;
		cardContainer.setAttribute('data-offset',offset);
	    }
    	    var div = cardContainer.getElementsByClassName('row')[0];
    	}
	
	for (var j = 0; j < len; j++) {
	    item = obj.albums.items[j];
	    var card = document.createElement('div');
    	    card.classList.add('grid-item');
	    icon = 'favorite_border';

    	    var str = '<div class="card1" id="card' + item.id + '">' +
                             ' <a class="clickable" data-name="' + item.title + '" onclick=\'appGoto("Qobuz","page","album__'+ item.id+'");\'>'+
                             ' <div class="item-wrapper"><img src="icons/disc.svg" data-src="'+item.image.small+'" width="100%" height="100%" class="lozad">';
            if (phone)
    		str +=  ' <div class="aplay">'+
                        '     <button class="btn material-icons shadow-none" type="button" role="button" onclick=\'Qobuz("play","album","'+item.id+'",event)\' title="Play">play_arrow</button>' +
                	' </div>'+
        		'</div></a>'+
                    	'<div class="card-tit">'+
                    	' <div>'+
                	'  <span class="item-title talb clickable" title="'+item.title+'" onclick=\'appGoto("Qobuz","page","album__'+ item.id+'");\'>' + item.title + '</span>' +
                	'  <span class="item-title tart clickable" title="'+item.artist.name+'" onclick=\'appGoto("Qobuz","page","artist__'+ item.artist.id+'");\'>'+item.artist.name+'</span>' +
                    	' </div>'+
                    	' <div class="title-button"><button class="btn material-icons shadow-none" onclick="showMenu2(this,event)">more_vert</button></div>' +
                    	'</div>'+
                	'</div>'
            else 
                str +=  ' <div class="overlay">' +
                        '     <button class="btn favbtn material-icons shadow-none" type="button" role="button" onclick=\'Qobuzfav("album","'+item.id+'",event,this);\' title="">'+icon+'</button>'+
                        '     <button class="btn material-icons shadow-none" type="button" role="button" onclick=\'Qobuz("play","album","'+item.id+'",event);\' title="Play">play_arrow</button>'+
                        '     <button class="btn material-icons shadow-none" type="button" role="button" onclick="showMenu2(this,event)" title="Show menu">more_vert</button>' +
                        ' </div>'+
        		'</div></a>' +
                	'  <span class="item-title talb clickable" title="'+item.title+'" onclick=\'appGoto("Qobuz","page","album__'+ item.id+'");\'>' + item.title + '</span>' +
                	'  <span class="item-title tart clickable" title="'+item.artist.name+'" onclick=\'appGoto("Qobuz","page","artist__'+ item.artist.id+'");\'>'+item.artist.name+'</span>' +
                	'</div>'; //dimas
//		img.setAttribute('src',item.image.small);
	    card.innerHTML = str;
    	    div.appendChild(card);
	    }
	if (!request.data.offset) cardContainer.appendChild(div);
    
    }
    else if (page == 'playlist') {
	var div = document.createElement('div');
	if (obj.image_rectangle) { var img =  obj.image_rectangle[0]; }
	else { var img = obj.images300[0]; }
	if (img == null) {
    	    var link = 'icons/disc.svg';
    	}
	else {
	    var link = img;
    	}
	var fav = checkQFav('playlist',obj.id);
	if (fav) {
	    clas = ' fav'; icon = 'favorite'; favtit = 'Remove from My Collection';
	} else {
		clas = ''; icon = 'favorite_border'; favtit = 'Add to My Collection';
	}
	if (!phone) {
	    document.getElementById('topTitle').innerHTML = 'Playlist: '+ obj.name;
    	    var str = '<div class="artist-image"><img src="'+link+'" width="100%"></div>'+
	    '<div class="artist-text"><h2>' + obj.name + '</h2>'+
	    '<h5>Owner: ' + obj.owner.name +'</h5>'+
	    '<div>' + obj.tracks_count+' Tracks - '+ '  Duration - '+HHMMSS(obj.duration)+'</div>';
	    if (obj.description != null ) {
		str+='<div class="swiper-bio">'+ obj.description + '</div>';
	    }

	    str+='<div class="header-controls">'+
	    '  <button class="btn play material-icons" type="button" role="button" onclick=\'Qobuz("play","playlist","' + obj.id+'",event);\'>play_arrow</button>'+
	    '  <button class="btn material-icons" type="button" role="button" onclick=\'Qobuz("playtidal","playlist","' + obj.id+'",event);\' title="Play from Tidal">local_taxi</button>'+
	    '  <button class="btn material-icons '+clas+'" type="button" role="button" onclick=\'Qobuzfav("playlist","' + obj.id+'",event,this);\' title="'+favtit+'">'+icon+'</button>'+
	    '  <button class="btn material-icons" type="button" role="button" onclick=\'Qobuz("add","playlist","' + obj.id+'",event);\' title="Add to Queue">playlist_add</button>'+
	    '</div>'+
	    '</div>';
	    div.innerHTML = str;
	    div.classList.add('artist-header');
	    cardContainer.appendChild(div);
	} else {
	    div.classList.add('swiper-container');
    	    div.classList.add('swiper-header');

	    var bg = document.createElement('div');
    	    bg.classList.add('bg-header');
	    bg.style.background = 'url("'+link+'")';
	    bg.style.backgroundSize = 'cover';
	    bg.style.backgroundPositionY = '50%';
	    div.appendChild(bg);

	    var div2 = document.createElement('div');
	    div2.classList.add('swiper-wrapper');
	    div.appendChild(div2);
	    var card = document.createElement('div');
	    card.classList.add('swiper-slide');
	    card.classList.add('card-body-image');
	    card.innerHTML = '<div class="w-100" style="margin:0 auto;">'+
	    '<img class="swiper-lazy" src="icons/disc.svg" data-src="'+link+'" width="100%;">'+
	    '<span class="item-title talb center" style="text-align:center;">'+obj.name+'</span>'+
	    '</div>';
	    div2.appendChild(card);

	    var card2 = document.createElement('div');
	    card2.classList.add('swiper-slide');
	    card2.classList.add('card-body-header');
	    var str ='<h5>'+obj.name+'</h5>'+
	    '<small>Owner: '+obj.owner.name+'</small>'+
	    '<div>' + obj.tracks_count+' Tracks - '+ '  Duration - '+beautifyDuration(obj.duration)+'</div>';
	    if (obj.description != null ) {
		str+='<div class="swiper-bio">'+ obj.description + '</div>';
	    }
	    card2.innerHTML = str;
	    div2.appendChild(card2);
	    cardContainer.appendChild(div);

	    var pg = document.createElement('div');
	    pg.classList.add('swiper-pagination');
	    div.appendChild(pg);
	    
	    var dv2 = document.createElement('div');
	    dv2.innerHTML = '<button class="btn float-left material-icons'+clas+'" type="button" role="button" onclick=\'Qobuzfav("playlist","' + obj.id+'",event,this);\' title="'+favtit+'">'+icon+'</button>'+
	    '<button class="btn float-right play material-icons" type="button" role="button" onclick=\'Qobuz("play","playlist","' + obj.id+'",event);\'>play_arrow</button>';
	    dv2.classList.add('header-controls');
	    dv2.classList.add('w-100');

	    var dv = document.createElement('div');
	    dv.style.height = '20px';
	    dv.style.width = '100%';

	    
	    var swiperhead = new Swiper('.swiper-header', {
		slidesPerView: 1,
    		loop: false,
    		lazy:true,
    		pagination: {
        	el: '.swiper-pagination',
        	     clickable: true,
    		},
	    });

	    cardContainer.appendChild(dv2);
	    cardContainer.appendChild(dv);
	    cardContainer.classList.add('phone');
	
	}
	
	var header = document.createElement('div');
	var str = '<h5>Playlist</h5>';

	 
	header.innerHTML = str;
	header.classList.add('group-header');
	cardContainer.appendChild(header);

	var tbl = document.createElement('ul');
	  
    	var tr = document.createElement('li');
    	tr.innerHTML = '<span class="track-cover"></span>'+
    	  '<div class="track-title-mobile">'+
    	  '<span class="track-title">Title</span><span class="track-artist">Artist</span>'+
    	  '</div>'+
    	  '<span class="track-album">Album</span><span class="track-duration">Time</span><span class="track-fav"></span><span class="track-action"></span>'
    	tr.classList.add('tracklist-label');
    	tbl.appendChild(tr);
	nr = obj.tracks.items.length;
	for (var j = 0; j < nr; j++) { // add track to table
	    item = obj.tracks.items[j];
	    var cover = item.album.image;
	    if (cover == null) {
		var link = 'icons/disc.svg'; 
	    }
	    else {
		var link = cover.thumbnail;
	    }

	    var artid = ((item.performer == null) ? item.album.artist.id : item.performer.id);
	    var artname = ((item.performer == null) ? item.album.artist.name : item.performer.name);
	    
	    var tr = document.createElement('li');
	    tr.innerHTML = '<span class="track-cover">'+
	    '<div class="imgmini2">'+
	    '<div class="item-wrapper">'+
	    '<a class="clickable" onclick=\'Qobuz("play","track","'+item.id+'",event);\'>'+
	    '<img class="lozad" src="icons/disc.svg" data-src="'+link+'" width="50px" height="50px">'+
	    '<div class="overlay">'+
                '<button class="btn material-icons clickable" type="button" role="button">play_arrow</button>'+
	    '</div>'+
	    '</a></div></div></span>'+
    	    '<div class="track-title-mobile">'+
	      '<span class="track-title"><a class="clickable" onclick=\'Qobuz("play","track","'+item.id+'",event);\' title="Play">' + item.title + '</a></span>'+
	      '<span class="track-artist"><a class="clickable" onclick=\'appGoto("Qobuz","page","artist__' + artid + '")\'>' + artname + '</a></span>'+
	    '</div>'+
	    '<span class="track-album"><a class="clickable" onclick=\'appGoto("Qobuz","page","album__' + item.album.id + '");\' title="' + item.album.title + '">' + item.album.title+'</a></span>'+
	    '<span class="track-duration">'+HHMMSS(item.duration)+'</span>'+
	    '<span class="track-fav"><a class="clickable material-icons" onclick=\'Qobuz("add","track","'+item.id+'",event); return false;\' title="Add to Queue">add</a></span>'+
	    '<span class="track-action"><a class="clickable material-icons" onclick="showMenu2(this.parentNode,event);" title="Show menu">more_vert</a></span>';
	    tr.classList.add('track-item');
	    tr.setAttribute('data-type','track');
	    tr.setAttribute('data-id',item.id);
	    tr.setAttribute('data-title',item.title);
	    
    	    tbl.appendChild(tr);
	  }
	  tbl.classList.add('tracklist');
          cardContainer.appendChild(tbl);
	
	 if (obj.similarPlaylist != null) {
	   nr = obj.similarPlaylist.items.length;
	   if (nr >0) {
	   var header = document.createElement('div');
	   var str = '<h5>Similar playlists</h5>';

	    
	   header.innerHTML = str;
	   header.classList.add('group-header');
	   cardContainer.appendChild(header);
         
	   var div2 = document.createElement('div');
	   div2.classList.add('row');

	    for (var j = 0; j < nr; j++) {
	      item = obj.similarPlaylist.items[j];
	      var card = document.createElement('div');
    	      card.classList.add('grid-item');
    	      var img = item.images150[0];
	      if (img == null) {
    		var link = 'icons/disc.svg';
    	      }
	      else {
    		var link = img;
    	      }

	      icon = 'favorite_border';

    	      var str = '<div class="card1">' +
                             ' <a class="clickable" onclick=\'appGoto("Qobuz","page","playlist__'+item.id+'");\'>'+
                             ' <div class="item-wrapper">'+
                             ' <img src="icons/disc.svg" data-src="'+link+'" width="100%" height="100%" class="lozad">';
              if (phone)
    		str +=  ' <div class="aplay">'+
                        '     <button class="btn material-icons shadow-none" type="button" role="button" onclick=\'Qobuz("play","playlist","'+item.id+'",event)\' title="Play">play_arrow</button>' +
                	' </div>'
    	      else 
                str +=  ' <div class="overlay">'+
                        '     <button class="btn favbtn material-icons shadow-none" type="button" role="button" onclick=\'Qobuzfav("playlist","'+item.id+'",event,this);\' title="">'+icon+'</button>'+
                        '     <button class="btn material-icons clickable" type="button" role="button" onclick=\'Qobuz("play","playlist","'+item.id+'",event);\'>play_arrow</button>'+
                        '     <button class="btn material-icons shadow-none" type="button" role="button" onclick="showMenu2(this,event)" title="Show menu">more_vert</button>' +
                        ' </div>';
              str += '</div></a>'+
                     ' <span class="item-title talb clickable" onclick=\'appGoto("Qobuz","page","playlist__'+item.id+'");\' title="'+item.name+'">' + item.name + '</span>' +
                     '</div>'; 
              card.innerHTML = str;
    	      div2.appendChild(card);
	    
	    } //for j=

    	    cardContainer.appendChild(div2);
	   }
	}
    }
    if (!phone) {
      var swiper1x = new Swiper('.swiper-1x', {
        slidesPerView: 'auto',
        slidesPerColumn: 1,
        slidesPerGroup: 3,
//    	freeMode: true,
        scrollbar: {
    	 el: '.swiper-scrollbar',
    	 hide: true,
        },
        navigation: {
    	nextEl: '.swiper-button-next',
    	prevEl: '.swiper-button-prev',
         },
//        preloadImages: false,
        lazy:true,
        watchSlidesVisibility:true
      });

/*      var swiper1x = new Swiper('.swiper-1x', {
         slidesPerView: 'auto',
         slidesPerColumn: 2,
    	 slidesPerGroup: 3,
        scrollbar: {
    	 el: '.swiper-scrollbar',
    	 hide: true,
        },
        navigation: {
    	nextEl: '.swiper-button-next',
    	prevEl: '.swiper-button-prev',
         },
//        preloadImages:false,
        freeMode:false,
        lazy:true,
        watchSlidesVisibility:true
      });*/
    }
    setPlaying();
    observer.observe();
    modalLoader.hide();
    scrollFlag = false;
    var t1 = performance.now();
    console.log('time:'+ (t1-t0));
}

function parsePrimePage(obj, request){
var len = 0;
var len2 = 0;
  var ensemble = 'Choir|Orchestra|Ensemble|Quartet';

  var cardContainer = document.getElementById('Primebody');
  if (obj.page) {  //add
    len = obj.items.length;
    if (len>0) {
	var type = obj.items[0].type;
	if (type == "artist" || type == "album" || type == "recording") {
	    var list = cardContainer.getElementsByClassName('row')[0];
	    list.setAttribute('data-next',obj.next);
	    for (var i = 0; i < len; i++) {
		var item = obj.items[i];
		var card = document.createElement('div');
		if (type == 'artist' && ensemble.indexOf(item.subtitle) == -1)
		    card.classList.add('grid-small')
		else
		    card.classList.add('grid-item');
		var img = '';
		if (item.image) img = item.image.url;
                if (type == "recording") {
		    var album = item.action.header.album.title;
		    var artist = item.title;
		} else if (type == "album") {
		    var album = item.title;
		    var artist = item.subtitle;
		}
		var query = album + '|'+artist;
		query = query.replace(/"/g,"");
		var url = item.action.url;
		url = url.replace(/\//g,'_');
		url = url.substring(1);

    	    	var str = '<div class="card1">' +
                 ' <a class="clickable" onclick=\''+(type == "artist" ? 'appGoto("Prime","page","'+url+'");':'Prime("playtidal","album","'+ query +'",event);')+'\'>'+
                (type == 'artist' && ensemble.indexOf(item.subtitle) == -1 ? '<div class="artist-wrapper">':' <div class="item-wrapper'+(ensemble.indexOf(item.subtitle) != -1 ? ' ensemble' : '')+'">')+
                 ' <img src="icons/disc.svg" data-src="' + img + '" width="100%" height="100%" ' +
                 'class="lozad">' +
                 ' <div class="overlay">'+
                 (type == "artist" ? '':'     <button class="btn material-icons shadow-none" type="button" role="button" onclick=\'Prime("playtidal","album","'+ query +'",event);\' title="Play from Tidal">local_taxi</button>')+
                 ' </div>'+
                 '</div></a>';
                if (type == "recording") {
                    str +=' <span class="item-title talb">' + album + '</span>' +
                    '  <span class="item-title tart clickable">' + artist + '</span>' +
                    (item.subtitle ? ' <span class="item-title tart">' + item.subtitle + '</span>':'') +
                 '</div>'; 
                } else {
                    str += '  <span class="item-title talb clickable">' + item.title + '</span>' +
                    (item.subtitle ? ' <span class="item-title tart">' + item.subtitle + '</span>':'') +
                 '</div>'; 
                }
                card.innerHTML = str;

		list.appendChild(card);
	    }
	} else {
	    var list = cardContainer.getElementsByClassName('list-group')[0];
	    list.setAttribute('data-next',obj.next);
	    for (var i = 0; i < len; i++) {
		var li = document.createElement('li');
		var item = obj.items[i];
	    	var url = item.action.url;
    	    	url = url.replace(/\//g,'_');
	    	url = url.substring(1);
		li.innerHTML = '<a onclick=\'appGoto("Prime","page","'+url+'");\'>'+
		(item.image ? '<img class="mr-3" src="' + item.image.lowresUrl +'" width="120px" style="float:left;">':'')+
		'<div class="media-body"><h5>'+item.title+'</h5></p>'+
		(item.subtitle ? '<span>'+item.subtitle+'</span>':'')+
		(item.disclosureText ? '<p>'+item.disclosureText+'</p>':'')+
		(item.description ? '<p>'+item.description+'</p>':'')+
		'</div></a>';
		li.classList.add('list-group-item');
		li.classList.add('p-0');
		list.appendChild(li);
	    }
	}
    }
    observer.observe();
    modalLoader.hide();
    return;
    scrollFlag = false;
  }

  var fi = "artist|genre|period|playlist|playlistContainer";
  cardContainer.innerHTML = '';

  if (obj.header && obj.header.type != "work") {
    var type0 = obj.header.type;
    if (fi.indexOf(type0) != -1) {
	var div = document.createElement('div');
	div.classList.add('media');
	if (type == "artist") {
	  div.innerHTML = '<div class="grid-item artist-wrapper mr-3">'+
	  '<img src="'+obj.header.image.lowresUrl+'" width="100%" height="100%"></div>'+
	  '<div class="media-body">'+
	  '<small>'+obj.header.startYear+(obj.header.endYear ? '-'+obj.header.endYear : '')+'</small>'+
	  '<h5>'+obj.title+'</h5>'+
	  '<span>'+obj.header.subtitle+'</span>'+
	  '</div>';
	} else {
	  var plurl = '';
	  if (type0 == "playlist" && obj.primaryButton.action) {
	    if (obj.primaryButton.action.type = "play-context")
		plurl = obj.primaryButton.action.tracksMetadataUrl;
		plurl = plurl.replace(/\//g,'_');
		plurl = plurl.substring(1);
	  }
	  div.innerHTML = '<div class="grid-item artistwrapper mr-3">'+
//	  div.innerHTML = '<div class="grid-item mr-3" style="float:left">'+
	  (obj.image ? '<img src="'+obj.image.lowresUrl+'" width="100%" height="100%">':'<img src="'+obj.header.image.lowresUrl+'" width="100%" height="100%">')+'</div>'+
//	  '<img src="'+obj.header.image.lowresUrl+'" width="100%" height="100%"></div>'+
	  '<div class="media-body">'+
	  '<small>'+(obj.header.startYear ? obj.header.startYear : '')+(obj.header.endYear ? '-'+obj.header.endYear : '')+'</small>'+
	  '<h5>'+obj.title+'</h5>'+
	  (obj.header.subtitle ? '<span>'+obj.header.subtitle+'</span>':'')+
	  (obj.description ? '<p>'+obj.description+'</span>':'')+
	  '<div id="aboutpl"></div>'+
	  (type0 == "playlist" ? '<div class="header-controls">'+
	    '<button class="btn material-icons" type="button" role="button" onclick="Prime(\'playtidal\',\'playlist\',\'' + plurl +'\',event)" title="Play from Tidal">local_taxi</button>'+
	    '<button class="btn material-icons" type="button" role="button" onclick="Prime(\'playqobuz\',\'playlist\',\'' + plurl +'\',event)" title="Play from Qobuz">album</button>'+
	  '</div>' : '');

	  '</div>';
	}
	cardContainer.appendChild(div);

	len = obj.sections.length;
	for (var i = 0; i < len; i++) {
	    var node = obj.sections[i];
	    var title = node.heading.title;
	    if (title.indexOf("About")==-1) {
	      var header = document.createElement('div');
	      var str = '<h5>' + title + '</h5>';
	      var button = node.heading.button;
	      if (button) {
		var url = button.action.url;
		url = url.replace(/\//g,'_');
		url = url.substring(1);
		var alt = button.action.title;
		str += '<a class="clickable" onclick=\'appGoto("Prime","page","'+url +'");\' title="'+alt+'">'+button.title+'</a>';
	      }
	      header.innerHTML = str;
	      header.classList.add('group-header');
	      cardContainer.appendChild(header);
	    }
	    if (node.components[0].type == "text") {
		if (title.indexOf("About")==-1) {
		  var div = document.createElement('div');
		  var str = '';
		  if (node.components[0].title)
		    str = '<h5>'+node.components[0].title+'</h5>';
		  str += '<span>'+node.components[0].paragraphs+'</span>';
		  div.innerHTML = (node.components[0].image ? '<div class="artistwrapper mr-3"><img src="' + node.components[0].image.url + '" width="80px"></div>' : '')+
		  '<div>' + str + '</div>';
		  div.classList.add('media');
		  cardContainer.appendChild(div);
		} else {
		  var a = document.getElementById('aboutpl');
		  a.innerHTML = '<p>'+node.components[0].paragraphs+'</p>';
		}
		continue;
//		type = "text";
	    } else {
		if (node.components[0].items[0].type) {
		    type = node.components[0].items[0].type;
		} else {
		    type = node.components[0].type;
		}
		len2 = node.components[0].items.length;
	    }
	    if (type0 == "playlist" && node.components[0].items) {
		var ul = document.createElement('ul');
		ul.classList.add('tracklist');
		ul.classList.add('album-tracklist');
	        for (var j = 0; j < len2; j++) {
	    	    var item = node.components[0].items[j];
	    	    if (item.type == "subheading") {
	    		var li = document.createElement('div');
	    		if (item.action) {
	    		    var url = item.action.url;
			    url = url.replace(/\//g,'_');
			    url = url.substring(1);
	    		    li.innerHTML = '<a class="clickable" onclick=\'appGoto("Prime","page","' + url + '");\'>' + item.title + '</a>';
	    		} else {
	    		    li.innerHTML = item.title;
	    		}
	    		li.classList.add('subhead');
	    	    }
	    	    if (item.type == "track") {
	    		var btn = item.moreButtons[0];
	    		if (btn.title.indexOf("album")!=-1) {
	    		    var album = btn.action.header.title;
	    		    var artist = btn.action.header.subtitle;
	    		    var img = btn.action.header.image;
	    		}
	    		var query = item.title+'|' + artist +'|'+album+'|'+item.duration;
	    		query = query.replace(/"/g,"");
	    		var li = document.createElement('li');
	    		li.innerHTML = '<a onclick=\'Prime("playtidal","track","'+query+'");\'><span class="track-cover">'+
			(img ? '<img class="mr-3" src="' + img.lowresUrl +'" width="60px" style="float:left;">' : '')+
			'</span>'+
//	    		'<div class="media-body">'+
			'<div class="track-title-mobile">'+
	    		'<span class="track-title">'+item.title+'</span>'+
	    		'<span class="track-artist">'+item.subtitle+'</span>'+
	    		'</div>'+
	    		'<span class="track-duration">'+item.duration+'</span></a>';
//			li.classList.add('list-group-item');
			li.classList.add('track-item');
//			li.classList.add('p-0');
	    	    }
		    ul.appendChild(li);
		}
		cardContainer.appendChild(ul);
	    }
	    if (type == "work" || type == "playlist") { //list
		var ul = document.createElement('ul');
		ul.classList.add('list-group');
		ul.classList.add('tracklist');
		ul.classList.add('album-tracklist');
	        for (var j = 0; j < len2; j++) {
	    	    var li = document.createElement('li');
	    	    var item = node.components[0].items[j];
	    	    //title, subtitle, disclosureText
	    	    var url = item.action.url;
    	    	    url = url.replace(/\//g,'_');
	    	    url = url.substring(1);
	    	    if (type =="work") {
		    li.innerHTML = '<a onclick=\'appGoto("Prime","page","'+url+'");\'>'+
//		      (item.image ? '<img class="mr-3" src="' + item.image.lowresUrl +'" width="120px" style="float:left;">':'')+
		      '<span class="track-title">'+item.title+'</span>'+
		      (item.subtitle ? '<span class="track-artist">'+item.subtitle+'</span>':'')+
		      (item.disclosureText ? '<span style="float:right;">'+item.disclosureText+'&nbsp;&nbsp;&#8250;</span>':'')+
//		      (item.description ? '<p>'+item.description+'</p>':'')+
		      '</a>';
		      li.classList.add('track-item');
	    	    }
	    	    else {
		    li.innerHTML = '<a onclick=\'appGoto("Prime","page","'+url+'");\'>'+
		    (item.image ? '<img class="mr-3" src="' + item.image.lowresUrl +'" width="120px" style="float:left;">':'')+
		    '<div class="media-body"><h5>'+item.title+'</h5>'+
		    (item.subtitle ? '<p>'+item.subtitle+'</p>':'')+
		    (item.disclosureText ? '<span class="duration">'+item.disclosureText+'</span>':'')+
		    (item.description ? '<p>'+item.description+'</p>':'')+
		    '</div></a>';
		    }
		    li.classList.add('list-group-item');
//		    li.classList.add('p-0');
	    	    ul.appendChild(li);
	        }
		if (node.components[0].items[0].image) ul.classList.add('list-group');
		cardContainer.appendChild(ul);
	    } else
	    if (type == "album" || type == "artist" || type == "shelf" ) {
		if (type == "shelf") {
		    var div = document.createElement('div');
    		    div.classList.add('swiper-container');
    		    div.classList.add('swiper-1x');
		    var div2 = document.createElement('div');
    		    div2.classList.add('swiper-wrapper')
        	    div.appendChild(div2);
		
		} else {
		    var div2 = document.createElement('div');
		    div2.classList.add("row");
		}
		for (var j = 0; j < len2; j++) {
		    var item = node.components[0].items[j];
		    if (item.subtitle || type == "shelf") {
		    var card = document.createElement('div');
    		    if (type == "shelf") card.classList.add('swiper-slide');
		    card.classList.add('grid-item');
		    var img = '';
		    if (item.image) img = item.image.url;
		    if (type == "album") {
			var query = item.title + '|' + item.subtitle;
			query = query.replace(/"/g,"");
		    }
		    var url = item.action.url;
		    url = url.replace(/\//g,'_');
		    url = url.substring(1);
    	    	    card.innerHTML = '<div class="card1">' +
                     ' <a class="clickable" onclick=\''+(type == "album" ? 'Prime("playtidal","album","'+ query +'",event);':'appGoto("Prime","page","'+ url +'");')+'\'>'+
                     (type == 'album' ? ' <div class="item-wrapper">' : '<div class="artist-wrapper">')+
                     ' <img src="icons/disc.svg" data-src="'+ img +'" width="100%" height="100%" ' +
                     'class="lozad">' +
                     ' <div class="overlay">'+
            	    (type == "album" ? '     <button class="btn material-icons shadow-none" type="button" role="button" onclick=\'Prime("playtidal","album","'+ query +'",event);\' title="Play from Tidal">local_taxi</button>':'')+
                     ' </div>'+
                     '</div></a>'+
                     '  <span class="item-title talb clickable" onclick=\'appGoto("Prime","page","' + url +'")\'>' + item.title + '</span>' +
                     (item.subtitle ? ' <span class="item-title tart">' + item.subtitle + '</span>':'') +
                     '</div>'; 
    		    div2.appendChild(card);
    		    }
		}
		if (type == "shelf") {
		    var pagina = document.createElement('div');
		    pagina.classList.add('swiper-scrollbar');
		    div.appendChild(pagina);

		    var but = document.createElement('div');
		    but.classList.add('swiper-button-next');
		    div.appendChild(but);
		    var but = document.createElement('div');
		    but.classList.add('swiper-button-prev');
		    div.appendChild(but);
		    cardContainer.appendChild(div);
		} else {

		    cardContainer.appendChild(div2);
		}
	    }
	}
    }
    var swiper1x = new Swiper('.swiper-1x', {
        slidesPerView: 'auto',
        slidesPerColumn: 1,
        slidesPerGroup: 3,
//    	freeMode: true,
        scrollbar: {
    	 el: '.swiper-scrollbar',
    	 hide: true,
        },
        navigation: {
    	nextEl: '.swiper-button-next',
    	prevEl: '.swiper-button-prev',
         },
//        preloadImages: false,
        lazy:true,
        watchSlidesVisibility:true
    });
  } else {
	var div = document.createElement('div');
	div.classList.add('media-body');
	div.innerHTML = '<h5>'+obj.title+'</h5>'+
	(obj.header ? '<span>'+obj.header.subtitle+'</span>':'')+
	(obj.header ? '<p>'+obj.header.description+'</p>':'');
	cardContainer.appendChild(div);
	var type = obj.firstPage.items[0].type;
	len = obj.firstPage.items.length;
	if (type == "artist" || type == "album" || type == "recording") {
	    var div2 = document.createElement('div');
	    div2.classList.add("row");
	    div2.setAttribute('data-next',obj.firstPage.next);
	    for (var i = 0; i < len; i++) {
		var item = obj.firstPage.items[i];
		var card = document.createElement('div');
		if (type == 'artist' && ensemble.indexOf(item.subtitle) == -1)
		    card.classList.add('grid-small')
		else
		    card.classList.add('grid-item');
		var img = '';
		if (item.image) img = item.image.url;
                if (type == "recording") {
		    var album = item.action.header.album.title;
		    var artist = item.title;
		} else if (type == "album") {
		    var album = item.title;
		    var artist = item.subtitle;
		}
		var query = album + "|" + artist;
		var query = query.replace(/"/g,"");
		
		var url = item.action.url;
		url = url.replace(/\//g,'_');
		url = url.substring(1);
    	    	var str = '<div class="card1">' +
                 ' <a class="clickable" onclick=\''+(type == "artist" ? 'appGoto("Prime","page","'+url+'");':'Prime("playtidal","album","'+ query +'",event);')+'\'>'+
                (type == 'artist' && ensemble.indexOf(item.subtitle) == -1 ? '<div class="artist-wrapper">':' <div class="item-wrapper'+(ensemble.indexOf(item.subtitle)!=-1 ? ' ensemble' : '')+'">')+
                 ' <img src="icons/disc.svg" data-src="' + img + '" width="100%" height="100%" ' +
                 'class="lozad">' +
                 ' <div class="overlay">'+
                 (type == "artist" ? '':'     <button class="btn material-icons shadow-none" type="button" role="button" onclick=\'Prime("playtidal","album","'+ query +'",event);\' title="Play from Tidal">local_taxi</button>')+
                 ' </div>'+
                 '</div></a>';
                if (type == "recording") {
                    str +=' <span class="item-title talb">' + album + '</span>' +
                    '  <span class="item-title tart clickable">' + artist + '</span>' +
                    (item.subtitle ? ' <span class="item-title tart">' + item.subtitle + '</span>':'') +
                 '</div>'; 
                } else {
                    str += '  <span class="item-title talb clickable">' + item.title + '</span>' +
                    (item.subtitle ? ' <span class="item-title tart">' + item.subtitle + '</span>':'') +
                 '</div>'; 
                }
                card.innerHTML = str;
		div2.appendChild(card);
	    }
	    cardContainer.appendChild(div2);
	} else
	if (type == "work" || type == "playlist") {
	    var ul = document.createElement('ul');
	    ul.classList.add('list-group');
	    ul.setAttribute('data-next',obj.firstPage.next);
	    for (var i = 0; i < len; i++) {
		var li = document.createElement('li');
	    	var item = obj.firstPage.items[i];

	    	var url = item.action.url;
    	    	url = url.replace(/\//g,'_');
	    	url = url.substring(1);
	    	
		li.innerHTML = '<a onclick=\'appGoto("Prime","page","'+url+'");\'>'+
		(item.image ? '<img class="mr-3" src="' + item.image.lowresUrl +'" width="120px" style="float:left;">':'')+
		'<div class="media-body"><h5>'+item.title+'</h5></p>'+
		(item.subtitle ? '<span>'+item.subtitle+'</span>':'')+
		(item.disclosureText ? '<p>'+item.disclosureText+'</p>':'')+
		(item.description ? '<p>'+item.description+'</p>':'')+
		'</div></a>';
		li.classList.add('list-group-item');
		li.classList.add('p-0');
	        ul.appendChild(li);
	    }
	    cardContainer.appendChild(ul);
	}
    }

    observer.observe();
    modalLoader.hide();
    scrollFlag = false;
}

function parsePrime(obj, request){
var len = 0;
var len2 = 0;
  var cardContainer = document.getElementById('Primebody');
  cardContainer.innerHTML = '';
  document.getElementById('topTitle').innerHTML = '';

  var page = request.data.page;
  if (page == "home" || page == "browse") {
    len = obj.sections.length;
    for (var i = 0; i < len; i++) {
	var node = obj.sections[i];
	var type = node.components[0].type;
	var itemtype = node.components[0].itemType;
	var title = node.heading.title;

	var header = document.createElement('div');
	var str = '<h5>'+title+'</h5>';
	if (title.indexOf("Podcast")!=-1) continue;

	var button = node.heading.button;
	if (button) {
	    var url = button.action.url;
	    url = url.replace(/\//g,'_');
	    url = url.substring(1);
//	    url = url.substring(0,url.indexOf('?'));
	    var alt = button.action.title;
	    str += '<a class="clickable" onclick=\'appGoto("Prime","page","'+url +'");\' title="'+alt+'">'+button.title+'</a>';
	}
	
	header.innerHTML = str;
	header.classList.add('group-header');
	cardContainer.appendChild(header);

	if (node.heading.subtitle) { 
	    var header = document.createElement('div');
	    header.innerHTML = '<small>'+node.heading.subtitle+'</small>';
	    cardContainer.appendChild(header);
	    }
	
	len2 = node.components[0].items.length;

//	if ((type == "shelf" || type == "carousel") && title.indexOf(" period") == -1) {
	if (type == "shelf" || type == "carousel") {
	if (!phone) {
	    var div = document.createElement('div');
    	    div.classList.add('swiper-container');
    	    div.classList.add('swiper-1x');
	    var div2 = document.createElement('div');
    	    div2.classList.add('swiper-wrapper')
            div.appendChild(div2);
    	}
        else {
	    var div2 = document.createElement('div');
    	    div2.classList.add('row')
    	    div2.classList.add('phone')
    	}

	for (var j = 0; j < len2; j++) {
	    var item = node.components[0].items[j];
	    var card = document.createElement('div');
    	    if (!phone) card.classList.add('swiper-slide');
    	    
    	    if (title == "Ensembles" || title.indexOf(" period")!=-1)
    		card.classList.add('grid-item')
    	    else
    		card.classList.add('grid-small');
    	    //item.cover
    	    var img = item.image.url;
    	    if (img == null) {
    		var img = "icons/disc.svg";
    	    }
    	    var url = item.action.url;
    	    url = url.replace(/\//g,'_');
	    url = url.substring(1);
//	      url = url.substring(0,url.indexOf('?'));
	    if (itemtype == "album") {
		var album = item.title;
		var artist = item.subtitle;
		var query = album + '|' + artist;
		query = query.replace(/"/g,"");
	    }
    	    card.innerHTML = '<div class="card1">' +
//                 ' <a class="clickable" onclick=\'' + (itemtype == "album" ? 'Prime("playtidal","' + itemtype + '","'+ (itemtype == "album" ? query : url) +'",event);' : 'appGoto("Prime","page","'+url+'");')+'\'>'+
                 ' <a class="clickable" ' + (itemtype == "album" ? '': 'onclick=\'appGoto("Prime","page","'+url+'")\';')+'>'+
                 (title == "Ensembles" || itemtype == "playlist" || itemtype == "album" || title.indexOf(" period")!=-1 ? ' <div class="item-wrapper' + (title == 'Ensembles' || title.indexOf(" period")!=-1 ? ' ensemble' : '')+'">' : '<div class="artist-wrapper">')+
                 ' <img src="icons/disc.svg" data-src="'+img+'" width="100%" height="100%" ' +
                 (!phone ? 'class="swiper-lazy">':'class="lozad">') +
                 ' <div class="overlay">'+
                 (itemtype == "album" || itemtype == "playlist" ? '     <button class="btn material-icons shadow-none" type="button" role="button" onclick=\'Prime("playtidal","'+itemtype+'","'+ (itemtype == "album" ? query : url) +'",event);\' title="Play from Tidal">local_taxi</button>' : '')+
                 (itemtype == "album" || itemtype == "playlist" ? '     <button class="btn material-icons shadow-none" type="button" role="button" onclick=\'Prime("playqobuz","'+itemtype+'","'+ (itemtype == "album" ? query : url) +'",event);\' title="Play from Qobuz">album</button>' : '')+
                 ' </div>'+
                 '</div>'+
//                 '</div></a>'+
//                 '  <span class="item-title talb clickable" onclick=\'appGoto("Prime","page","' +url+'")\'>' + item.title + '</span>' +
                 '  <span class="item-title talb clickable">' + item.title + '</span>' +
                 (title.indexOf(" period")!=-1 || itemtype == "album" ?'  <span class="item-title tart clickable">' + item.subtitle + '</span>':'') +
		 '</a>'+
                 '</div>'; 
    	    div2.appendChild(card);
	} //for j=
	if (!phone) {
	    var pagina = document.createElement('div');
	    pagina.classList.add('swiper-scrollbar');
	    div.appendChild(pagina);

	    var but = document.createElement('div');
	    but.classList.add('swiper-button-next');
	    div.appendChild(but);
	    var but = document.createElement('div');
	    but.classList.add('swiper-button-prev');
	    div.appendChild(but);
	  

	    cardContainer.appendChild(div);
	} else {
	  cardContainer.appendChild(div2);
	}

	}
	if (type == "list") {
	    var ul = document.createElement('ul');
	    for (var j = 0; j < len2; j++) {
	      var li = document.createElement('li');
	      var item = node.components[0].items[j];
	      var url =  item.action.url;
    	      url = url.replace(/\//g,'_');
	      url = url.substring(1);
//	      var url2 = url.substring(0,url.indexOf('?'));
	      if (item.image) {
		li.innerHTML = '<a onclick=\'appGoto("Prime","page","'+url+'");\'><img class="mr-3" src="'+ item.image.url+'" style="width:100px;float:left;">'+
		'<div class="media-body"><h5>'+item.title+'</h5></p>'+
		(item.subtitle ? '<span>'+item.subtitle+'</span>':'')+
		'<p>'+item.description+'</p></div></a>';
		li.classList.add('list-group-item');
		li.classList.add('p-0');
	        ul.appendChild(li);
	      } else {
        	 var card = document.createElement('div'); // no need two div !!!
	    	 card.classList.add('card-cloud');
	         card.innerHTML = ''+
                             ' <a class="clickable" onclick=\'appGoto("Prime","page","'+url+'");\'>'+
                             '  <span class="cloud-title talb">' + item.title + '</span>' +
                             '</div>'; 
	        ul.appendChild(card);
	      }
	        //action.url, action.header.image.url
	    }
	    if (node.components[0].items[0].image) ul.classList.add('list-group');
	    cardContainer.appendChild(ul);
	}
//	    item.action.url,  item.action.title, item.action.header.subtitle
    };
    var swiper1x = new Swiper('.swiper-1x', {
        slidesPerView: 'auto',
        slidesPerColumn: 1,
        slidesPerGroup: 3,
//    	freeMode: true,
        scrollbar: {
    	 el: '.swiper-scrollbar',
    	 hide: true,
        },
        navigation: {
    	nextEl: '.swiper-button-next',
    	prevEl: '.swiper-button-prev',
         },
//        preloadImages: false,
        lazy:true,
        watchSlidesVisibility:true
    });
  }

  observer.observe();
  modalLoader.hide();
  scrollFlag = false;
}


function searchTidal(query,type){
//    modalSearch('hide');
    modalLoader.show();

    if (type === undefined)
	sendAPI({"cmd": "API_TIDAL_SEARCH","data":{"query":query}},parseTidalSearch);
    else
	sendAPI({"cmd": "API_TIDAL_SEARCH","data":{"query":query,"type":type}},parseTidalFullSearch);
//    e.stopPropagation();
}


function searchQobuz(query,type){
//    modalQSearch('hide');
    modalLoader.show();
    if (type === undefined)
	sendAPI({"cmd": "API_QOBUZ_SEARCH","data":{"query":query}},parseQobuzSearch);
    else
	sendAPI({"cmd": "API_QOBUZ_SEARCH","data":{"query":query,"type":type}},parseQobuzFullSearch);
//    e.stopPropagation();
}


function searchYoutube(query,type){
    modalLoader.show();
    if (type === undefined)
	type = document.getElementById('ysearchType').value;

    sendAPI({"cmd": "API_YOUTUBE_SEARCH","data":{"query":encodeURI(query), "type":type}},parseYoutubeSearch);
}

function searchFilm(query,e){
    modalLoader.show();

    sendAPI({"cmd": "API_FILM","data":{"cmd":"search","query":encodeURI(query)}},parseFilmSearch);
    e.stopPropagation();
}

function cmdFilm(cmd,par){
//    alert(cmd+','+par);
    if (cmd == 'play') {
	var fq = document.getElementById("filmQuality");
	sendAPI({"cmd": "API_FILM","data":{"cmd":"play","query":fq.options[fq.selectedIndex].value}});
    } else {
	if (par === undefined) {
	    sendAPI({"cmd": "API_FILM","data":{"cmd":cmd}});
	}
	else {
	    sendAPI({"cmd": "API_FILM","data":{"cmd":cmd,"query":par}});
	}
    }
}

function searchSoundcloud(query,type){
    modalLoader.show();
    if (type === undefined)
	type = document.getElementById('scloudsearchType').value;

    sendAPI({"cmd": "API_SOUNDCLOUD_SEARCH","data":{"query":encodeURI(query), "type":type}},parseScloudSearch);
}

function searchFullTidal(query){
    var tag = document.getElementById("searchType");
    searchTidal(query, tag.value);
}

function searchFullQobuz(query){
    var tag = document.getElementById("qsearchType");
    searchQobuz(query, tag.value);
}

function YoutubeChannel(type,id,e){
    if (id == 'featured') {
	document.getElementById('channelSecond').classList.add('hide');
	document.getElementById('channelHome').classList.remove('hide');
	var Container = document.getElementById('Youtubebody');
	Container.setAttribute('data-tab',id);
	
	var links = Container.getElementsByClassName('nav-link');
	var lnk = links.length;
	for (var a = 0; a < lnk; a++) {
	    links[a].classList.remove('active');
	    if (request.data.id == 'featured')
		links[a].classList.add('active');
	}

    } else {
	modalLoader.show();    
	sendAPI({"cmd": "API_YOUTUBE_DATA","data":{"cmd":"channel", "type":type, "id" : id}},parseYtChannel);
    }
    e.stopPropagation();
}

function Prime(cmd,type,id,e){
//    sendAPI({"cmd": "API_PRIME_CMD","data":{"cmd":cmd,"type":type,"query":encodeURI(id)}});
    sendAPI({"cmd": "API_PRIME_CMD","data":{"cmd":cmd,"type":type,"query":id}});
    e.stopPropagation();
}

function Tidalfav(type,id,e,t){
var ind = -1;
    jp_hide();
    if (t.classList.contains('fav')) {
	t.classList.remove('fav');
	t.innerHTML = 'favorite_border';
	t.setAttribute('title','Add to My Collection');
	sendAPI({"cmd": "API_TIDAL_FAVREM","data":{"type":type,"id":id}});
	if (type == "album") {
	    ind = tidalFavs.ALBUM.indexOf(id);
	    if (ind > -1) tidalFavs.ALBUM.splice(ind,1);
	} else if (type == "artist") {
	    ind = tidalFavs.ARTIST.indexOf(id);
	    if (ind > -1) tidalFavs.ARTIST.splice(ind,1);
	} else if (type == "track") {
	    ind = tidalFavs.TRACK.indexOf(id);
	    if (ind > -1) tidalFavs.TRACK.splice(ind,1);
	} else if (type == "playlist") {
	    ind = tidalFavs.PLAYLIST.indexOf(id);
	    if (ind > -1) tidalFavs.PLAYLIST.splice(ind,1);
	} else if (type == "video") {
	    ind = tidalFavs.VIDEO.indexOf(id);
	    if (ind > -1) tidalFavs.VIDEO.splice(ind,1);
	}
    }
    else {
	t.classList.add('fav');
	t.innerHTML = 'favorite';
	t.setAttribute('title','Remove from My Collection');
	sendAPI({"cmd": "API_TIDAL_FAVADD","data":{"type":type,"id":id}})
	if (type == "album") {
	    tidalFavs.ALBUM.push(id);
	} else if (type == "artist") {
	    tidalFavs.ARTIST.push(id);
	} else if (type == "track") {
	    tidalFavs.TRACK.push(id);
	} else if (type == "playlist") {
	    tidalFavs.PLAYLIST.push(id);
	} else if (type == "video") {
	    tidalFavs.VIDEO.push(id);
	}
    }
    e.stopPropagation();
}

function Tidal(cmd,type,id,e,itemid){
var ind = -1;
    jp_hide();
    if (cmd == "play" || cmd == "insert")
	sendAPI({"cmd": "API_TIDAL_PLAY","data":{"cmd":cmd,"type":type,"id":id}})
    else if (cmd == "add")
	sendAPI({"cmd": "API_TIDAL_ADD","data":{"type":type,"id":id}})
    else if (cmd == "fav")
	sendAPI({"cmd": "API_TIDAL_FAVADD","data":{"type":type,"id":id}})
    else if (cmd == "favrem") {
	if (typeof itemid != "undefined") {
	    var item = document.getElementById(itemid);
	    if (item.parentNode)
		item.parentNode.removeChild(item);
	}
	if (type == "album") {
	    ind = tidalFavs.ALBUM.indexOf(id);
	    if (ind > -1) tidalFavs.ALBUM.splice(ind,1);
	} else if (type == "artist") {
	    ind = tidalFavs.ARTIST.indexOf(id);
	    if (ind > -1) tidalFavs.ARTIST.splice(ind,1);
	} else if (type == "track") {
	    ind = tidalFavs.TRACK.indexOf(id);
	    if (ind > -1) tidalFavs.TRACK.splice(ind,1);
	} else if (type == "playlist") {
	    ind = tidalFavs.PLAYLIST.indexOf(id);
	    if (ind > -1) tidalFavs.PLAYLIST.splice(ind,1);
	} else if (type == "video") {
	    ind = tidalFavs.VIDEO.indexOf(id);
	    if (ind > -1) tidalFavs.VIDEO.splice(ind,1);
	}
	sendAPI({"cmd": "API_TIDAL_FAVREM","data":{"type":type,"id":id}});
    }
    e.stopPropagation();
}

function Qobuzfav(type,id,e,t){
var ind = -1;
    if (t.classList.contains('fav')) {
	t.classList.remove('fav');
	t.title = 'Add to My Collection';
	t.innerHTML = 'favorite_border';
	sendAPI({"cmd": "API_QOBUZ_FAVREM","data":{"type":type,"id":id}});
	if (type == "album") {
	    var item = t.parentNode.parentNode.parentNode.parentNode.parentNode;
	    if (item.parentNode)
		item.parentNode.removeChild(item);
	    ind = qobuzFavs.albums.indexOf(id);
	    if (ind > -1) qobuzFavs.albums.splice(ind,1);
	} else if (type == "artist") {
	    ind = qobuzFavs.artists.indexOf(id);
	    if (ind > -1) qobuzFavs.artists.splice(ind,1);
	} else if (type == "track") {
	    ind = qobuzFavs.tracks.indexOf(id);
	    if (ind > -1) qobuzFavs.tracks.splice(ind,1);
	} else if (type == "playlist") {
	    ind = qobuzFavs.playlists.indexOf(id);
	    if (ind > -1) qobuzFavs.playlists.splice(ind,1);
	}
    } else {
	t.classList.add('fav');
	t.innerHTML = 'favorite';
	t.title = 'Remove from My Collection';
	sendAPI({"cmd": "API_QOBUZ_FAVADD","data":{"type":type,"id":id}});
	if (type == "album") {
	    qobuzFavs.albums.push(id);
	} else if (type == "artist") {
	    qobuzFavs.artists.push(id);
	} else if (type == "track") {
	    qobuzFavs.tracks.push(id);
	} else if (type == "playlist") {
	    qobuzFavs.playlists.push(id);
	}
    }
    e.stopPropagation();
}

function Qobuz(cmd,type,id,e,itemid){
var ind = -1;
    jp_hide();
    if (cmd == "play" || cmd == "playtidal" || cmd == "insert")
	sendAPI({"cmd": "API_QOBUZ_PLAY","data":{"cmd":cmd,"type":type,"id":id}})
    else if (cmd == "add")
	sendAPI({"cmd": "API_QOBUZ_ADD","data":{"type":type,"id":id}})
    else if (cmd == "fav")
	sendAPI({"cmd": "API_QOBUZ_FAVADD","data":{"type":type,"id":id}})
    else if (cmd == "favrem") {
	if (typeof itemid != "undefined") {
	    var item = document.getElementById(itemid);
	    if (item.parentNode)
		item.parentNode.removeChild(item);
	}
	if (type == "album") {
	    var item = t.parentNode.parentNode.parentNode.parentNode.parentNode;
	    if (item.parentNode)
		item.parentNode.removeChild(item);
	    ind = qobuzFavs.albums.indexOf(id);
	    if (ind > -1) qobuzFavs.albums.splice(ind,1);
	} else if (type == "artist") {
	    ind = qobuzFavs.artists.indexOf(id);
	    if (ind > -1) qobuzFavs.artists.splice(ind,1);
	} else if (type == "track") {
	    ind = qobuzFavs.tracks.indexOf(id);
	    if (ind > -1) qobuzFavs.tracks.splice(ind,1);
	} else if (type == "playlist") {
	    ind = qobuzFavs.playlists.indexOf(id);
	    if (ind > -1) qobuzFavs.playlists.splice(ind,1);
	}
	sendAPI({"cmd": "API_QOBUZ_FAVREM","data":{"type":type,"id":id}});
    }
    e.stopPropagation();
}

function Pitch(cmd,type,id,e){
    sendAPI({"cmd": "API_PITCHFORK_PLAY","data":{"cmd":cmd,"type":type,"search": id}});
    e.stopPropagation();
}

function parseYT(obj){
    sendAPI({"cmd": "MPD_API_PLAYER_STATE"},parseState);
}

function playYoutube(type,id,e){
    sendAPI({"cmd": "API_YOUTUBE_CMD","data":{"cmd":"play","type":type,"id":id}},parseYT);
/*    setTimeout(function(){
	sendAPI({"cmd": "MPD_API_PLAYER_STATE"},parseState);
    },3000);*/
    e.stopPropagation();
}

function cmdYoutube(cmd){
    sendAPI({"cmd": "API_YOUTUBE_CMD","data":{"cmd":cmd}});
}
