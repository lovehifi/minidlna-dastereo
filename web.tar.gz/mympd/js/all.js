"use strict";
//var scrollFlag = false;

function formatDate(date, m) {
var d = new Date(date);
    if (m) 
	return d.toLocaleString('ru',{ hour12:false });
    else
	return d.toLocaleString('ru',{ year:'numeric',month:'long',day:'numeric' });
}

function setstartpage(){
    var s = window.location.href;
    s = s.split('#')[1];
    sendAPI({"cmd":"MPD_API_SETTINGS_SET","data":{"startPage":s}});
}

function ScrollStart() {
    var ww = document.getElementById('maincont');
    if (app.current.app == 'Playback' || app.current.app == 'Film') {
	return;
    } else {
//	var currentScrollPos = window.pageYOffset;
	var currentScrollPos = ww.offsetHeight + ww.scrollTop;
//	console.log(prevScrollpos +' > ' + currentScrollPos);

//	if (!phone) {
	    if (ww.scrollTop < 56) {
		document.getElementById('topTitle').style.display = 'none';
	    } else {
		document.getElementById('topTitle').style.display = 'block';
	    }
//	}

	if (prevScrollpos > currentScrollPos) {
	    prevScrollpos = currentScrollPos;
	    return;
	}
// hide bar
/*	if (prevScrollpos > currentScrollPos || currentScrollPos == 0) {
	    document.getElementById("tsearch").style.top = "10px";
	    document.getElementById("qsearch").style.top = "10px";
	    document.getElementById("navbar").style.top = "0";
	    document.getElementById("botbar").style.bottom = "0";
	    document.getElementById("song-seek-progress").style.bottom = "55px";
	} else {
	    document.getElementById("tsearch").style.top = "-50px";
	    document.getElementById("qsearch").style.top = "-50px";
	    document.getElementById("navbar").style.top = "-60px";
	    document.getElementById("botbar").style.bottom = "-55px";
	    document.getElementById("song-seek-progress").style.bottom = "0";
	    document.getElementById("more-controls").style.display = "none";
	}*/
	prevScrollpos = currentScrollPos;
    }
//    if ((window.innerHeight + window.scrollY) >= document.body.offsetHeight && !loaderVisible())
//    console.log(ww.offsetHeight+' + '+ww.scrollTop+' >= '+ww.scrollHeight);
    var off = ww.offsetHeight + ww.scrollTop + 60;
//    if (!loaderVisible() && off >= ww.scrollHeight)
    if (!scrollFlag && off >= ww.scrollHeight)
    {
//	console.log(app.current.app +' ' + app.current.tab);
	if (app.current.app == 'Pitchfork') {
	    var pbody = document.getElementById('Pitchbody');
	    var offset = parseInt(pbody.getAttribute('data-offset'));
	    var genre = app.current.filter;
	    if (genre == '-') genre = 'all';
	    modalLoader.show();
	    if (app.current.tab) {
	        scrollFlag = true;
	        sendAPI({"cmd": "API_PITCHFORK_CMD", "data": {"cmd": app.current.tab,"genre":genre,"offset":offset}}, parsePitch);
	    }
	}
	if (app.current.tab == 'Database' && app.current.view == "Album") {
	    var pbody=document.getElementById('BrowseDatabaseAlbumList');
	    var offset = parseInt(pbody.getAttribute('data-offset'));
	    if (offset>0) {
	        modalLoader.show(); scrollFlag = true;
	        sendAPI({"cmd": "MPD_API_ALBUMS",  //dimas
		    "data": {"offset": offset, "filter": app.current.filter}}, parseListAlbums2);
	    }
	}
	if (app.current.app == 'Browse' && app.current.tab == "Last") {
	    var pbody = document.getElementById('BrowseLastAlbumList');
	    var offset = parseInt(pbody.getAttribute('data-offset'));
	    modalLoader.show(); scrollFlag = true;
	    sendAPI({"cmd": "MPD_API_ALBUMS",  //dimas
		"data": {"offset": offset, "filter": app.current.filter}}, parseListAlbums2);
	    }
	if (app.current.app == 'Youtube') {
	    if (app.current.tab == 'search') {
		var pbody = document.getElementById('Youtubesearchbody');
		var nextpage = pbody.getAttribute('data-nextpage');
	    	var query = document.getElementById('ysearchbtn').value;
	    	var type = document.getElementById('ysearchType').value;
	    	modalLoader.show(); scrollFlag = true;
		sendAPI({"cmd": "API_YOUTUBE_SEARCH", "data": {"query": encodeURI(query),"type":type,"nextpage":nextpage}}, parseYoutubeSearch);
	    }
	    if (app.current.tab == 'page') {
	        if (app.current.view.indexOf("channel") != -1) {
		    var ytab = document.getElementById("Youtubebody").getAttribute('data-tab');
		    var chSec = document.getElementById("channelSecond");
		    if (chSec) {
			var next = chSec.getAttribute('data-next');
			if (next && (ytab == 'videos' || ytab == 'playlists')) {
	    		    modalLoader.show(); scrollFlag = true;
			    sendAPI({"cmd": "API_YOUTUBE_DATA", "data": {"cmd": "channel","type":ytab,"id":"next"}}, parseYtAdd);
			}
		    }
		}
	    }
	}

	if (app.current.app == 'Soundcloud') {
	    if (app.current.tab == 'search') {
		var pbody = document.getElementById('SoundcloudSbody');
		var offset = pbody.getAttribute('data-offset');
	    	var query = document.getElementById('scloudsearchbtn').value;
	    	var type = document.getElementById('scloudsearchType').value;
	    	modalLoader.show(); scrollFlag = true;
		sendAPI({"cmd": "API_SOUNDCLOUD_SEARCH", "data": {"query": encodeURI(query),"type":type,"offset":offset}}, parseScloudSearch);
	    }
	}
	if (app.current.app == 'Prime') {
	    var list ='page|composers|conductors|ensembles|soloists';
	    if (list.indexOf(app.current.tab)!=-1) {
		var pbody = document.getElementById('Primebody');
		var clist = pbody.getElementsByClassName('list-group');
		if (clist.length>0) {
		    path = clist[0].getAttribute('data-next');
		}
		else {
		    var clist = pbody.getElementsByClassName('row');
		    if (clist.length > 0)
			path = clist[0].getAttribute('data-next');
		}
		if (path != null) {
	    	    modalLoader.show(); scrollFlag = true;
    		    sendAPI({"cmd": "API_PRIME_PAGE", "data": {"page": path,"type":"add"}}, parsePrimePage);
    		}
	    }
	}
	if (app.current.app == 'Tidal') {
	    if (app.current.tab == 'search') {
		var type = document.getElementById('searchType').value;
		if (type != 'all') {
		    var pbody = document.getElementById('tidalFullSearch');
		    var offset = parseInt(pbody.getAttribute('data-offset'));
		    var query = document.getElementById('tfullsearchbtn').value;
	    	    modalLoader.show(); scrollFlag = true;
		    sendAPI({"cmd": "API_TIDAL_SEARCH","data":{"query":query,"type":type,"offset":offset}},parseTidalFullSearch);
		}
	    }
	    if (app.current.tab == 'page') {
//		   console.log('Scroll!!!!!!');
		var pbody = document.getElementById('Tidalpage');
		var offset = parseInt(pbody.getAttribute('data-offset'));
		var total = parseInt(pbody.getAttribute('data-total'));
		var path = pbody.getAttribute('data-apipath');
		var view = app.current.view;
		if (path != null ) {
		    if (view.indexOf("__") == -1 && (view.indexOf("single")>0 || view.indexOf("data")>0 || view.indexOf("_playlists")>0)) {
			if (offset > 0 && offset < total) {
	    		    modalLoader.show(); scrollFlag = true;
    			    sendAPI({"cmd": "API_TIDAL_PAGE", "data": {"page": path, "offset":offset}}, parseTidalAdd);
    			}
    		    } 
    		} else {
		    if (view.indexOf("__") > 0) {
			if (offset > 0 && offset < total) {
			    var ar = view.split('__');
	    		    modalLoader.show(); scrollFlag = true;
	    		    if (ar[0] && ar[1]) {
				modalLoader.show(); scrollFlag = true;
				console.log('offset:'+offset+' total:'+total);
    				sendAPI({"cmd": "API_TIDAL_PAGID", "data": {"page": ar[0],"id":ar[1],"offset":offset}}, parseTidalAdd);
    			    }
    			}
    		    } 
    		}
		if (view == 'ecm' || view == '1001' || 'daaudio') {
		    var pbody = document.getElementById('Tidal'+(view == 'daaudio'? 'da': view) + 'body');
		    if (pbody) {
		      var offset = parseInt(pbody.getAttribute('data-offset'));
		      var filter = app.current.filter;
		      if (filter == '-') filter = 'all';
	    	      modalLoader.show(); scrollFlag = true;
    		      sendAPI({"cmd": "API_TIDAL_PAGE", "data": {"page": view, "filter":filter, "offset":offset}}, parseTidalECM);
    		    }
    		}
	    } else
	    if (app.current.tab == "my") {
	      var list0 = 'myalbums|mytracks|myartists|myplists';
	      if (list0.indexOf(app.current.view) != -1) {
		var pbody = document.getElementById('Tidal' + app.current.view+'body');
		var offset = parseInt(pbody.getAttribute('data-offset'));
		var total = parseInt(pbody.getAttribute('data-total'));
		if (offset < total) {
		  modalLoader.show(); scrollFlag = true;
		  sendAPI({"cmd": "API_TIDAL_GROUP", "data": {"group": app.current.view, "offset":offset}}, parseTidalList);
		}
		}
	    }
	}
	if (app.current.app == 'Qobuz') {
	    if (app.current.tab == 'search') {
		var type = document.getElementById('qsearchType').value;
		if (type != 'all') {
		    var pbody = document.getElementById('qobuzFullSearch');
		    var offset = parseInt(pbody.getAttribute('data-offset'));
		    var query = document.getElementById('qfullsearchbtn').value;
	    	    modalLoader.show(); scrollFlag = true;
		    sendAPI({"cmd": "API_QOBUZ_SEARCH","data":{"query":query,"type":type,"offset":offset}},parseQobuzFullSearch);
		}
	    }
	    if (app.current.tab == 'page') {
		var view = app.current.view;
		var pbody = document.getElementById('Qobuzpage');
		if (view == 'playlists' || view == 'albums') {
		    var par = document.getElementById((view =='albums'? 'a':'p')+'qtab-content');
		    var cl = par.getElementsByClassName('active')[0].firstChild;
		    var offset = parseInt(cl.getAttribute('data-offset'));
		    var total = parseInt(cl.getAttribute('data-total'));
		    var slug = cl.getAttribute('data-slug');

		    var filter = app.current.filter;
		    if (filter == '-') filter = 'all';

		    if (offset < total ) {
	    		modalLoader.show(); scrollFlag = true;
    			sendAPI({"cmd": "API_QOBUZ_PAGE", "data": {"page": view + "_" + slug, "filter": filter, "offset":offset}}, parseQobuzPlists);
		    }
		} 
		else {

		  var offset = parseInt(pbody.getAttribute('data-offset'));
	
		  if (view.indexOf("__") != -1) {
//    			sendAPI({"cmd": "API_QOBUZ_PAGE", "data": {"page": view}}, parseQobuz);
    		    var ar = view.split('__');
    		    if (ar[0] && ar[1] && ar[0] == 'label') {
	    		modalLoader.show(); scrollFlag = true;
    			sendAPI({"cmd": "API_QOBUZ_PAGID", "data": {"page": ar[0],"id":ar[1], "offset":offset}}, parseQobuz);
    		    }
    		  } else
		  if (view == 'daaudio' || view == '1001') {
		    var pbody = document.getElementById('Qobuz'+(view == 'daaudio'? 'da' : view) + 'body');
//		    var pbody = document.getElementById('Qobuzpage');
		    var offset = parseInt(pbody.getAttribute('data-offset'));
		    var filter = app.current.filter;
		    if (filter == '-') filter = 'all';
	    	    modalLoader.show(); scrollFlag = true;
    		    sendAPI({"cmd": "API_QOBUZ_PAGE", "data": {"page": view, "filter":filter, "offset":offset}}, parseQobuz);
    		  }
    		}
	    } else
	    if (app.current.tab == "my") {
	      var list0 = 'myalbums|mytracks|myartists|myplists';
	      if (list0.indexOf(app.current.view) != -1) {
		var pbody = document.getElementById('Qobuz' + app.current.view+'body');
		var offset = parseInt(pbody.getAttribute('data-offset'));
		var total = parseInt(pbody.getAttribute('data-total'));
		if (offset < total) {
		  modalLoader.show(); scrollFlag = true;
		  sendAPI({"cmd": "API_QOBUZ_GROUP", "data": {"group": app.current.view, "offset":offset}}, parseQobuzList);
		}
	      }
	    }

		
	} // Qobuz
//    	    console.log('!!!!!!!!!!bottom!');
    }
}

function prepareMenu() {
    var aps = app.current.app;
    console.log('---preparemenu---');
    if (aps == "Tidal") {
	var cardContainer = document.getElementById('tidalMenu');
	var cards = cardContainer.getElementsByClassName('dropdown-item');
	if (cards.length == 0) tidalmenu();
    }
    else if (aps == "Qobuz") {
	var cardContainer = document.getElementById('qobuzMenu');
	var cards = cardContainer.getElementsByClassName('dropdown-item');
	if (cards.length == 0) qobuzmenu();
    }
    else if (aps == "Pitchfork") {
	var cardContainer = document.getElementById('pitchMenu');
	var cards = cardContainer.getElementsByClassName('dropdown-item');
	if (cards.length == 0) pitchmenu();
    }
    else if (aps == "Youtube") {
	var cardContainer = document.getElementById('youtubeMenu');
	var cards = cardContainer.getElementsByClassName('dropdown-item');
	var nrItems = cards.length;
	if (cards.length == 0) youtubemenu();
    }
    else if (aps == "Prime") {
	var cardContainer = document.getElementById('primeMenu');
	var cards = cardContainer.getElementsByClassName('dropdown-item');
	if (cards.length == 0) primemenu();
    }
/*    else if (aps == "Podcast") {
	var cardContainer = document.getElementById('podcastMenu');
	var cards = cardContainer.getElementsByClassName('list-group-item');
	if (cards.length == 0) podcast();
    }*/

}

function parseCmd(event, href) {
    event.preventDefault();
    var cmd = href;
    if (typeof(href) == 'string')
        cmd = JSON.parse(href);
        
    if (typeof window[cmd.cmd] === 'function') {
        switch(cmd.cmd) {
            case 'sendAPI':
                sendAPI(... cmd.options); 
                break;
            default:
                window[cmd.cmd](... cmd.options);                    
        }
    }
}

function dragAndDropTable(table) {
//    var tableBody = document.getElementById(table).getElementsByTagName('tbody')[0];
    var tableBody = document.getElementById(table);
    tableBody.addEventListener('dragstart', function(event) {
        if (event.target.nodeName == 'LI') {
            event.target.classList.add('opacity05');
            event.dataTransfer.setDragImage(event.target, 0, 0);
            event.dataTransfer.effectAllowed = 'move';
            event.dataTransfer.setData('Text', event.target.getAttribute('id'));
            dragEl = event.target.cloneNode(true);
        }
    }, false);
    tableBody.addEventListener('dragleave', function(event) {
        event.preventDefault();        
        if (dragEl.nodeName != 'LI')
            return;
        var target = event.target;
        if (event.target.nodeName == 'SPAN')
            target = event.target.parentNode;
        if (target.nodeName == 'LI')
            target.classList.remove('dragover');
    }, false);
    tableBody.addEventListener('dragover', function(event) {
        event.preventDefault();
        if (dragEl.nodeName != 'LI')
            return;
        var tr = tableBody.getElementsByClassName('dragover');
        var trLen = tr.length;
        for (var i = 0; i < trLen; i++) {
            tr[i].classList.remove('dragover');
        }
        var target = event.target;
        if (event.target.nodeName == 'SPAN')
            target = event.target.parentNode;
        if (target.nodeName == 'LI')
            target.classList.add('dragover');
        event.dataTransfer.dropEffect = 'move';
    }, false);
    tableBody.addEventListener('dragend', function(event) {
        event.preventDefault();
        if (dragEl.nodeName != 'LI')
            return;
        var tr = tableBody.getElementsByClassName('dragover');
        var trLen = tr.length;
        for (var i = 0; i < trLen; i++) {
            tr[i].classList.remove('dragover');
        }
        if (document.getElementById(event.dataTransfer.getData('Text')))
            document.getElementById(event.dataTransfer.getData('Text')).classList.remove('opacity05');
    }, false);
    tableBody.addEventListener('drop', function(event) {
        event.stopPropagation();
        event.preventDefault();
        if (dragEl.nodeName != 'LI')
            return;
        var target = event.target;
        if (event.target.nodeName == 'SPAN')
            target = event.target.parentNode;
        var oldSongpos = document.getElementById(event.dataTransfer.getData('Text')).getAttribute('data-songpos');
        var newSongpos = target.getAttribute('data-songpos');
        document.getElementById(event.dataTransfer.getData('Text')).remove();
        dragEl.classList.remove('opacity05');

        tableBody.insertBefore(dragEl, target);

        var tr = tableBody.getElementsByClassName('dragover');
        var trLen = tr.length;
        for (var i = 0; i < trLen; i++) {
            tr[i].classList.remove('dragover');
        }
        document.getElementById(table).classList.add('opacity05');
        if (app.current.app == 'Queue' && app.current.tab == 'Current')
            sendAPI({"cmd": "MPD_API_QUEUE_MOVE_TRACK","data": {"from": oldSongpos, "to": newSongpos}});
        else if (app.current.app == 'Browse' && app.current.tab == 'Playlists' && app.current.view == 'Detail')
            playlistMoveTrack(oldSongpos, newSongpos);        
    }, false);
}

function dragAndDropTableHeader(table) {
    var tableHeader;
    if (document.getElementById(table + 'List')) {
        tableHeader = document.getElementById(table + 'List').getElementsByTagName('tr')[0];
    }
    else {
        tableHeader = table.getElementsByTagName('tr')[0];
        table = 'BrowseDatabase';
    }
}

function playlistMoveTrack(from, to) {
    sendAPI({"cmd": "MPD_API_PLAYLIST_MOVE_TRACK","data": { "plist": app.current.search, "from": from, "to": to}});
}

function webSocketConnect() {
    var wsUrl = getWsUrl();
    socket = new WebSocket(wsUrl);

    try {
        socket.onopen = function() {
            console.log('connected');
            showNotification('Connected to myMPD: ' + wsUrl, '', '', 'success');
            modalConnectionError.hide();
//            appRoute();
	    checkRoute();
            sendAPI({"cmd": "MPD_API_PLAYER_STATE"}, parseState);
        }

        socket.onmessage = function got_packet(msg) {
            if (msg.data === lastState || msg.data.length == 0)
                return;
                
            try {
                var obj = JSON.parse(msg.data);
            } catch(e) {
                console.log('Invalid JSON data received: ' + msg.data);
            }

            switch (obj.type) {
                case 'update_message':
//            	    alert('preload');
//                    showNotification('Preload track...', '', '', 'success');
		    break;
                case 'preload':
		    break;
                case 'update_state':
		    console.log('>>update_state');
                    parseState(obj);
                    break;
                case 'disconnected':
                    showNotification('Lost connection to myMPD: ' + wsUrl, '', '', 'danger');
                    break;
                case 'update_queue':
//                    if (app.current.app === 'Queue')
		    console.log('>>update_queue');
                    getQueue();
                    sendAPI({"cmd": "MPD_API_PLAYER_STATE"}, parseState);
                    break;
                case 'update_options':
                    getSettings();
                    break;
//                case 'update_outputs':
//                    sendAPI({"cmd": "MPD_API_PLAYER_OUTPUT_LIST"}, parseOutputs);
//                    break;
                case 'update_started':
                    updateDBstarted(false);
                    break;
                case 'update_database':
                case 'update_finished':
                    updateDBfinished(obj.type);
                    break;
            	case 'update_volume':
            	    parseVolume(obj);
            	    break;
            	case 'update_stored_playlist':
            	    if (app.current.app == 'Browse' && app.current.tab == 'Playlists' && app.current.view == 'All')
                        sendAPI({"cmd": "MPD_API_PLAYLIST_LIST","data": {"offset": app.current.page, "filter": app.current.filter}}, parsePlaylists);
                    else if (app.current.app == 'Browse' && app.current.tab == 'Playlists' && app.current.view == 'Detail')
                        sendAPI({"cmd": "MPD_API_PLAYLIST_CONTENT_LIST", "data": {"offset": app.current.page, "filter": app.current.filter, "uri": app.current.search}}, parsePlaylists);
                    break;                
		case 'error':
                    showNotification(obj.data, '', '', 'danger');
                    break;
                default:
                    break;
            }
        }

        socket.onclose = function(){
            console.log('disconnected');
            modalConnectionError.show();
            setTimeout(function() {
                console.log('reconnect');
                webSocketConnect();
            }, 3000);
        }

    } catch(exception) {
        alert('Error: ' + exception);
    }
}

function getWsUrl() {
    var hostname = window.location.hostname;
    var protocol = window.location.protocol;
    var port = window.location.port;
    
    if (protocol == 'https:')
        protocol = 'wss://';
    else
        protocol = 'ws://';

    var wsUrl = protocol + hostname + (port != '' ? ':' + port : '') + '/ws';
    document.getElementById('wsUrl').innerText = wsUrl;        
    return wsUrl;
}

function parseStats(obj) {
    document.getElementById('mpdstats_artists').innerText =  obj.data.artists;
    document.getElementById('mpdstats_albums').innerText = obj.data.albums;
    document.getElementById('mpdstats_songs').innerText = obj.data.songs;
    document.getElementById('mpdstats_dbPlaytime').innerText = beautifyDuration(obj.data.dbPlaytime);
    document.getElementById('mpdstats_playtime').innerText = beautifyDuration(obj.data.playtime);
    document.getElementById('mpdstats_uptime').innerText = beautifyDuration(obj.data.uptime);
    var d = new Date(obj.data.dbUpdated * 1000);
    document.getElementById('mpdstats_dbUpdated').innerText = d.toUTCString();
//    document.getElementById('mympdVersion').innerText = obj.data.mympdVersion;
    document.getElementById('mpdVersion').innerText = obj.data.mpdVersion;
}

function capitalize(s) {
    return s && s[0].toUpperCase() + s.slice(1);
}

function toggleBtn(btn, state, action) {
    var b = document.getElementById(btn);
    if (!b)
        return;
    if (btn == 'btnRandom' || btn == 'btnRepeat')
	var c = document.getElementById(btn+'2');

    if (state == undefined || state == "undef")
        state = b.classList.contains('active') ? 0 : 1;

    if (state == 1 || state == true) {
        b.classList.add('active');
        if (c) c.classList.add('btnwhite');
    }
    else {
        b.classList.remove('active');
        if (c) c.classList.remove('btnwhite');
    }

    if (action) {
      if (btn == 'btnRandom') {
	sendAPI({"cmd": "MPD_API_SETTINGS_SET", "data": {
            "random": (document.getElementById(btn).classList.contains('active') ? 1 : 0)
        }}, getSettings);
      }
      if (btn == 'btnRepeat') {
	sendAPI({"cmd": "MPD_API_SETTINGS_SET", "data": {
            "repeat": (document.getElementById(btn).classList.contains('active') ? 1 : 0)
        }}, getSettings);
      }
    }
}
/*
function filterCols(x) {
    var tags = settings.tags.slice();
    if (settings.featTags == false)
        tags.push('Title');
    tags.push('Duration');
    if (x == 'colsQueueCurrent' || x == 'colsBrowsePlaylistsDetail')
        tags.push('Pos');
    else if (x == 'colsBrowseFilesystem')
        tags.push('Type');
//    if (x == 'colsQueueLastPlayed')
//        tags.push('LastPlayed');
        
    var cols = [];
    for (var i = 0; i < settings[x].length; i++) {
        if (tags.includes(settings[x][i]))
            cols.push(settings[x][i]);
    }
    settings[x] = cols;
}*/

function parseSettings(obj) {
    settings = obj.data;

    toggleBtn('btnRandom', settings.random);
//    toggleBtn('btnConsume', settings.consume);
//    toggleBtn('btnSingle', settings.single);
    toggleBtn('btnRepeat', settings.repeat);
    

//    var features = ["featStickers", "featSmartpls", "featPlaylists", "featTags", "featLocalplayer", "featSyscmds", "featCoverimage"];
    var features = ["featPlaylists", "featTags"];
    
    for (var j = 0; j < features.length; j++) {
        var Els = document.getElementsByClassName(features[j]);
        var ElsLen = Els.length;
        var displayEl = settings[features[j]] == true ? '' : 'none';
        for (var i = 0; i < ElsLen; i++) 
            Els[i].style.display = displayEl;
    }

    if (settings.featTags == false) {
        app.apps.Browse.active = 'Filesystem';
        app.apps.Search.state = '0/filename/';
        app.apps.Queue.state = '0/filename/';
//        settings.colsQueueCurrent = ["Pos", "Title", "Duration"];
//        settings.colsQueueLastPlayed = ["Pos", "Title", "LastPlayed"];
        settings.colsSearch = ["Title", "Duration"];
        settings.colsBrowseFilesystem = ["Type", "Title", "Duration"];
        settings.colsBrowseDatabase = ["Track", "Title", "Duration"];
        settings.colsPlayback = [];
    }
    else {
        var pbtl = '';
/*        for (var i = 0; i < settings.colsPlayback.length; i++) {
            pbtl += '<div id="current' + settings.colsPlayback[i]  + '" data-tag="' + settings.colsPlayback[i] + '" '+
                    'data-name="' + encodeURI((lastSongObj.data ? lastSongObj.data[settings.colsPlayback[i]] : '')) + '">' +
                    '<small>' + settings.colsPlayback[i] + '</small>' +
                    '<h4';
            if (settings.browsetags.includes(settings.colsPlayback[i]))
                  pbtl += ' class="clickable"';
            pbtl += '>' + (lastSongObj.data ? lastSongObj.data[settings.colsPlayback[i]] : '') + '</h4></div>';
        }
        document.getElementById('cardPlaybackTags').innerHTML = pbtl;*/
    }

       
    if (!settings.tags.includes('AlbumArtist') && settings.featTags) {
        if (settings.tags.includes('Artist'))
            app.apps.Browse.tabs.Database.active = 'Artist';
        else    
            app.apps.Browse.tabs.Database.active = settings.tags[0];
    }
    

    settings.tags.sort();
    settings.searchtags.sort();
    settings.browsetags.sort();
//    filterCols('colsSearch');
//    filterCols('colsQueueCurrent');
//    filterCols('colsQueueLastPlayed');
//    filterCols('colsBrowsePlaylistsDetail');
//    filterCols('colsBrowseFilesystem');
//    filterCols('colsBrowseDatabase');
//    filterCols('colsPlayback');
    
    addTagList('BrowseDatabaseByTagDropdown', 'browsetags');
    addTagList('searchqueuetags', 'searchtags');
    addTagList('searchtags', 'searchtags');
 
    addTagList2('BrowseLastByTagDropdown', false); // dimas
    
    for (var i = 0; i < settings.tags.length; i++) {
        app.apps.Browse.tabs.Database.views[settings.tags[i]] = { "state": "0/-/", "scrollPos": 0 };
//        console.log(settings.tags[i]);
        }

    dropdownMainMenu = new Dropdown(document.getElementById('mainMenu'));
    dropdownmyMenu = new Dropdown(document.getElementById('myMenu'));
    
//    setCols('QueueCurrent');
    setCols('Search');
    setCols('BrowseFilesystem');
    setCols('BrowsePlaylistsDetail');
    setCols('BrowseDatabase', '.tblAlbumTitles');
//    setCols('Playback');
/*    if (app.current.app == "Home" && settings.startPage != "Home")
	location.href = location.origin+ '/#'+settings.startPage;
    else {
	appGoto("Home");
	modalLoader.hide();
    }*/

    var accessList = 'Youtube|Pitchfork|Soundcloud|Sygma|Tidal|Qobuz|Prime|APRadio|RedRadio|CapRadio|SunRadio|MyRadio|Podcast|Fav|Film';
    if (accessList.indexOf(app.current.app) != -1)
        appRoute();
    else if (app.current.app == 'Browse' && (app.current.tab == 'Filesystem' || app.current.tab == 'Search'))
        appRoute();
    else if (app.current.app == 'Browse' && app.current.tab == 'Playlists' && app.current.view == 'Detail')
        appRoute();
    else if (app.current.app == 'Browse' && app.current.tab == 'Database' && app.current.search != '')
        appRoute();
}


function setCols(table, className) {
    var tagChks = '';
    var tags = settings.tags.slice();
    if (settings.featTags == false)
        tags.push('Title');
    tags.push('Duration');
    if (table == 'QueueCurrent' || table == 'BrowsePlaylistsDetail')
//    if (table == 'QueueCurrent' || table == 'BrowsePlaylistsDetail' || table == 'QueueLastPlayed')
        tags.push('Pos');
    if (table == 'BrowseFilesystem')
        tags.push('Type');
//    if (table == 'QueueLastPlayed')
//        tags.push('LastPlayed');
    
    tags.sort();
    
    for (var i = 0; i < tags.length; i++) {
        if (table == 'Playback' && tags[i] == 'Title')
            continue;
        tagChks += '<div class="form-check">' +
            '<input class="form-check-input" type="checkbox" value="1" name="' + tags[i] + '"';
        if (settings['cols' + table].includes(tags[i]))
            tagChks += 'checked';
        tagChks += '>' +
            '<label class="form-check-label text-light" for="' + tags[i] + '">&nbsp;&nbsp;' + tags[i] + '</label>' +
            '</div>';
    }
    document.getElementById(table + 'ColsDropdown').firstChild.innerHTML = tagChks;
    
    if (table != 'Playback') {
        var heading = '';
        for (var i = 0; i < settings['cols' + table].length; i++) {
            var h = settings['cols' + table][i];
            heading += '<th data-col="' + h  + '"'+(h == "Type"?" class='track-type'":'')+'>';
            var h2 = h;
            if (h == 'Track' || h == 'Pos') h2 = '#';
            if (h == 'Duration') h2 = 'Time';
            heading += h2 + '</th>';
        }
        heading += '<th class="track-fav"></th>';
        if (className == undefined) 
            document.getElementById(table + 'List').getElementsByTagName('tr')[0].innerHTML = heading;
        else {
            var tbls = document.querySelectorAll(className);
            for (var i = 0; i < tbls.length; i++) {
                tbls[i].getElementsByTagName('tr')[0].innerHTML = heading;
            }
        }
    }
}


function getSettings() {
    sendAPI({"cmd": "MPD_API_SETTINGS_GET"}, parseSettings);
}

function parseOutputs(obj) {
    var btns = '';
    var outputsLen = obj.data.outputs.length;
    for (var i = 0; i < outputsLen; i++) {
        btns += '<button id="btnOutput' + obj.data.outputs[i].id +'" data-output-id="' + obj.data.outputs[i].id + '" class="btn btn-secondary btn-block';
        if (obj.data.outputs[i].state == 1)
            btns += ' active';
        btns += '"><span class="material-icons float-left">volume_up</span> ' + obj.data.outputs[i].name + '</button>';
    }
    domCache.outputs.innerHTML = btns;
}

function HHMMSS(sec){
    var hours = Math.floor(sec / 3600);
    var minutes = Math.floor((sec % 3600) / 60);
    var seconds = sec % 60;
    return (hours > 0 ? hours +':' : '')+ 
    (minutes > 9 ? minutes : ( hours ? '0'+minutes : minutes)) +':'+
    (seconds > 9 ? '' : '0') + seconds;
}

function setCounter(currentSongId, totalTime, elapsedTime) {
//    console.log('---setCounter---');

    currentSong.totalTime = totalTime;
    currentSong.elapsedTime = elapsedTime;
    currentSong.currentSongId = currentSongId;
    var total_minutes = Math.floor(totalTime / 60);
    var total_seconds = totalTime - total_minutes * 60;
    var elapsed_minutes = Math.floor(elapsedTime / 60);
    var elapsed_seconds = elapsedTime - elapsed_minutes * 60;
    var proc = elapsedTime / totalTime * 100; //procent

    for (i = 0; i < domCache.progressBar.length; i++)
//	domCache.progressBar[i].value = proc*10;
	domCache.progressBar[i].value = Math.floor(proc*10);
    var fix = document.getElementsByClassName("sliderfix")[0];
    fix.style.width = proc + '%';
    for (i = 0; i < domCache.progressBar2.length; i++) {
	domCache.progressBar2[i].style.width = proc+'%';
	}

    var timeText = elapsed_minutes + ":" + 
        (elapsed_seconds < 10 ? '0' : '') + elapsed_seconds;
    var timeTotalText = total_minutes + ":" + (total_seconds < 10 ? '0' : '') + total_seconds;

    for (var i = 0; i < domCache.songtime.length; i++)
	domCache.songtime[i].innerText = timeText;
    for (var i = 0; i < domCache.songtimetotal.length; i++)
	domCache.songtimetotal[i].innerText = timeTotalText;
//    domCache.counter.innerText = counterText;
    
    //Set playing track in queue view
    if (lastState) {
        if (lastState.data.currentSongId != currentSongId) {
            var tr = document.getElementById('queueTrackId' + lastState.data.currentSongId);
//	    var tr = document.getElementById('queueTrackId' + currentSongId);
            if (tr) {
                var durationTd = tr.querySelector('[data-col=Duration]');
                if (durationTd)
                    durationTd.innerText = tr.getAttribute('data-duration');
                var posTd = tr.querySelector('[data-col=Pos]');
                if (posTd) {
                    posTd.classList.remove('material-icons');
                    posTd.innerText = tr.getAttribute('data-songpos');
                }
                tr.classList.remove('font-weight-bold');
            }
        }
    }
    var tr = document.getElementById('queueTrackId' + currentSongId);
    if (tr) {
        var durationTd = tr.querySelector('[data-col=Duration]');
        if (durationTd)
            durationTd.innerText = timeTotalText;
        var posTd = tr.querySelector('[data-col=Pos]');
        if (posTd) {
            if (!posTd.classList.contains('material-icons')) {
                posTd.classList.add('material-icons');
                posTd.innerText = 'play_arrow';
            }
        }
        tr.classList.add('font-weight-bold');
    }
    
    if (progressTimer)
        clearTimeout(progressTimer);
    if (playstate == 'play') {
        progressTimer = setTimeout(function() {
            currentSong.elapsedTime ++;
            setCounter(currentSong.currentSongId, currentSong.totalTime, currentSong.elapsedTime);    
        }, 1000);
    }
}

function parseState(obj) {
    console.log('-----parseState-----');
//    console.log(obj);
    if (JSON.stringify(obj) === JSON.stringify(lastState))
        return;

    //Set playstate
    if (obj.data.state == 1) {
        for (var i = 0; i < domCache.btnsPlayLen; i++)
            domCache.btnsPlay[i].innerText = 'play_arrow';
        playstate = 'stop';
    } else if (obj.data.state == 2) {
        for (var i = 0; i < domCache.btnsPlayLen; i++)
            domCache.btnsPlay[i].innerText = 'pause';
        playstate = 'play';
    } else {
        for (var i = 0; i < domCache.btnsPlayLen; i++)
            domCache.btnsPlay[i].innerText = 'play_arrow';
	playstate = 'pause';
    }

    if (obj.data.nextSongPos == -1) // && settings.jukeboxMode == false)
        domCache.btnNext.setAttribute('disabled','disabled');
    else
        domCache.btnNext.removeAttribute('disabled');
    
    if (obj.data.songPos <= 0)
        domCache.btnPrev.setAttribute('disabled','disabled');
    else
        domCache.btnPrev.removeAttribute('disabled');
    
    if (obj.data.queueLength == 0)
        for (var i = 0; i < domCache.btnsPlayLen; i++)
            domCache.btnsPlay[i].setAttribute('disabled','disabled');
    else
        for (var i = 0; i < domCache.btnsPlayLen; i++)
            domCache.btnsPlay[i].removeAttribute('disabled');

    var curRate = document.getElementById('currentRate').getElementsByTagName('small');
    if (obj.data.player == 'mpd') {
	if (obj.data.audioFormat.sampleRate >0)  {
	  var sr = ''+obj.data.audioFormat.sampleRate * 0.001 +' KHz';
	  var s = obj.data.audioFormat.bits+'-bit';
	  domCache.footerFormat.innerHTML = s + ' / ' + sr +'<br/>'+obj.data.kbitrate+' Kbps';
	  curRate[0].innerHTML =  s + '&nbsp;&nbsp;&bull;&nbsp;&nbsp;'+ sr +'&nbsp;&nbsp;&bull;&nbsp;&nbsp;' + obj.data.kbitrate+' Kbps';
	} else {
//	  var s ='';
	  domCache.footerFormat.innerHTML ='';
	  curRate[0].innerHTML = '';
	}
    }
    if (obj.data.player == 'apr') {
	if (obj.data.audioFormat.sampleRate >0)  {
	  var sr = ''+obj.data.audioFormat.sampleRate * 0.001 +' KHz';
	  var s = obj.data.audioFormat.bits+'-bit';
	  domCache.footerFormat.innerHTML = s + ' / ' + sr +'<br/>aprenderer'+ (obj.data.preload ? ' preload':'');
	  curRate[0].innerHTML =  s + '&nbsp;&nbsp;&bull;&nbsp;&nbsp;'+ sr+'&nbsp;&nbsp;&bull;&nbsp;&nbsp;aprenderer';
	} else {
	  domCache.footerFormat.innerHTML ='';
	  curRate[0].innerHTML = '';
	}
    }
    if (obj.data.player == 'mpv') {
	if (obj.data.audioFormat.samplerate >0)  {
	  var sr1 = 'A: ' + obj.data.audioFormat.samplerate * 0.001 +' KHz ';
	  var sr = sr1 + obj.data.audioFormat.channels + '<br/>';
	  if (obj.data.videoFormat) {
	    sr += 'V: '+obj.data.videoFormat.w+'x'+obj.data.videoFormat.h;
	  };
	  domCache.footerFormat.innerHTML = sr;
	  var sr2 = sr1 + '&nbsp;&nbsp;&bull;&nbsp;&nbsp;' + obj.data.audioFormat.channels;
	  if (obj.data.videoFormat) {
	    sr2 += '&nbsp;&nbsp;&bull;&nbsp;&nbsp;' +obj.data.videoFormat.w+'x'+obj.data.videoFormat.h
	  }
	  curRate[0].innerHTML = sr2;
	}
    }
//    domCache.badgeQueueItems.innerText = obj.data.queueLength;

    //Set volume
    parseVolume(obj);

    //Set play counters
    console.log("elapsed: "+obj.data.elapsedTime);
    setCounter(obj.data.currentSongId, obj.data.totalTime, obj.data.elapsedTime);
    
    //Get current song
//    console.log(lastState);
//    if (lastState && lastState.data.currentSongId != obj.data.currentSongId)
        sendAPI({"cmd": "MPD_API_PLAYER_CURRENT_SONG"}, songChange);
    //clear playback card if not playing
    if (obj.data.songPos == '-1') {
        domCache.currentTitle.innerText = 'Not playing';
        domCache.currentCover.style.backgroundImage = '';
        domCache.footerCover.style.backgroundImage = '';
       var pb = document.getElementById('cardPlaybackTags').getElementsByTagName('h4');
        for (var i = 0; i < pb.length; i++)
            pb[i].innerText = '';
    }
    
//    if (app.current.app == 'LastPlayed')
//        sendAPI({"cmd": "MPD_API_QUEUE_LAST_PLAYED", "data": {"offset": app.current.page}}, parseLastPlayed);

    lastState = obj;
}

function parseVolume(obj) {
    if (obj.data.volume == -1) {
      document.getElementById('volume').classList.add('hide');
//      domCache.volumePrct.innerText = 'Volumecontrol disabled';
//      domCache.volumeControl.classList.add('hide');
    } 
    else {
        domCache.volumeControl.classList.remove('hide');
        domCache.volumePrct.innerText = obj.data.volume + ' %';
        if (obj.data.volume == 0)
            domCache.volumeMenu.innerText = 'volume_off';
        else if (obj.data.volume < 50)
            domCache.volumeMenu.innerText = 'volume_down';
        else
            domCache.volumeMenu.innerText = 'volume_up';
    }
    domCache.volumeBar.value = obj.data.volume;
}

function getQueue() {
//    console.log('-----getQueue-----');
//    if (app.current.search.length >= 2) 
//        sendAPI({"cmd": "MPD_API_QUEUE_SEARCH", "data": {"filter": app.current.filter, "offset": app.current.page, "searchstr": app.current.search}}, parseQueue);
//    else 
//    sendAPI({"cmd": "MPD_API_QUEUE_LIST", "data": {"offset": app.current.page}}, parseQueue);
    sendAPI({"cmd": "MPD_API_QUEUE_LIST", "data": {"offset": 0}}, parseQueue);
}

function parseQueueCover(obj) {
    var ul = document.getElementById('QueueCurrentList');
    var len = obj.length;
    for (var i = 0; i < len; i++) {
	var src = obj[i].src;
	if (src == 'tidal' || src == 'qobuz' ||  src == 'youtube' ||  src == 'soundcloud') {
	    var link = obj[i].src + obj[i].id;
	    var els = ul.querySelectorAll("[data-id='"+link+"']");
	    if (els.length>0) {
		var len2 = els.length;
		for (var j = 0; j < len2; j++) {
		    var el2 = els[j].getElementsByTagName('img');
		    if (el2.length > 0) {
		      if (src == 'tidal') {
		        if (obj[i].cover) {
		    	    var link2 = obj[i].cover.replace(/-/g,'\/');
		    	    el2[0].src = 'https://resources.tidal.com/images/'+link2+'/80x80.jpg';
		        } else {
		    	    var link2 = 'icons/disc.svg';
		    	    el2[0].src = link2;
		        }
		        var art = els[j].getElementsByClassName("track-artist")[0];
		        if (art.innerHTML == '-' ) {
		    	    art.innerHTML = obj[i].artist;
		    	    els[j].getElementsByClassName("track-title")[0].innerHTML = obj[i].title;
		    	    els[j].getElementsByClassName("track-album")[0].innerHTML = obj[i].album;
//		    	    els[j].getElementsByClassName("track-duration")[0].innerHTML = HHMMSS(obj[i].duration);
		        }
		      }
		      if (src == 'qobuz') {
		        el2[0].src = obj[i].cover;
		        var art = els[j].getElementsByClassName("track-artist")[0];
		        if (art.innerHTML == '-' ) {
		    	    art.innerHTML = obj[i].artist;
		    	    //artid,albid
		    	    els[j].getElementsByClassName("track-title")[0].innerHTML = obj[i].title;
		    	    els[j].getElementsByClassName("track-album")[0].innerHTML = obj[i].album;
	    		    els[j].getElementsByClassName("track-duration")[0].innerHTML = HHMMSS(obj[i].duration);
		        }
		      }
		      if (src == 'soundcloud') {
		        el2[0].src = obj[i].cover;
		        els[j].getElementsByClassName("track-artist")[0].innerHTML = obj[i].artist;
//		    	art.innerHTML = obj[i].artist;
		    	    //artid,albid
		    	els[j].getElementsByClassName("track-title")[0].innerHTML = obj[i].title;
	    		els[j].getElementsByClassName("track-duration")[0].innerHTML = HHMMSS(Math.trunc(obj[i].duration*0.001));
		      }
		      if (src == 'youtube') {
		        el2[0].src = obj[i].thumbnail_url;
		      }
		    } //if
		} //for j
	    } //if
	} //if
    } //for
}

function parseQueue(obj) {    
    console.log('-----parseQueue-----');
/*    if (typeof(obj.totalTime) != undefined && obj.totalTime > 0 && obj.totalEntities <= settings.maxElementsPerPage )
        document.getElementById('cardFooterQueue').innerText = obj.totalEntities + ' ' + (obj.totalEntities > 1 ? 'Songs' : 'Song') + ' – ' + beautifyDuration(obj.totalTime);
    else if (obj.totalEntities > 0)
        document.getElementById('cardFooterQueue').innerText = obj.totalEntities + ' ' + (obj.totalEntities > 1 ? 'Songs' : 'Song');
    else
        document.getElementById('cardFooterQueue').innerText = '';
*/
    console.log('items:'+nrItems);

    var ul = document.getElementById('QueueCurrentList');
    ul.innerHTML = '';
    if (!obj.data) {
	var nrItems = obj.length;
	document.getElementById('totalTracks').innerHTML = nrItems + ' tracks';
//aprenderer
	for (var i = 0; i < nrItems; i++) {
	    var item = obj[i];
    	    var minutes = Math.floor(item.duration / 60);
    	    var seconds = item.duration - minutes * 60;
    	    var duration = minutes + ':' + (seconds < 10 ? '0' : '') + seconds;
    	    var row = document.createElement('li');
    	    row.classList.add('track-item');
        
    	    row.setAttribute('draggable','true');
    	    row.setAttribute('data-trackid', i);
    	    row.setAttribute('id','queueTrackId' + i);
    	    row.setAttribute('data-songpos', i);
    	    row.setAttribute('data-duration', item.duration);
    	    row.setAttribute('data-type','qitem');
    	    row.setAttribute('data-id',item.src + item.id);

    	    var title = item.title;
    	    var artist = item.artist;
    	    var album = item.album;
    	    
	    var src = item.src;
	    if (src == 'tidal' || src == 'qobuz' ||  src == 'youtube' ||  src == 'soundcloud') {
	      var cover = '';
	      if (src == 'tidal') {
	        if (item.cover) {
		    var link2 = obj[i].cover.replace(/-/g,'\/');
		    cover = 'https://resources.tidal.com/images/'+link2+'/80x80.jpg';
		} else {
		    var link2 = 'icons/disc.svg';
		    cover = link2;
		}
	      }
	      else if (src == 'qobuz' || src == 'soundcloud') {
		    cover  = item.cover; 
	      }
	      else if (src == 'youtube')
		    cover = item.thumbnail_url;
	    } //if

    	    var tds = ''+
	    '<span class="track-cover"><img src="'+cover+'" width="44px"></span>'+
//	    '<span class="track-number" data-col="Pos">'+obj.data[i].Pos+'</span>'+
    	    '<div class="track-title-mobile">'+
	    '<span class="track-title">' + title + '</span>'+
	    '<span class="track-artist">'+ artist + '</span>'+
	    '</div>'+
//	    '<span class="track-album"><a class="clickable" onclick=\'appGoto("Tidal","page","album__'+item.album.id+'");\' title="'+item.album.title+'">'+item.album.title+'</a></span>'+
	    '<span class="track-album">'+ album+'</a></span>'+
	    '<span class="track-duration">'+duration+'</span>';
//	'<span class="track-fav"><a class="material-icons" onclick="favTidal(\'track\',\''+item.id+'\');">favorite_border</a></span>'+

    	    tds += '<span class="track-action"><a href="#" class="material-icons">more_horiz</a></span>';
    	    row.innerHTML = tds;
        
        ul.appendChild(row); 

	}
	ul.classList.add('tracklist');
	modalLoader.hide();
	return;
    }
    var nrItems = obj.data.length;
    document.getElementById('totalTracks').innerHTML = nrItems + ' tracks';

    for (var i = 0; i < nrItems; i++) {
	var item = obj.data[i];
        var minutes = Math.floor(item.Duration / 60);
        var seconds = item.Duration - minutes * 60;
        var duration = minutes + ':' + (seconds < 10 ? '0' : '') + seconds;
        obj.data[i].Pos++;

        var row = document.createElement('li');
        row.classList.add('track-item');
        
        row.setAttribute('draggable','true');
        row.setAttribute('data-trackid', item.id);
        row.setAttribute('id','queueTrackId' + item.id);
        row.setAttribute('data-songpos', item.Pos);
        row.setAttribute('data-duration', item.Duration);
        row.setAttribute('data-type','qitem');
        var uri = item.uri;
        row.setAttribute('data-uri', uri);
        uri = uri.replace('://track/','');
        if (uri.indexOf('qobuz')!==-1) {
    	    uri = uri.split('|')[0];
        }
        if (uri.indexOf('youtube')!==-1) {
    	    uri = 'youtube' + uri.split('=')[1];
        }
        if (uri.indexOf('soundcloud')!==-1) {
    	    uri = uri.split('/stream?')[0].replace('tracks','#');
    	    uri = 'soundcloud' + uri.split('#/')[1];
        }
        row.setAttribute('data-id', uri);
        
        var artist = '&nbsp;';
        if (item.Name != '-') {
    	    var title = item.Name;
    	    var ar = title.split(' - ');
    	    if (ar[1]) { 
    		var title = ar[1];
    		var artist = ar[0];
    	    }
        } else {
    	    var title = item.Title;
    	    var artist = item.Artist;
        }
        if (item.Album) {
    	    var album = item.Album;
        } else { 
    	    var album = '&nbsp;';
        }
        var tds = ''+
	    '<span class="track-cover"><img src="icons/disc.svg" width="44px"></span>'+
//	    '<span class="track-number" data-col="Pos">'+obj.data[i].Pos+'</span>'+
    	    '<div class="track-title-mobile">'+
	    '<span class="track-title">' + title + '</span>'+
	    '<span class="track-artist">'+ artist + '</span>'+
	    '</div>'+
//	    '<span class="track-album"><a class="clickable" onclick=\'appGoto("Tidal","page","album__'+item.album.id+'");\' title="'+item.album.title+'">'+item.album.title+'</a></span>'+
	    '<span class="track-album">'+ album+'</a></span>'+
	    '<span class="track-duration">'+ duration +'</span>';
//	'<span class="track-fav"><a class="material-icons" onclick="favTidal(\'track\',\''+item.id+'\');">favorite_border</a></span>'+

        tds += '<span class="track-action"><a href="#" class="material-icons">more_horiz</a></span>';
        row.innerHTML = tds;
        
        ul.appendChild(row); 
    }

    ul.classList.add('tracklist');
//    cardContainer.appendChild(ul);

//    var colspan = settings['colsQueueCurrent'].length;
//    colspan--;

    if (obj.type == 'queuesearch' && nrItems == 0)
        tbody.innerHTML = '<tr><td><span class="material-icons">error_outline</span></td>' +
                          '<td colspan="' + colspan + '">No results, please refine your search!</td></tr>';
//    else if (obj.type == 'queue' && nrItems == 0)
//        tbody.innerHTML = '<tr><td><span class="material-icons">error_outline</span></td>' +
//                          '<td colspan="' + colspan + '">Empty queue</td></tr>';

//    setPagination(obj.totalEntities);

    sendAPI({"cmd": "API_QUEUE2"}, parseQueueCover);
    
//    document.getElementById('QueueCurrentList').classList.remove('opacity05');
    modalLoader.hide();
}

/*
function parseLastPlayed(obj) {
    document.getElementById('cardFooterQueue').innerText = obj.totalEntities + ' Songs';
    var nrItems = obj.data.length;
    var table = document.getElementById('QueueLastPlayedList');
    table.setAttribute('data-version', obj.queueVersion);
    var tbody = table.getElementsByTagName('tbody')[0];
    var tr = tbody.getElementsByTagName('tr');
    for (var i = 0; i < nrItems; i++) {
        var minutes = Math.floor(obj.data[i].Duration / 60);
        var seconds = obj.data[i].Duration - minutes * 60;
        obj.data[i].Duration = minutes + ':' + (seconds < 10 ? '0' : '') + seconds;
        obj.data[i].LastPlayed = new Date(obj.data[i].LastPlayed * 1000).toUTCString();
        var row = document.createElement('tr');
        row.setAttribute('data-songpos', (obj.data[i].Pos + 1));
        row.setAttribute('data-uri', obj.data[i].uri);
        row.setAttribute('data-name', obj.data[i].Title);
        row.setAttribute('data-type', 'song');
        var tds = '';
        for (var c = 0; c < settings.colsQueueLastPlayed.length; c++) {
            tds += '<td data-col="' + settings.colsQueueLastPlayed[c] + '">' + obj.data[i][settings.colsQueueLastPlayed[c]] + '</td>';
        }
        tds += '<td data-col="Action"><a href="#" class="material-icons">playlist_add</a></td>';
        row.innerHTML = tds;
        if (i < tr.length)
            tr[i].replaceWith(row); 
        else 
            tbody.append(row);  
    }
    var trLen = tr.length - 1;
    for (var i = trLen; i >= nrItems; i --) {
        tr[i].remove();
    }                    

    var colspan = settings['colsQueueLastPlayed'].length;
    colspan--;
    
    if (nrItems == 0)
        tbody.innerHTML = '<tr><td><span class="material-icons">error_outline</span></td>' +
            '<td colspan="' + colspan + '">Empty list</td></tr>';

    setPagination(obj.totalEntities);
    
    document.getElementById('QueueLastPlayedList').classList.remove('opacity05');
    modalLoader.hide();
}*/

function parseSearch(obj) {
    document.getElementById('panel-heading-search').innerHTML = obj.totalEntities + ' Songs found';
    document.getElementById('cardFooterSearch').innerHTML = obj.totalEntities + ' Songs found';
    if (obj.totalEntities > 0) {
        document.getElementById('searchAddAllSongs').removeAttribute('disabled');
        document.getElementById('searchAddAllSongsBtn').removeAttribute('disabled');
    } 
    else {
        document.getElementById('searchAddAllSongs').setAttribute('disabled','disabled');
        document.getElementById('searchAddAllSongsBtn').setAttribute('disabled','disabled');
    }
    parseFiles(obj);
}

function parseFiles(obj) {
//    console.log('---parseFiles---');
    var list = app.current.app + (app.current.tab == 'Filesystem' ? app.current.tab : '');
    var colspan = settings['cols' + list].length;
    colspan--;
    var nrItems = obj.data.length;
    var tbody = document.getElementById(app.current.app + (app.current.tab == undefined ? '' : app.current.tab) + 'List').getElementsByTagName('tbody')[0];
    if (phone) tbody.classList.add('phone');
    var tr = tbody.getElementsByTagName('tr');
    obj.data.sort(function(a,b) {return (a.name > b.name) ? 1 : ((b.name > a.name) ? -1 : 0);} );

    for (var i = 0; i < nrItems; i++) {
        var uri = encodeURI(obj.data[i].uri);
        var row = document.createElement('tr');
        row.setAttribute('data-type', obj.data[i].Type);
        row.setAttribute('data-uri', uri);
        if (obj.data[i].Type == 'song')
            row.setAttribute('data-name', obj.data[i].Title);
        else
            row.setAttribute('data-name', obj.data[i].name);

        switch(obj.data[i].Type) {
            case 'dir':
            case 'smartpls':
            case 'plist':
                var tds = '';
                for (var c = 0; c < settings['cols' + list].length; c++) {
            	    var cl = settings['cols' + list][c];
                    if (cl == 'Title')
                	tds += '<td data-col="' + cl + '"'+(cl == 'Type' ? " class='track-type'":'') +' colspan="3">';
                    if (cl == 'Type') {
                	tds += '<td data-col="' + cl + '"'+(cl == 'Type' ? " class='track-type'":'') +'>';
                        if (obj.data[i].Type == 'dir')
                            tds += '<span class="material-icons">folder</span>';
                        else
                            tds += '<span class="material-icons">list</span>';
                    }
                    else if (cl == 'Title')
                        tds += obj.data[i].name;
                    tds += '</td>';
                }
                tds += '<td data-col="Action"><a href="#" class="material-icons">more_vert</a></td>';
                row.innerHTML = tds;
                break;
            case 'song':
                var minutes = Math.floor(obj.data[i].Duration / 60);
                var seconds = obj.data[i].Duration - minutes * 60;
                obj.data[i].Duration = minutes + ':' + (seconds < 10 ? '0' : '') + seconds;
                var tds = '';
                for (var c = 0; c < settings['cols' + list].length; c++) {
            	    var cl = settings['cols' + list][c];
                    tds += '<td data-col="' + cl + '"'+(cl == 'Type' ? " class='track-type'":'')+'>';
                    if (cl == 'Type')
                        tds += '<span class="material-icons">music_note</span>';
                    else
                        tds += obj.data[i][cl];
                    tds += '</td>';
                }
                tds += '<td data-col="Action"><a href="#" class="material-icons">more_vert</a></td>';
                row.innerHTML = tds;
                break;
        }
        if (i < tr.length)
            tr[i].replaceWith(row); 
        else 
            tbody.appendChild(row);
    }
    var trLen = tr.length - 1;
    for (var i = trLen; i >= nrItems; i --) {
        tr[i].remove();
    }

//    setPagination(obj.totalEntities);

    if (nrItems == 0)
        tbody.innerHTML = '<tr><td><span class="material-icons">error_outline</span></td>' +
                          '<td colspan="' + colspan + '">No results</td></tr>';
    document.getElementById(app.current.app + (app.current.tab == undefined ? '' : app.current.tab) + 'List').classList.remove('opacity05');
    document.getElementById('cardFooterBrowse').innerText = obj.totalEntities + ' Entries';
    modalLoader.hide();
}

function parsePlaylists(obj) {
//    console.log('-----parsePlaylists-----');
    if (app.current.view == 'All') {
        document.getElementById('BrowsePlaylistsAllList').classList.remove('hide');
        document.getElementById('BrowsePlaylistsDetailList').classList.add('hide');
        document.getElementById('btnBrowsePlaylistsAll').parentNode.classList.add('hide');
        document.getElementById('btnPlaylistClear').parentNode.classList.add('hide');
        document.getElementById('BrowsePlaylistsDetailColsBtn').parentNode.classList.add('hide');
    } else {
        if (obj.uri.indexOf('.') > -1 || obj.smartpls == true) {
            document.getElementById('BrowsePlaylistsDetailList').setAttribute('data-ro', 'true');
            document.getElementById('btnPlaylistClear').parentNode.classList.add('hide');
        }
        else {
            document.getElementById('BrowsePlaylistsDetailList').setAttribute('data-ro', 'false');
            document.getElementById('btnPlaylistClear').parentNode.classList.remove('hide');
        }
        document.getElementById('BrowsePlaylistsDetailList').setAttribute('data-uri', obj.uri);
        if (obj.smartpls == true)
            document.getElementById('BrowsePlaylistsDetailList').getElementsByTagName('caption')[0].innerHTML = 'Smart playlist: ' + obj.uri +
                '<small class="pull-right">' + obj.totalEntities + ' Songs </small>';
        else
            document.getElementById('BrowsePlaylistsDetailList').getElementsByTagName('caption')[0].innerHTML = 'Playlist: ' + obj.uri +
                '<small class="pull-right">' + obj.totalEntities + ' Songs </small>';
        document.getElementById('BrowsePlaylistsDetailList').classList.remove('hide');
        document.getElementById('BrowsePlaylistsAllList').classList.add('hide');
        document.getElementById('btnBrowsePlaylistsAll').parentNode.classList.remove('hide');
        if (settings.featTags)
            document.getElementById('BrowsePlaylistsDetailColsBtn').parentNode.classList.remove('hide');
    }

    var nrItems = obj.data.length;
    var tbody = document.getElementById(app.current.app + app.current.tab + app.current.view + 'List').getElementsByTagName('tbody')[0];
    var tr = tbody.getElementsByTagName('tr');
    if (app.current.view == 'All') {
        for (var i = 0; i < nrItems; i++) {
            var uri = encodeURI(obj.data[i].uri);
            var d = new Date(obj.data[i].last_modified * 1000);
            var row = document.createElement('tr');
            row.setAttribute('data-uri', uri);
            row.setAttribute('data-type', obj.data[i].Type);
            row.setAttribute('data-name', obj.data[i].name);
            row.innerHTML = '<td data-col="Type"><span class="material-icons">list</span></td>' +
                            '<td>' + obj.data[i].name + '</td>' +
                            '<td>'+ d.toUTCString() + '</td>' +
                            '<td data-col="Action"><a href="#" class="material-icons">more_vert</a></td>';
            if (i < tr.length)
                tr[i].replaceWith(row); 
            else 
                tbody.appendChild(row);
        }
        document.getElementById('cardFooterBrowse').innerText = obj.totalEntities + ' Playlists';
    }
    else if (app.current.view == 'Detail') {
        for (var i = 0; i < nrItems; i++) {
            var uri = encodeURI(obj.data[i].uri);
            var row = document.createElement('tr');
            if (obj.smartpls == false)
                row.setAttribute('draggable','true');
            row.setAttribute('id','playlistTrackId' + obj.data[i].Pos);
            row.setAttribute('data-type', obj.data[i].Type);
            row.setAttribute('data-uri', uri);
            row.setAttribute('data-name', obj.data[i].Title);
            row.setAttribute('data-songpos', obj.data[i].Pos);
            var minutes = Math.floor(obj.data[i].Duration / 60);
            var seconds = obj.data[i].Duration - minutes * 60;
            obj.data[i].Duration = minutes + ':' + (seconds < 10 ? '0' : '') + seconds;
            var tds = '';
            for (var c = 0; c < settings.colsBrowsePlaylistsDetail.length; c++) {
                tds += '<td data-col="' + settings.colsBrowsePlaylistsDetail[c] + '">' + obj.data[i][settings.colsBrowsePlaylistsDetail[c]] + '</td>';
            }
            tds += '<td data-col="Action"><a href="#" class="material-icons">more_vert</a></td>';
            row.innerHTML = tds;

            if (i < tr.length)
                tr[i].replaceWith(row); 
            else 
                tbody.appendChild(row);
        }
        document.getElementById('cardFooterBrowse').innerText = obj.totalEntities + ' Songs';
    }
    var trLen = tr.length - 1;
    for (var i = trLen; i >= nrItems; i --) {
        tr[i].remove();
    }

    setPagination(obj.totalEntities);
    
    if (nrItems == 0) {
//        var colspan = settings['cols' + list].length;
//        var colspan = settings['colsQueueCurrent'].length;
//        colspan--;
        if (app.current.view == 'All')
            tbody.innerHTML = '<tr><td><span class="material-icons">error_outline</span></td>' +
                              '<td colspan="' + colspan + '">No playlists found.</td></tr>';
        else
            tbody.innerHTML = '<tr><td><span class="material-icons">error_outline</span></td>' +
                              '<td colspan="' + colspan + '">Empty playlist.</td></tr>';
   }            

    document.getElementById(app.current.app + app.current.tab + app.current.view + 'List').classList.remove('opacity05');
//    modalLoader.hide();
}

function parseListAlbums2(obj,request) {
// Database & Album
    var count = document.getElementById('countTxt');
    document.getElementById('BrowseDatabaseTagList').classList.add('hide');
    if (isNaN(request.data.filter)) {
	document.getElementById('BrowseDatabaseAlbumListCaption').innerHTML = '';
    }
    if (obj.length == 0){ 
	modalLoader.hide();
	return;
    }

    document.getElementById('BrowseDatabasePaginationTop').classList.add('hide');
    document.getElementById('BrowseDatabasePaginationBottom').classList.add('hide');
    var nrItems = obj.length;
    if (isNaN(request.data.filter)) {
	if (app.current.view == 'Album') {
	    var cardContainer = document.getElementById('BrowseDatabaseAlbumList');
	} else {
	    document.getElementById('BrowseDatabaseAlbumListCaption').classList.remove('hide');
	    document.getElementById('BrowseDatabaseAlbumListCaption').innerHTML = '<h2>'+ request.data.tag+': '+(request.data.val =='-' ? 'Unknown' : request.data.val)+'</h2>';
	    var cardContainer = document.getElementById('BrowseDatabaseAlbumList2');
	    cardContainer.innerHTML = '';
	}
    } else {
	var cardContainer = document.getElementById('BrowseLastAlbumList');
    }
    if (phone) cardContainer.parentNode.classList.add('phone');
    cardContainer.classList.remove('hide');
    if (request.data.offset == 0) {
	cardContainer.innerHTML = '';
	if (nrItems > 0) 
	    cardContainer.setAttribute('data-offset',nrItems);
    } else {
	var offset = parseInt(cardContainer.getAttribute('data-offset'));
	offset = offset + nrItems;
	cardContainer.setAttribute('data-offset',offset);
    }
//    var cards = cardContainer.getElementsByClassName('my-item');
    for (var i = 0; i < nrItems; i++) {
        var id = 1000 + i;
	curId = app.current.tab + '_' + id.toString();
        
        var card = document.createElement('div');
    	card.classList.add('grid-item');
        card.classList.add('mr-0');
        card.setAttribute('id', curId);
        
        if (obj[i].md5!="" && obj[i].thumb == "1") {
    	    var img = "cache/"+obj[i].md5+"/cover.jpg";
        } else {
    	    var img = "icons/disc.svg";
        }
        card.innerHTML = '<div class="card1" id="cardl' + curId + '">' +
//                             ' <a data-album="' + obj[i].album + '" data-type="dir" data-uri="'+obj[i].path+'" onclick="albumClick2(this);">' +
                             ' <a data-album="' + obj[i].album + '" data-year="'+obj[i].year+'" data-type="dir" data-uri="'+obj[i].path+'" onclick="albumClick3(this);">' +
                             ' <div class="item-wrapper"><img class="lozad" src="icons/disc.svg" data-src="'+img+'" width="100%" heigth="100%">' +
//                             ' <div class="item-wrapper"><img class="lozad" src="'+img+'" width="100%" heigth="100%">' +
                             ' <div class="overlay">'+
                             '     <button class="btn material-icons clickable" type="button" role="button" onclick=\'replaceQueue("dir","'+obj[i].path+'","'+obj[i].album+'");\'>play_arrow</button>'+
                             '     <button class="btn material-icons clickable" type="button" role="button" onclick="showMenu2(this,event);">more_vert</button>'+
                             ' </div></div></a>'+
                             '  <span class="item-title talb clickable" data-album="'+obj[i].album+'" onclick="albumClick2(this);">' + obj[i].album + '</span>' +
                             '  <span class="item-title tart" data-artist="'+ obj[i].artist + '">'+obj[i].artist+'</span>' +
                             '</div>'+
                             '<div class="grid-addon hide"><div class="grid-addon-body"></div></div>' ; //dimas
        
        cardContainer.appendChild(card);
//	if (obj[i].md5 == "")
//	    sendAPI({"cmd": "MPD_API_DATABASE_COVER_ALBUM", "data": { "album": obj[i].album, "tag": curId}}, parseCover2);

    }
    count.innerHTML = document.getElementsByClassName('grid-item').length;

    observer.observe();
    modalLoader.hide();
    scrollFlag = false;
//    cardContainer.classList.remove('opacity05');
}

//===========================================================
function CloudTab(apps,tab){
    console.log("---cloudTab---"+apps+"-"+tab);

    var radioList = "MyRadio|CapRadio|SunRadio|RedRadio|APRadio|Soundcloud|Sygma";
    if (radioList.indexOf(apps)!= -1) {
        if (apps == "Soundcloud") { //search
	    document.getElementById("Soundcloudsearch").classList.add('hide');
	    document.getElementById("SoundcloudSbody").classList.add('hide');
	    document.getElementById("SoundcloudList").classList.remove('hide');
        }
	var cardContainer = document.getElementById(apps+'Menu');

	if (apps == "MyRadio") {
	    var cards = cardContainer.getElementsByClassName('card-cloud');
	}
	else {
	    var cards = cardContainer.getElementsByClassName('list-group-item');
	}
	var nrItems = cards.length;
	for (var i = 0; i < nrItems; i++) {
	    cards[i].classList.remove('active');
	}
	if (apps == "MyRadio") {
	    var el = document.getElementById('cardMyRadioNav'+tab);
	    el.classList.add('active');
	} 
	else if (apps == "Soundcloud") {
	    if (tab == "search") { 
		cards[0].classList.add('active');
		document.getElementById("SoundcloudList").classList.add('hide');
		document.getElementById("Soundcloudsearch").classList.remove('hide');
		document.getElementById("SoundcloudSbody").classList.remove('hide');
	    } else {
		var a = parseInt(tab)+1;
		cards[a].classList.add('active');
	    }
	}
	else {
//		var a = parseInt(tab)+1;
	    cards[tab].classList.add('active');
	}
	if (apps == "Sygma") 
	    document.getElementById('SygmaDesc').innerHTML = cards[tab].getAttribute("data-desc");

	var card = document.getElementById('card'+apps);
	var cards2 = card.getElementsByClassName('dropdown-item');
	var nrItems = cards2.length;
	for (var i = 0; i < nrItems; i++) {
	    cards2[i].classList.remove('active');
	}

	var but = document.getElementById(apps+'Drop');
	if (apps == "MyRadio") {
	    var el = document.getElementById('cardMyRadioDrop'+tab);
	    el.classList.add('active');
	    but.innerHTML = el.innerHTML;
	} else if (apps == "Soundcloud") {
	    if (tab == "search") { 
		cards2[0].classList.add('active');
		but.innerHTML = cards2[0].innerHTML;
	    } else {
		var a = parseInt(tab)+1;
		cards[a].classList.add('active');
		but.innerHTML = cards2[a].innerHTML;
	    }
	
	} else {
	    cards2[tab].classList.add('active');
	    but.innerHTML = cards2[tab].innerHTML;
	}
	modalLoader.show();
	sendAPI({"cmd": "API_RADIO_LIST","data":{"service":getServ(apps),"group": tab}},parseRadioList);
    }
    else if (apps == "Podcast") {
	var cardContainer = document.getElementById('podcastMenu');
	var cards = cardContainer.getElementsByClassName('list-group-item');
	var nrItems = cards.length;

	for (var i = 0; i < nrItems; i++) {
	    cards[i].classList.remove('active');
	}
//	cards[tab].classList.add('active');
	var el = document.getElementById('cardPodcastNav'+tab);
	el.classList.add('active');
	modalLoader.show();
	sendAPI({"cmd": "API_RADIO_LIST","data":{"service":"aero","group": tab}},parsePodcastList);
    }
    else if (apps == "Prime") {
	var cardContainer = document.getElementById('primeMenu');
	var cards = cardContainer.getElementsByClassName('dropdown-item');
	var nrItems = cards.length;
	for (var i = 0; i < nrItems; i++) {
	    cards[i].classList.remove('active');
	}
	var curPrime = document.getElementById('cardPrimeNav' + app.current.tab);
	if (curPrime) {
    	    curPrime.classList.add('active');
	    document.getElementById('primeMenubutton').innerHTML = curPrime.innerHTML;
	}
	modalLoader.show();
	if (tab == "home" || tab == "browse") {
    	    sendAPI({"cmd": "API_PRIME_PAGE", "data": {"page": tab}}, parsePrime);
    	}
    	else {
    	    var view = '';
    	    if (tab == "composers") {
    		view = "query_view_search_composers?sortBy=popularityAsComposer.global&sortOrder=descending&filterBy[]=workGenreIds.keyword&filterBy[]=periodIds.keyword&filterValue[]=&filterValue[]=";
    		tab = "page";
    	    } else if (tab == "conductors") {
		view = "query_view_browse_conductor_artists?sortBy=popularityAsArtist.global&sortOrder=descending&filterBy[]=workGenreIds.keyword&filterBy[]=periodIds.keyword&filterValue[]=&filterValue[]=";
    		tab = "page";
	    } else if (tab == "ensembles") {
		view = "query_view_browse_ensemble_artists?sortBy=popularityAsArtist.global&sortOrder=descending&filterBy[]=workGenreIds.keyword&filterBy[]=periodIds.keyword&filterValue[]=&filterValue[]=";
    		tab = "page";
    	    } else if (tab == "soloists") {
		view = "query_view_browse_soloist_artists?sortBy=popularityAsArtist.global&sortOrder=descending&filterBy[]=workGenreIds.keyword&filterBy[]=periodIds.keyword&filterValue[]=&filterValue[]=";
    		tab = "page";
	    } else
		view = app.current.view;
    	    sendAPI({"cmd": "API_PRIME_PAGE", "data": {"page": view,"type":tab}}, parsePrimePage);
    	}
    	var cardContainer = document.getElementById('Primebody');
    	cardContainer.classList.remove('hide');
    }
    else if (apps == "Pitchfork") {
	var cardContainer = document.getElementById('pitchMenu');
	var cards = cardContainer.getElementsByClassName('dropdown-item');
	var nrItems = cards.length;

	for (var i = 0; i < nrItems; i++) {
	    cards[i].classList.remove('active');
	}
	var curPitch = document.getElementById('cardPitchNav' + app.current.tab);
	if (curPitch)
    	    curPitch.classList.add('active');

	var cardContainer = document.getElementById('pitchGenres');
	var cards = cardContainer.getElementsByClassName('dropdown-item');
	var nrItems = cards.length;
	for (var i = 0; i < nrItems; i++) {
	    cards[i].classList.remove('active');
	}
    	
	if (app.current.filter == '-') { 
	    var genre = 'all'; 
	} else { 
	    var genre = app.current.filter; 
	}
	
	var curPitchGenre = document.getElementById('PitchGenre' + genre);
	if (curPitchGenre) {
    	    curPitchGenre.classList.add('active');
    	    var genr = curPitchGenre.innerHTML;
	} else { 
	    var genr = genre;
//    	    var genre = curPitchGenre.getAttribute('data-tag');
    	}
    	    
	document.getElementById('pitchMenubutton').innerHTML = curPitch.innerHTML;
	document.getElementById('pitchGenrebutton').innerHTML = genr;

	modalLoader.show();
    	sendAPI({"cmd": "API_PITCHFORK_CMD", "data": {"cmd": tab,"genre":genre}}, parsePitch);
    	var cardContainer = document.getElementById('Pitchbody');
    	cardContainer.classList.remove('hide');
    }
/*    else if (apps == "Film") {
	modalLoader.show();
    	sendAPI({"cmd": "API_FILM_SEARCH", "data": {"cmd":"search","query":view}}, parseFilm);
    } */
    else if (apps == "Youtube") {
	var cardContainer = document.getElementById('youtubeMenu');
	var cards = cardContainer.getElementsByClassName('dropdown-item');
	var nrItems = cards.length;
	for (var i = 0; i < nrItems; i++) {
	    cards[i].classList.remove('active');
	}

	if (tab != 'page' )  {
	var curYt = document.getElementById('cardYoutubeNav' + tab);
	  if (curYt)
    	    curYt.classList.add('active');

	  document.getElementById('youtubeMenubutton').innerHTML = curYt.innerHTML;
	} else 
	    if (tab == 'page' && (app.current.view == 'ddd' || app.current.view == 'da')) {
		var curYt = document.getElementById('cardYoutubeNav' + app.current.view);
    		curYt.classList.add('active');

		document.getElementById('youtubeMenubutton').innerHTML = curYt.innerHTML;
	}
	if ( tab == 'account' ) {
	    document.getElementById('ysearch').style.display = 'none';
	    document.getElementById('Youtubeaccount').classList.remove('hide');
	}
	else if (tab == 'search') {
	    document.getElementById('ysearch').style.display = 'inline-block';
	    document.getElementById('Youtubeaccount').classList.add('hide');
	    document.getElementById('Youtubesearch').classList.remove('hide');
	}
	else if (tab == 'page') {
	  var view = app.current.view; 
	  if (view == 'ddd' || view == 'da') {
		modalLoader.show();
    		sendAPI({"cmd": "API_YOUTUBE_DATA", "data": {"cmd":"page","type":view}}, parseYtDDD);
	  } else {
	    var ar = view.split('__');
	    modalLoader.show();
	    sendAPI({"cmd": "API_YOUTUBE_DATA","data": {"cmd":"page","type":ar[0],"id":ar[1]}}, parseYoutube);
	  }
	}
	var cardContainer = document.getElementById('cardYoutube');
	cardContainer.classList.remove('hide');
    }

    else if (apps == "Qobuz") {
	if (phone)
	    domCache.bsearch.classList.remove('hide');
	domCache.qsearch.classList.remove('hide');
	
	var cardContainer = document.getElementById('qobuzMenu');
	var cards = cardContainer.getElementsByClassName('dropdown-item');
	var nrItems = cards.length;
	for (var i = 0; i < nrItems; i++) {
	    cards[i].classList.remove('active');
	}
	
	document.getElementById('qGenres').classList.add('hide');
	var curQobuz = document.getElementById('cardQobuzNav' + app.current.tab);
	if (curQobuz) curQobuz.classList.add('active');
	document.getElementById('q1001Years').classList.add('hide');

	var view = app.current.view;
    
	if (tab == 'page') {
	    modalQSearch('hide');


	    if (view.indexOf("__") == -1) {
		if (view == 'albums' || view == 'playlists') {
		    if (app.current.filter == '-') { 
			var genre = 'all'; 
		    } else { 
			var genre = app.current.filter; 
		    }
		    var curQobuz = document.getElementById('cardQobuzNav' + view);
		    if (curQobuz) curQobuz.classList.add('active');

		    var cardContainer = document.getElementById('qobuzGenres');
		    var cards = cardContainer.getElementsByClassName('dropdown-item');
	    	    var nrItems = cards.length;
		    for (var i = 0; i < nrItems; i++) {
			cards[i].classList.remove('active');
		    }
		    var curQobuzGenre = document.getElementById('QobuzGenre' + genre);
		    if (curQobuzGenre) {
    			curQobuzGenre.classList.add('active');
    			var genr = curQobuzGenre.innerHTML;
		    } 
    		    if (genr == undefined) genr = 'All';
		    document.getElementById('qobuzMenubutton').innerHTML = curQobuz.innerHTML;
		    document.getElementById('qobuzGenrebutton').innerHTML = genr;

		    document.getElementById('qGenres').classList.remove('hide');
		    modalLoader.show();
    		    sendAPI({"cmd": "API_QOBUZ_PAGE", "data": {"page": view,"filter":genre}}, parseQobuz);

		} else if (view == 'daaudio' || view == '1001') {
		    var curQobuz = document.getElementById('cardQobuzNav' + view);
		    if (curQobuz) curQobuz.classList.add('active');

		    var filter = app.current.filter;
		    if (filter == '-') filter = 'all';
		    document.getElementById('qobuzMenubutton').innerHTML = curQobuz.innerHTML;
		    if (view == '1001') {
			var cardContainer = document.getElementById('q1001Menu');
			var cards = cardContainer.getElementsByClassName('dropdown-item');
			var nrItems = cards.length;
			for (var i = 0; i < nrItems; i++) {
			    cards[i].classList.remove('active');
			}
			document.getElementById('q1001Menubutton').innerHTML = filter;
		
			var ecmTi = document.getElementById('q1001' + filter);
			if (ecmTi)
    			    ecmTi.classList.add('active');
    		    
	    		document.getElementById('q1001Years').classList.remove('hide');
	    	    }

//		    document.getElementById('qobuzMenubutton').innerHTML = curQobuz.innerHTML;
		    modalLoader.show();
    		    sendAPI({"cmd": "API_QOBUZ_PAGE", "data": {"page": view,"filter":filter,"offset":0}}, parseQobuz);
		} else {
		    document.getElementById('qobuzMenubutton').innerHTML = curQobuz.innerHTML;
		    modalLoader.show();
    		    sendAPI({"cmd": "API_QOBUZ_PAGE", "data": {"page": view}}, parseQobuz);
    		}
    	    }
    	    else {
    		var ar = view.split('__');
//    		console.log(ar[0]+' '+ar[1]);
    		if (ar[0] && ar[1]) {
		    modalLoader.show();
    		    sendAPI({"cmd": "API_QOBUZ_PAGID", "data": {"page": ar[0],"id":ar[1]}}, parseQobuz);
    		}
    	    }
	}
	else {
	    document.getElementById('qobuzMenubutton').innerHTML = curQobuz.innerHTML;
	    
	    var str = "explore|album|artist|playlist"; //page
	    var str2 = "labels|my|myplists|myalbums|myartists|mytracks" //list

    	    var cardContainer = document.getElementById('Qobuz'+tab);
	    if (str.indexOf(tab) !== -1) {
		if (cardContainer.getElementsByTagName('div').length == 0) {
		    modalLoader.show();
    		    sendAPI({"cmd": "API_QOBUZ_PAGE", "data": {"page": tab}}, parseQobuz);
    		}
    		else
    		    cardContainer.classList.remove('hide');
    	    } else
    	    
	    if (str2.indexOf(tab) !== -1) {
		if (tab == 'my') { 
    		  var cardContainer = document.getElementById('Q'+view);
    		} else {
    		  var cardContainer = document.getElementById('Qobuz'+tab);
    		}
		if (cardContainer.getElementsByTagName('div').length == 0 &&
		    cardContainer.getElementsByTagName('ul').length == 0) {
		    modalLoader.show();
    		    sendAPI({"cmd": "API_QOBUZ_GROUP", "data": {"group": (tab == "my" ? app.current.view : tab)}}, parseQobuzList);
    		}
    		else {
		  if (tab == 'my') {
    		    var myQ = document.getElementById('Qobuzmy');
    		    myQ.classList.remove('hide');
    		  } else {
    		    cardContainer.classList.remove('hide');
    		  }
    		}
    	    } else {
    		cardContainer.classList.remove('hide');
    	    }
	}
    }
    else if (apps == "Tidal") {
	if (phone)
	    domCache.bsearch.classList.remove('hide');
	domCache.tsearch.classList.remove('hide');
	
	var cardContainer = document.getElementById('tidalMenu');
	var cards = cardContainer.getElementsByClassName('dropdown-item');
	var nrItems = cards.length;
	
	for (var i = 0; i < nrItems; i++) {
	    cards[i].classList.remove('active');
	}

	var lst = "ecm|daaudio|1001|apple|ddd|plists|twgeema";
	if (app.current.tab == 'page' && lst.indexOf(app.current.view) !== -1) {
//	if (app.current.tab == 'page' && (app.current.view == 'ecm' || app.current.view == 'daaudio' || app.current.view == '1001' || app.current.view == 'apple' || app.current.view == 'ddd' ||app.current.view == 'plists' || app.current.view == 'twgeema')) {
	    var curTidal = document.getElementById('cardTidalNav'+app.current.view);
	} else {
	    var curTidal = document.getElementById('cardTidalNav' + app.current.tab);
	}
	
	if (curTidal) curTidal.classList.add('active');
	
	document.getElementById('ecmYears').classList.add('hide');
	document.getElementById('a1001Years').classList.add('hide');
//	cards[tab].classList.add('active');
	if (tab == 'page') {
	    modalSearch('hide');

	    var view = app.current.view;
	    if (view.indexOf("single-") !== -1)
		view = view.replace(/_/g,"\/");

	    if (view == 'ecm') {
		var cardContainer = document.getElementById('ecmMenu');
		var cards = cardContainer.getElementsByClassName('dropdown-item');
		var nrItems = cards.length;
		for (var i = 0; i < nrItems; i++) {
		    cards[i].classList.remove('active');
		}
		var filter = app.current.filter;
		if (filter == '-') filter = 'all';

		document.getElementById('ecmMenubutton').innerHTML = filter;
		document.getElementById('tidalMenubutton').innerHTML = curTidal.innerHTML;
		
		var ecmTi = document.getElementById('ecm' + filter);
		if (ecmTi) {
    		    ecmTi.classList.add('active');
//    		    var genr = curPitchGenre.innerHTML;
//		} else { 
//		    var genr = genre;
    		}
		document.getElementById('ecmYears').classList.remove('hide');
    		
//		if (document.getElementById('Tidal'+view+'body').getElementsByTagName('div').length == 0) {
		    modalLoader.show();
    		    sendAPI({"cmd": "API_TIDAL_PAGE", "data": {"page": view,"filter":filter,"offset":0}}, parseTidalECM);
//    		}

	    } else if (view == 'daaudio' || view == '1001') {
		var filter = app.current.filter;
		if (filter == '-') filter = 'all';
		if (view == '1001') {
		    var cardContainer = document.getElementById('a1001Menu');
		    var cards = cardContainer.getElementsByClassName('dropdown-item');
		    var nrItems = cards.length;
		    for (var i = 0; i < nrItems; i++) {
			cards[i].classList.remove('active');
		    }

		    document.getElementById('a1001Menubutton').innerHTML = filter;
		    document.getElementById('tidalMenubutton').innerHTML = curTidal.innerHTML;
		
		    var ecmTi = document.getElementById('a1001' + filter);
		    if (ecmTi) {
    			ecmTi.classList.add('active');
    		    }
	    	    document.getElementById('a1001Years').classList.remove('hide');
	    	}

		document.getElementById('tidalMenubutton').innerHTML = curTidal.innerHTML;
//		if (document.getElementById('Tidal'+(view == 'daaudio'? 'da': view)+'body').getElementsByTagName('div').length == 0) {
		    modalLoader.show();
    		    sendAPI({"cmd": "API_TIDAL_PAGE", "data": {"page": view,"filter":filter,"offset":0}}, parseTidalECM);
//    		}
	    } else if (view == 'plists') {
		document.getElementById('tidalMenubutton').innerHTML = curTidal.innerHTML;
		modalLoader.show();
    		sendAPI({"cmd": "API_TIDAL_PAGE", "data": {"page": view}}, parsePlists);
	    } else if (view == 'twgeema') {
		document.getElementById('tidalMenubutton').innerHTML = curTidal.innerHTML;
		modalLoader.show();
    		sendAPI({"cmd": "API_TIDAL_PAGE", "data": {"page": view}}, parseTWGEEMA);
	    } else if (view == 'ddd') {
		document.getElementById('tidalMenubutton').innerHTML = curTidal.innerHTML;
		var filter = app.current.filter;
		if (filter == '-') filter = '';
		modalLoader.show();
    		sendAPI({"cmd": "API_TIDAL_PAGE", "data": {"page": view,"filter":filter}}, parseDDD);
	    } else if (view == 'apple') {
		document.getElementById('tidalMenubutton').innerHTML = curTidal.innerHTML;
		var filter = app.current.filter;
		if (filter == '-') filter = '';
		modalLoader.show();
    		sendAPI({"cmd": "API_TIDAL_PAGE", "data": {"page": view,"filter":filter}}, parseApple);
	    } else {
	      if (view.indexOf("__") == -1) {
		modalLoader.show();
    		sendAPI({"cmd": "API_TIDAL_PAGE", "data": {"page": view}}, parseTidal);
    	      }
    	      else {
    		var ar = view.split('__');
//    		console.log(ar[0]+' '+ar[1]);
		if (ar[0]=="apple") {
		    modalLoader.show();
    		    sendAPI({"cmd": "API_TIDAL_PAGID", "data": {"page": ar[0],"id":ar[1]}}, parseApple);
		} else 
		if (ar[0]=="ddd") {
		    modalLoader.show();
    		    sendAPI({"cmd": "API_TIDAL_PAGID", "data": {"page": ar[0],"id":ar[1]}}, parseDDD);
		} else 
		if (ar[0]=="twgeema") {
		    modalLoader.show();
    		    sendAPI({"cmd": "API_TIDAL_PAGID", "data": {"page": ar[0],"id":ar[1]}}, parseTWGEEMA);
		} else 
		if (ar[0]=="aplaylist") {
		    modalLoader.show();
    		    sendAPI({"cmd": "API_TIDAL_PAGID", "data": {"page": ar[0],"id":ar[1]}}, parseApple);
		} else 
    		if (ar[0] && ar[1]) {
		    modalLoader.show();
    		    sendAPI({"cmd": "API_TIDAL_PAGID", "data": {"page": ar[0],"id":ar[1]}}, parseTidal);
    		}
    	      }
//    		var cardContainer = document.getElementById('Tidalpage');
//    		cardContainer.classList.remove('hide');
    	    }
    	
	}
	else {
	    document.getElementById('tidalMenubutton').innerHTML = curTidal.innerHTML;
	    var str = "home|explore|videos|album|artist|playlist"; //page
    	    var cardContainer = document.getElementById('Tidal'+tab);
	    if (str.indexOf(tab) !== -1) {
		if (cardContainer.getElementsByTagName('div').length == 0) {
	    	    modalLoader.show();
    		    sendAPI({"cmd": "API_TIDAL_PAGE", "data": {"page": tab}}, parseTidal);
    		} else
    		    cardContainer.classList.remove('hide');
    	    } else 
	    if (tab == 'my') {
		var view = app.current.view;
    		var cardContainer = document.getElementById('T' + view);
		
		if (cardContainer.getElementsByTagName('div').length == 0 &&
		    cardContainer.getElementsByTagName('ul').length == 0) {
		    modalLoader.show();
    		    sendAPI({"cmd": "API_TIDAL_GROUP", "data": {"group": view}}, parseTidalList);
    		} else {
    		    var myT = document.getElementById('Tidalmy');
    		    myT.classList.remove('hide');
//    		    cardContainer.classList.remove('hide');
    		}
    	    } else {
    		cardContainer.classList.remove('hide');
    	    }
	}
    }
}


var createClickHandler = function(apps,arg,arg2) {
  return function() { if (arg2) {appGoto(apps,arg,arg2,'0/-/');} else {appGoto(apps,arg,undefined,'0/-/');} };
}

function parseMPDTags(obj) {
    document.getElementById('BrowseDatabaseAlbumListCaption').classList.add('hide');
    document.getElementById('BrowseDatabaseAlbumList').classList.add('hide');
    document.getElementById('BrowseDatabaseAlbumList2').classList.add('hide');
    document.getElementById('BrowseDatabaseTagList').classList.remove('hide');
    document.getElementById('btnBrowseDatabaseByTag').parentNode.classList.remove('hide');
    document.getElementById('BrowseDatabaseAddAllSongs').parentNode.parentNode.classList.add('hide');
    document.getElementById('btnBrowseDatabaseTag').parentNode.classList.add('hide');
    document.getElementById('BrowseDatabaseFilter').classList.remove('hide');//dimas
//    document.getElementById('BrowseDatabaseTagListCaption').innerText = app.current.view;
//    document.getElementById('cardFooterBrowse').innerText = obj.totalEntities + ' Tags';
    var nrItems = obj.length;
    var tbody = document.getElementById(app.current.app + app.current.tab + 'TagList').getElementsByTagName('tbody')[0];
    tbody.innerHTML = '';
//    var tr = tbody.getElementsByTagName('tr');
    for (var i = 0; i < nrItems; i++) {
        var uri = encodeURI(obj[i].tag);
        var row = document.createElement('tr');
        if (uri == '') uri='-';
        row.setAttribute('data-uri', uri);
        var tag = (obj[i].tag =='' ? 'Unknown' : obj[i].tag);
        row.innerHTML='<td data-col="Type"></td>' +
                          '<td>' + tag + '<span class="badge-light2"> ('+ obj[i].total +')</span></td>';

        tbody.appendChild(row);
    }
    if (nrItems == 0) 
        tbody.innerHTML = '<tr><td><span class="material-icons">error_outline</span></td>' +
      '<td>No entries found.</td></tr>';
    document.getElementById('BrowseDatabaseTagList').classList.remove('opacity05');
}

function parseListDBtags(obj) {
//    console.log('-----parseListdbtags-----');
//    console.log('total:'+obj.totalEntities+',return:'+obj.returnedEntities);
    scrollTo(0);
    if (app.current.search != '') {
	if (app.current.tab  == 'AlbumInfo') {
    	    document.getElementById('BrowseAlbumInfo').classList.remove('hide');
    	    document.getElementById('BrowseAlbumInfoCaption').innerHTML = '<h2>' + obj.searchtagtype + ': ' + obj.searchstr + '</h2><hr/>';
	}
	else {
    	    document.getElementById('BrowseDatabaseAlbumList').classList.remove('hide');
    	    document.getElementById('BrowseDatabaseAlbumListCaption').innerHTML = '<h2>' + obj.searchtagtype + ': ' + obj.searchstr + '</h2><hr/>';
	}
    	document.getElementById('BrowseDatabaseTagList').classList.add('hide');
        document.getElementById('btnBrowseDatabaseByTag').parentNode.classList.add('hide');
        document.getElementById('btnBrowseDatabaseTag').parentNode.classList.remove('hide');
        document.getElementById('BrowseDatabaseAddAllSongs').parentNode.parentNode.classList.remove('hide');
//        document.getElementById('BrowseDatabaseColsBtn').parentNode.classList.remove('hide');
        document.getElementById('btnBrowseDatabaseTag').innerHTML = '&laquo; ' + app.current.view;
//        document.getElementById('cardFooterBrowse').innerText = obj.totalEntities + ' Entries';

        if (app.current.view  == 'Album' || app.current.tab  == 'AlbumInfo')
    	    document.getElementById('BrowseDatabaseFilter').classList.add('hide');

	if (app.current.view  == 'Album') //dimas
    	    document.getElementById('BrowseDatabaseAlbumListCaption').classList.add('hide');
	if (app.current.tab  == 'AlbumInfo') //dimas
    	    document.getElementById('BrowseAlbumInfoCaption').classList.add('hide');

        var nrItems = obj.data.length;
        
	if (app.current.tab == 'AlbumInfo')
    	    var cardContainer = document.getElementById('BrowseAlbumInfo')
	else
    	    var cardContainer = document.getElementById('BrowseDatabaseAlbumList');
    	var cards = cardContainer.getElementsByClassName('my-item');
        for (var i = 0; i < nrItems; i++) {
    	    var id = 1000 + i;
    	    curId = app.current.tab + '_' + id.toString();

            var card = document.createElement('div');

    	    card.classList.add('my-item');
            if (app.current.view  != 'Album' && app.current.tab  != 'AlbumInfo') //dimas
    		card.classList.add('grid-item');
    	    else
    		card.classList.add('col-md');

            card.classList.add('mr-0');
            if (app.current.view  == 'Album' || app.current.tab  == 'AlbumInfo') //dimas
    		card.classList.add('w100');
//            card.classList.add('card', 'ml-4', 'mr-4', 'mb-4', 'w-100');
            card.setAttribute('id', curId);
            card.setAttribute('data-album',encodeURI(obj.data[i].value));
            
            if (app.current.view  != 'Album' && app.current.tab != 'AlbumInfo') {
            card.innerHTML = '<div class="card1" id="card' + curId + '">' +
//                             ' <a href="#" class="clickable" data-name="' + obj.data[i].value + '" onclick="albumClick2(this);">'+
                             ' <a href="#" class="clickable" data-album="' + obj.data[i].value + '" onclick="albumClick2(this);">'+
                             '<div class="item-wrapper"><img src="icons/disc.svg" width="100%" height="100%">'+
                             '<div class="overlay">'+
            			'<button id="play'+curId+'"class="btn material-icons clickable" type="button" role="button">play_arrow</button>'+
            			'<button id="more'+curId+'"class="btn material-icons clickable" type="button" role="button">more_vert</button>'+
                             '</div></div></a>' +
                             ' <div class="card-body1">' +
                             '  <span class="item-title talb clickable" data-album="'+obj.data[i].value+'" onclick="albumClick2(this);">' + obj.data[i].value + '</span>' +
                             '  <span class="item-title tart" id="albumartist' + curId + '"></span>' +
                             ' </div>'+
                             '</div>'; //dimas
            
            }
            else {

	    if (app.current.tab == 'AlbumInfo') {
	        var btnback = document.getElementById('btnAlbumInfoBack');
    		btnback.innerHTML = '&laquo; Back';
    		btnback.setAttribute('data-href','#');
    		btnback.setAttribute('onclick','history.back();return false;');
	    }
//    	    var btnback = document.getElementById('btnBrowseDatabaseTag');
//    	    btnback.innerHTML = '&laquo; Back';
//    	    btnback.setAttribute('data-href','#');
//    	    btnback.setAttribute('onclick','history.back();return false;');

    	    document.getElementById('btnBrowseDatabaseTag').innerHTML = '&laquo; Back';
            card.innerHTML = '<div class="card1 mb-4" id="card' + curId + '">' +
        		     ' <div style="width:100%;display:inline-block;margin-bottom:20px;">'+
                             ' <a href="#" class="card-img-album" style="float:left;" data-name="' + obj.data[i].value + '"></a>' +
                             ' <div style="margin:20px;float:left;">'+
                             '   <span class="item-title clickable" id="albumartist' + curId + '" onclick="artistClick2(this)"></span>' +
                             '   <span class="item-title">' + obj.data[i].value + '</span>' +
			     ' </div>' +
			     ' </div>' +
                             ' <div class="card-body card-body1">' +
                             '  <table class="table table-sm table-hover" id="tbl' + curId + '" >'+
                             '  <tbody></tbody></table>'+
                             ' </div>'+
                             '</div>';
            }

            if (i < cards.length)
                cards[i].replaceWith(card); 
            else 
                cardContainer.appendChild(card);

	    if (app.current.view  == 'Album') { //dimas
                sendAPI({"cmd": "MPD_API_DATABASE_TAG_ALBUM_TITLE_LIST", "data": { "album": obj.data[i].value, "search": app.current.search, "tag": app.current.view, "id": curId}}, parseListTitles);
            }
	    else if (app.current.tab == 'AlbumInfo') {
                sendAPI({"cmd": "MPD_API_DATABASE_TAG_ALBUM_TITLE_LIST", "data": { "album": obj.data[i].value, "search": app.current.search, "tag": "Album", "id": curId}}, parseListTitles);
	    }
	    else { //Artist, Genres
        	sendAPI({"cmd": "MPD_API_DATABASE_COVER_ARTIST", "data": { "album": obj.data[i].value, "search": obj.data[i].value, "tag": curId}}, parseCover);
//                sendAPI({"cmd": "MPD_API_DATABASE_TAG_ALBUM_TITLE_LIST", "data": { "album": obj.data[i].value, "search": app.current.search, "tag": app.current.view, "id": curId}}, parseListTitles);
            }
 
        }
        var cardsLen = cards.length - 1;
        for (var i = cardsLen; i >= nrItems; i --) {
            cards[i].remove();
        }
	if (app.current.tab != 'AlbumInfo')
    	    setPagination(obj.totalEntities,'Album');

        setCols('BrowseDatabase', '.tblAlbumTitles');
        var tbls = document.querySelectorAll('.tblAlbumTitles');
        for (var i = 0; i < tbls.length; i++) 
            dragAndDropTableHeader(tbls[i]);
        
        if (app.current.tab == 'AlbumInfo') 
    	    document.getElementById('BrowseAlbumInfo').classList.remove('opacity05')
    	else
    	    document.getElementById('BrowseDatabaseAlbumList').classList.remove('opacity05');        
    }  
    else {
        document.getElementById('BrowseDatabaseAlbumList').classList.add('hide');
        document.getElementById('BrowseDatabaseAlbumList2').classList.add('hide');
        document.getElementById('BrowseDatabaseTagList').classList.remove('hide');
        document.getElementById('btnBrowseDatabaseByTag').parentNode.classList.remove('hide');
        document.getElementById('BrowseDatabaseAddAllSongs').parentNode.parentNode.classList.add('hide');
//        document.getElementById('BrowseDatabaseColsBtn').parentNode.classList.add('hide');
        document.getElementById('btnBrowseDatabaseTag').parentNode.classList.add('hide');
//        document.getElementById('btnBrowseDatabaseBack').parentNode.classList.add('hide'); //dimas
        document.getElementById('BrowseDatabaseFilter').classList.remove('hide');//dimas
        document.getElementById('BrowseDatabaseTagListCaption').innerText = app.current.view;                
        document.getElementById('cardFooterBrowse').innerText = obj.totalEntities + ' Tags';
        var nrItems = obj.data.length;
        var tbody = document.getElementById(app.current.app + app.current.tab + 'TagList').getElementsByTagName('tbody')[0];
        var tr = tbody.getElementsByTagName('tr');
        for (var i = 0; i < nrItems; i++) {
            var uri = encodeURI(obj.data[i].value);
            var row = document.createElement('tr');
            row.setAttribute('data-uri', uri);
//            row.innerHTML='<td data-col="Type"><span class="material-icons">album</span></td>' +
            row.innerHTML='<td data-col="Type"></td>' +
                          '<td>' + obj.data[i].value + '</td>';

            if (i < tr.length)
                tr[i].replaceWith(row); 
            else 
                tbody.appendChild(row);

        }
        var trLen = tr.length - 1;
        for (var i = trLen; i >= nrItems; i --) {
            tr[i].remove();
        }

        setPagination(obj.totalEntities);

        if (nrItems == 0) 
            tbody.innerHTML = '<tr><td><span class="material-icons">error_outline</span></td>' +
                              '<td>No entries found.</td></tr>';
        document.getElementById('BrowseDatabaseTagList').classList.remove('opacity05');                              
    }
}

/*
function createListTitleObserver(ele) {
  var options = {
    root: null,
    rootMargin: "0px",
  };

  var observer = new IntersectionObserver(getListTitles, options);
  observer.observe(ele);
}*/

function parseCover(obj) {
    var id = obj.id;
    if (id == '') return;
    var card = document.getElementById('card' + id);
    var img = card.getElementsByTagName('img')[0];
    if (img) {
      if (obj.thumb)
	img.setAttribute("src",obj.thumb);
      else if (obj.cover)
	img.setAttribute("src",obj.cover);

    var play = card.querySelector('#play'+id);
    var more = card.querySelector('#more'+id);
    var link = img.parentNode.parentNode;
      link.setAttribute('data-uri', encodeURI(obj.uri.replace(/\/[^\/]+$/, '')));
      link.setAttribute('data-name', link.getAttribute('data-album'));
      link.setAttribute('data-type', 'dir');

      more.addEventListener('click', function(event) {
	showMenu(link, event);
      }, false);
      play.addEventListener('click', function(event) {
	replaceQueue('dir',obj.uri.replace(/\/[^\/]+$/, ''),link.getAttribute('data-album'));
      }, false);
    }
    if (id.indexOf('Last')==-1)
	document.getElementById('albumartist' + id).innerText = obj.Artist;
}

function parseCover2(obj) {
//    console.log('>>>>parsecover2');
    var id = obj.id;
    if (id == '') return;
    var card = document.getElementById('card' + id);
    if (obj.thumb == "1") {
	var img = card.getElementsByTagName('img')[0];
	img.setAttribute("src","cache/"+obj.md5+"/cover.jpg");
    } 
}


function getListTitles(changes, observer) {
    changes.forEach(function(change){
        if (change.intersectionRatio > 0) {
            observer.unobserve(change.target);
            var album = decodeURI(change.target.getAttribute('data-album'));
            sendAPI({"cmd": "MPD_API_DATABASE_TAG_ALBUM_TITLE_LIST", "data": { "album": album, "search": app.current.search, "tag": app.current.view}}, parseListTitles);
        }
    });
}

function parseListTitles(obj) {
//    console.log('parseListTitles '+obj.id+','+obj.ALbum +','+ obj.AlbumArtist);
    var id = obj.id;
    var card = document.getElementById('card' + id);
    if (app.current.view == 'Album' || app.current.tab == 'AlbumInfo') { //dimas
	var tbody = card.getElementsByTagName('tbody')[0];
//	var cardHeader = card.querySelector('.card-header');
	var cardHeader = card.querySelector('.card-img-album');
	cardHeader.setAttribute('data-uri', encodeURI(obj.data[0].uri.replace(/\/[^\/]+$/, '')));
	cardHeader.setAttribute('data-name', obj.Album);
	cardHeader.setAttribute('data-type', 'dir');
	cardHeader.addEventListener('click', function(event) {
    	    showMenu(this, event);
	}, false);
	cardHeader.classList.add('clickable');
    }
    var img = card.getElementsByTagName('a')[0];
    if (img) {
	if (obj.thumb == '') {
	    img.style.backgroundImage = 'url("' + obj.cover + '")';
	}
	else {
	    img.style.backgroundImage = 'url("' + obj.thumb + '")';
	}
	img.setAttribute('data-uri', encodeURI(obj.data[0].uri.replace(/\/[^\/]+$/, '')));
	img.setAttribute('data-name', obj.Album);
	img.setAttribute('data-type', 'dir');
	img.addEventListener('click', function(event) {
        showMenu(this, event);
	}, false);
    }

//    document.getElementById('albumartist' + id).setAttribute('data-albumartist',obj.AlbumArtist); //dimas

  
  if (app.current.view == 'Album' || app.current.tab == 'AlbumInfo' ) { //dimas
    document.getElementById('albumartist' + id).innerText = obj.data[0].AlbumArtist;
    var titleList = '';
    var nrItems = obj.data.length;
    for (var i = 0; i < nrItems; i++) {
        if (obj.data[i].Duration) {
    	    var minutes = Math.floor(obj.data[i].Duration / 60); //dimas
    	    var seconds = obj.data[i].Duration - minutes * 60;//dimas
            obj.data[i].Duration = minutes + ':' + (seconds < 10 ? '0' : '') + seconds;
	}
        titleList += '<tr data-type="song" data-name="' + obj.data[i].Title + '" data-uri="' + encodeURI(obj.data[i].uri) + '">';
        for (var c = 0; c < settings.colsBrowseDatabase.length; c++) {
            titleList += '<td data-col="' + settings.colsBrowseDatabase[c] + '">' + obj.data[i][settings.colsBrowseDatabase[c]] + '</td>';
        }
        titleList += '<td data-col="Action"><a href="#" class="material-icons">more_vert</a></td></tr>';

/*	    var tr = document.createElement('li');
	    tr.setAttribute('data-type','track');
	    tr.setAttribute('data-title',item.title);
	    tr.setAttribute('data-id',item.id);
	    tr.innerHTML = '<span class="track-number">'+item.trackNumber+'</span>'+
    	    '<div class="track-title-mobile">'+
	    '<span class="track-title clickable" title="'+item.title+'"><a onclick="playTidal(\'track\',\''+item.id+'\',event); return false;" title="'+item.title+'">'+item.title+'</a></span>'+
	    '<span class="track-artist clickable"><a onclick=\'appGoto("Tidal","page","artist__' + item.artists[0].id+'");\' title="'+item.artists[0].name+'">'+item.artists[0].name+'</a></span>'+
	    '</div>'+
	    '<span class="track-duration">'+HHMMSS(item.duration)+'</span>'+
	    '<span class="track-fav"><a class="material-icons" onclick="favTidal(\'track\',\''+item.id+'\',event);" title="Add to My Collection">favorite_border</a></span>'+
	    '<span class="track-action"><a class="clickable material-icons" onclick="showMenu2(this.parentNode,event);" title="Show menu">more_vert</a></span>';
    	    tbl.appendChild(tr);

        	    
    	    */

    }
    tbody.innerHTML = titleList;
  } else {
    document.getElementById('albumartist' + id).innerText = obj.AlbumArtist;
  }
 

    if (app.current.view == 'Album' || app.current.tab == 'AlbumInfo') //dimas 

    tbody.parentNode.addEventListener('click', function(event) {
        if (event.target.nodeName == 'TD') {
            appendQueue('song', decodeURI(event.target.parentNode.getAttribute('data-uri')), event.target.parentNode.getAttribute('data-name'));
        }
        else if (event.target.nodeName == 'A') {
            showMenu(event.target, event);
        }
    }, false);
//    modalLoader.hide();
}

function setPagination(number, val) {
var totalPages = 0;
var max = 0;
//    console.log('---setPagination---');
    if (val == 'Album') {
	max = settings.maxAlbumsPerPage;
    }
    else {
	max = settings.maxElementsPerPage;
    }

    totalPages = Math.ceil(number / max);
    var cat = app.current.app + (app.current.tab == undefined ? '': app.current.tab);
    if (totalPages == 0) 
        totalPages = 1;
    var p = ['PaginationTop', 'PaginationBottom'];
    for (var i = 0; i < 2; i++) {
        document.getElementById(cat + p[i] + 'Page').innerText = (app.current.page / max + 1) + ' / ' + totalPages;
        if (totalPages > 1) {
            document.getElementById(cat + p[i] + 'Page').removeAttribute('disabled');
            var pl = '';
            for (var j = 0; j < totalPages; j++) {
                pl += '<button data-page="' + (j * max) + '" type="button" class="mr-1 mb-1 btn-sm btn btn-secondary">' +
                    ( j + 1) + '</button>';
            }
            document.getElementById(cat + p[i] + 'Pages').innerHTML = pl;
        } else {
            document.getElementById(cat + p[i] + 'Page').setAttribute('disabled', 'disabled');
        }
    
        if (number > app.current.page + max) {
            document.getElementById(cat + p[i] + 'Next').removeAttribute('disabled');
            document.getElementById(cat + p[i]).classList.remove('hide');
            document.getElementById(cat + 'ButtonsBottom').classList.remove('hide');
        } else {
            document.getElementById(cat + p[i] + 'Next').setAttribute('disabled', 'disabled');
            document.getElementById(cat + p[i]).classList.add('hide');
            document.getElementById(cat + 'ButtonsBottom').classList.add('hide');
        }
    
        if (app.current.page > 0) {
            document.getElementById(cat + p[i] + 'Prev').removeAttribute('disabled');
            document.getElementById(cat + p[i]).classList.remove('hide');
            document.getElementById(cat + 'ButtonsBottom').classList.remove('hide');
        } else {
            document.getElementById(cat + p[i] + 'Prev').setAttribute('disabled', 'disabled');
        }
    }
}

function appendQueue(type, uri, name) {
//    console.log('-----appendQueue-----');
    switch(type) {
        case 'song':
        case 'dir':
            sendAPI({"cmd": "MPD_API_QUEUE_ADD_TRACK", "data": {"uri": uri}});
            showNotification('"' + name + '" added', '', '', 'success');
            break;
        case 'plist':
            sendAPI({"cmd": "MPD_API_QUEUE_ADD_PLAYLIST", "data": {"plist": uri}});
            showNotification('"' + name + '" added', '', '', 'success');
            break;
    }
}

function appendAfterQueue(type, uri, to, name) {
    switch(type) {
        case 'song':
            sendAPI({"cmd": "MPD_API_QUEUE_ADD_TRACK_AFTER", "data": {"uri": uri, "to": to}});
            showNotification('"' + name + '" added to pos ' + to, '', '', 'success');
            break;
    }
}

function replaceQueue(type, uri, name) {
//    console.log('-----replaceQueue-----'+type+' '+uri+' '+name );

    switch(type) {
        case 'song':
//            sendAPI({"cmd": "MPD_API_QUEUE_REPLACE_TRACK", "data": {"uri": uri}});
            sendAPI({"cmd": "API_URL_REPLACE_PLAYLIST", "data": {"url": uri}});
            showNotification('"' + name + '" replaced', '', '', 'success');
            break;
        case 'dir':
            sendAPI({"cmd": "MPD_API_QUEUE_REPLACE_TRACK", "data": {"uri": uri}});
            showNotification('"' + name + '" replaced', '', '', 'success');
            break;
        case 'plist':
            sendAPI({"cmd": "MPD_API_QUEUE_REPLACE_PLAYLIST", "data": {"plist": uri}});
            showNotification('"' + name + '" replaced', '', '', 'success');
            break;
    }
}

function artistClick() {
    var albumartist = domCache.currentArtist.getAttribute('data-albumartist');
    if (albumartist != '') 
        appGoto('Browse', 'Database', 'AlbumArtist', '0/-/' + albumartist);
}

function artistClick2(a) {
    var albumartist = a.getAttribute('data-albumartist');
    if (albumartist != '') 
        appGoto('Browse', 'Database', 'AlbumArtist', '0/-/' + albumartist);
}

function albumClick() {
    var album = domCache.currentAlbum.getAttribute('data-album');
    if (album != '') 
        appGoto('Browse', 'Database', 'Album', '0/-/' + album);
}

function albumClick2(a) { //dimas
    var album = a.getAttribute('data-album');
    if (album != '') 
        appGoto('Browse', 'AlbumInfo', undefined, '0/-/' + album);
}

function parseAlbum3(obj,request,a) { //dimas
var griditem;
    if (SelectedAddon) {
	SelectedAddon.innerHTML = '';
	SelectedAddon.parentNode.classList.add('hide');
	griditem = SelectedAddon.parentNode.parentNode;
	griditem.style.height = null;
	griditem.getElementsByClassName('card1')[0].classList.remove('active-tool');
//	griditem.getElementsByClassName('tart')[0].classList.remove('hide');
    }
    griditem = a.parentNode.parentNode;
    var addon = griditem.getElementsByClassName('grid-addon')[0];

    griditem.getElementsByClassName('card1')[0].classList.add('active-tool');

    var b = addon.getElementsByClassName('grid-addon-body')[0];
    if (SelectedAddon === b) {
	SelectedAddon = null;
	return;
    }

    var img = a.getElementsByTagName('img')[0];
    if (!phone && img.src.indexOf('icons/disc.svg')==-1) {
	var div = document.createElement('div');
	div.classList.add('art-wrap');
	var img = document.createElement('img');
	img.src = a.getElementsByTagName('img')[0].src;
	div.appendChild(img);

	b.appendChild(div);

	var div = document.createElement('div');
	div.style.clear='both';
	b.parentNode.appendChild(div);
    }
    var h2 = document.createElement('h2');
    var year = a.getAttribute('data-year');
    h2.innerHTML = a.getAttribute('data-album') + (year =='' ? '':'&nbsp;&nbsp;('+year+')');
    h2.classList.add('Color1');
    
    b.appendChild(h2);
    var h3 = document.createElement('h3');
    h3.innerText = griditem.getElementsByClassName('tart')[0].getAttribute('data-artist');
    h3.classList.add('Color2');
    b.appendChild(h3);
//    griditem.getElementsByClassName('tart')[0].classList.add('hide');

    var div = document.createElement('div');
    var ol = document.createElement('ul');
    ol.classList.add('Color2');
    var len = obj.data.length;
    if (len>6) div.classList.add('multi');
    if (len<13) div.classList.add('linehi');
    for (var i = 0; i < len; i++) {
//	if (i>0 && item.uri.indexOf('.cue')!=0) break;
        var item = obj.data[i];
//	if (parseInt(item.Duration) == 0) continue;
	var li = document.createElement('li');
	li.setAttribute("data-type","song");
	li.setAttribute("data-name", item.Title);
	li.setAttribute("data-uri",encodeURI(item.uri));

	li.innerHTML = '<span class="trnumber">' + item.Track + '.</span>'+
	'<span class="trtitle clickable Color1" onclick=\'appendQueue("song","'+ item.uri+'","'+ item.Title+'");\'>'+item.Title+'</span>'+
	'<span class="trtime">'+ HHMMSS(parseInt(item.Duration))+'</span>';

/*	li.innerHTML = '<a href="#" class="Color1" onclick=\'appendQueue("song","'+ item.uri+'","'+ item.Title+'");\'>'+item.Title+'</a>'+
	'<span style="float:right">'+ HHMMSS(parseInt(item.Duration))+'</span>';*/
	ol.appendChild(li);
    }
    div.appendChild(ol);
    b.appendChild(div);

    addon.classList.remove('hide');
    griditem.style.height = griditem.offsetHeight + addon.offsetHeight +'px';
//  window.orientation !== undefined -> mobile

    if (!phone && img.src.indexOf('icons/disc.svg')==-1) {
	var colors = getColors(img);
	styleBackground(colors[1], b);
	styleText(colors[1], colors[0],b);
    } else {
	b.style.backgroundColor = '#ddd';
	b.style.color = '#333';
	var div1 = b.parentNode.parentNode.getElementsByClassName('card1')[0];
	try {
	    div1.pseudoStyle("after","border-bottom-color","#ddd");
	}
	catch(err){
	}
    }
    SelectedAddon = b;
}

function albumClick3(a) { //dimas
    console.log(a);
//    sendAPI({"cmd": "MPD_API_DATABASE_TAG_ALBUM_LIST", "data": {"offset":app.current.page, "filter": 0 , "search": "-", "tag": a.getAttribute("data-album")}}, parseAlbum3, a);
    sendAPI({"cmd": "MPD_API_DATABASE_TAG_ALBUM_TITLE_LIST", "data": { "album": a.getAttribute("data-album"), "search": a.getAttribute("data-album"), "tag": "Album", "id": 0}}, parseAlbum3,a);
}

function clickTitle() {
    var src = domCache.currentTitle.getAttribute('data-src');
    if (src == 'local') {
	var uri = decodeURI(domCache.currentTitle.getAttribute('data-uri'));
	if (uri != '')
    	    songDetails(uri);
    }
}

function gotoBrowse(x) {
//    console.log('---gotoBrowse---');

    var tag = x.parentNode.getAttribute('data-tag');
    var name = decodeURI(x.parentNode.getAttribute('data-name'));
    if (tag != '' && name != '' && name != '-' && settings.browsetags.includes(tag)) 
        appGoto('Browse', 'Database', tag, '0/-/' + name);
}

function songDetails(uri) {
//    console.log('-----SongDetails-----');
    sendAPI({"cmd": "MPD_API_DATABASE_SONGDETAILS", "data": {"uri": uri}}, parseSongDetails);
    modalSongDetails.show();
}

function parseSongDetails(obj) {
//    console.log('-----parseSongDetails-----');
    var modal = document.getElementById('modalSongDetails');
//    modal.getElementsByClassName('album-cover')[0].style.backgroundImage = 'url("' + obj.data.cover + '")';
//    modal.getElementsByClassName('footer-cover')[0].style.backgroundImage = 'url("' + obj.data.cover + '")';
    modal.getElementsByTagName('h3')[0].innerText = obj.data.Title;
    
    var songDetails = '';
    for (var i = 0; i < settings.tags.length; i++) {
        songDetails += '<tr><th>' + settings.tags[i] + '</th><td data-tag="' + settings.tags[i] + '" data-name="' + encodeURI(obj.data[settings.tags[i]]) + '">';
        if (settings.browsetags.includes(settings.tags[i]))
            songDetails += '<a class="text-success" href="#">' + obj.data[settings.tags[i]] + '</a>';
        else
            songDetails += obj.data[settings.tags[i]];
        songDetails += '</td></tr>';
    }
    var duration = obj.data.Duration;
    var minutes = Math.floor(duration / 60);
    var seconds = duration - minutes * 60;
    duration = minutes + ':' + (seconds < 10 ? '0' : '') + seconds;        
    songDetails += '<tr><th>Time</th><td>' + duration + '</td></tr>';
    if (settings.featLibrary)
        songDetails += '<tr><th>Filename</th><td><a class="text-success" href="/library/' + encodeURI(obj.data.uri) + '">' + obj.data.uri + '</a></td></tr>';
    else
        songDetails += '<tr><th>Filename</th><td>' + obj.data.uri + '</td></tr>';

/*    if (settings.featStickers == true) {
        songDetails += '<tr><th colspan="2">Statistics</th></tr>' +
            '<tr><th>Play count</th><td>' + obj.data.playCount + '</td></tr>' +
            '<tr><th>Skip count</th><td>' + obj.data.skipCount + '</td></tr>' +
            '<tr><th>Last played</th><td>' + (obj.data.lastPlayed == 0 ? 'never' : new Date(obj.data.lastPlayed * 1000).toUTCString()) + '</td></tr>' +
            '<tr><th>Like</th><td>' +
              '<div class="btn-group btn-group-sm">' +
                '<button title="Dislike song" id="btnVoteDown2" data-href=\'{"cmd": "voteSong", "options": [0]}\' class="btn btn-sm btn-light material-icons">thumb_down</button>' +
                '<button title="Like song" id="btnVoteUp2" data-href=\'{"cmd": "voteSong", "options": [2]}\' class="btn btn-sm btn-light material-icons">thumb_up</button>' +
              '</div>' +
            '</td></tr>';
    }*/

    modal.getElementsByTagName('tbody')[0].innerHTML = songDetails;
//    setVoteSongBtns(obj.data.like, obj.data.uri);
}

//function execSyscmd(cmd) {
//    sendAPI({"cmd": "MPD_API_SYSCMD", "data": {"cmd": cmd}});
//}

function playlistDetails(uri) {
    document.getElementById('BrowsePlaylistsAllList').classList.add('opacity05');
    appGoto('Browse', 'Playlists', 'Detail', '0/-/' + uri);
}

function removeFromPlaylist(uri, pos) {
    pos--;
    sendAPI({"cmd": "MPD_API_PLAYLIST_RM_TRACK", "data": {"uri": uri, "track": pos}});
    document.getElementById('BrowsePlaylistsDetailList').classList.add('opacity05');    
}

function playlistClear() {
    var uri = document.getElementById('BrowsePlaylistsDetailList').getAttribute('data-uri');
    sendAPI({"cmd": "MPD_API_PLAYLIST_CLEAR_AND_LIST", "data": {"uri": uri}});
    document.getElementById('BrowsePlaylistsDetailList').classList.add('opacity05');    
}

function getAllPlaylists(obj) {
    var nrItems = obj.data.length;
    var playlists = '';
    if (obj.offset == 0) {
        if (playlistEl == 'addToPlaylistPlaylist')
            playlists = '<option></option><option>New Playlist</option>';
//        else if (playlistEl == 'selectJukeboxPlaylist')
//            playlists = '<option>Database</option>';
    }
    for (var i = 0; i < nrItems; i++) {
        playlists += '<option';
//        if (playlistEl == 'selectJukeboxPlaylist' && obj.data[i].uri == settings.jukeboxPlaylist)
//            playlists += ' selected';
        playlists += '>' + obj.data[i].uri + '</option>';
    }
    if (obj.offset == 0)
        document.getElementById(playlistEl).innerHTML = playlists;
    else
        document.getElementById(playlistEl).innerHTML += playlists;
    if (obj.totalEntities > obj.returnedEntities) {
        obj.offset += settings.maxElementsPerPage;
        sendAPI({"cmd": "MPD_API_PLAYLIST_LIST", "data": {"offset": obj.offset, "filter": "-"}}, getAllPlaylists);
    }
}
/*
function voteSong(vote) {
    var uri = domCache.currentTitle.getAttribute('data-uri');
    if (uri == '')
        return;
        
    if (vote == 2 && domCache.btnVoteUp.classList.contains('active-fg-green'))
        vote = 1;
    else if (vote == 0 && domCache.btnVoteDown.classList.contains('active-fg-red'))
        vote = 1;
    sendAPI({"cmd": "MPD_API_LIKE", "data": {"uri": uri, "like": vote}});
    setVoteSongBtns(vote, uri);
}

function setVoteSongBtns(vote, uri) {
    domCache.btnVoteUp2 = document.getElementById('btnVoteUp2');
    domCache.btnVoteDown2 = document.getElementById('btnVoteDown2');
    
    if (uri == '' || uri.indexOf('http://') == 0 || uri.indexOf('https://') == 0) {
        domCache.btnVoteUp.setAttribute('disabled', 'disabled');
        domCache.btnVoteDown.setAttribute('disabled', 'disabled');
        if (domCache.btnVoteUp2) {
            domCache.btnVoteUp2.setAttribute('disabled', 'disabled');
            domCache.btnVoteDown2.setAttribute('disabled', 'disabled');
        }
    } else {
        domCache.btnVoteUp.removeAttribute('disabled');
        domCache.btnVoteDown.removeAttribute('disabled');
        if (domCache.btnVoteUp2) {
            domCache.btnVoteUp2.removeAttribute('disabled');
            domCache.btnVoteDown2.removeAttribute('disabled');
        }
    }
    
    if (vote == 0) {
        domCache.btnVoteUp.classList.remove('active-fg-green');
        domCache.btnVoteDown.classList.add('active-fg-red');
        if (domCache.btnVoteUp2) {
            domCache.btnVoteUp2.classList.remove('active-fg-green');
            domCache.btnVoteDown2.classList.add('active-fg-red');
        }
    } else if (vote == 1) {
        domCache.btnVoteUp.classList.remove('active-fg-green');
        domCache.btnVoteDown.classList.remove('active-fg-red');
        if (domCache.btnVoteUp2) {
            domCache.btnVoteUp2.classList.remove('active-fg-green');
            domCache.btnVoteDown2.classList.remove('active-fg-red');
        }
    } else if (vote == 2) {
        domCache.btnVoteUp.classList.add('active-fg-green');
        domCache.btnVoteDown.classList.remove('active-fg-red');
        if (domCache.btnVoteUp2) {
            domCache.btnVoteUp2.classList.add('active-fg-green');
            domCache.btnVoteDown2.classList.remove('active-fg-red');
        }
    }
}*/

function toggleAddToPlaylistFrm() {
    var btn = document.getElementById('toggleAddToPlaylistBtn');
    toggleBtn('toggleAddToPlaylistBtn');
    if (btn.classList.contains('active')) {
        document.getElementById('addToPlaylistFrm').classList.remove('hide');
        document.getElementById('addStreamFooter').classList.add('hide');
        document.getElementById('addToPlaylistFooter').classList.remove('hide');
    }    
    else {
        document.getElementById('addToPlaylistFrm').classList.add('hide');
        document.getElementById('addStreamFooter').classList.remove('hide');
        document.getElementById('addToPlaylistFooter').classList.add('hide');
    }
}


function chkInt(el, frm) {
    var value = el.value.replace(/\d/g,'');
    if (value != '') {
        el.classList.add('is-invalid');
        frm.classList.add('was-validated');
        return false;
    } else {
        el.classList.remove('is-invalid');
        return true;
    }
}


function showAddToPlaylist(uri) {
    document.getElementById('addToPlaylistUri').value = uri;
    document.getElementById('addToPlaylistPlaylist').innerHTML = '';
    document.getElementById('addToPlaylistNewPlaylist').value = '';
    document.getElementById('addToPlaylistNewPlaylistDiv').classList.add('hide');
    document.getElementById('addToPlaylistFrm').classList.remove('was-validated');
    document.getElementById('addToPlaylistNewPlaylist').classList.remove('is-invalid');
    toggleBtn('toggleAddToPlaylistBtn',0);
    var streamUrl = document.getElementById('streamUrl');
    streamUrl.focus();
    streamUrl.value = '';
    streamUrl.classList.remove('is-invalid');
    document.getElementById('addStreamFrm').classList.remove('was-validated');
    if (uri != 'stream') {
        document.getElementById('addStreamFooter').classList.add('hide');
        document.getElementById('addStreamFrm').classList.add('hide');
        document.getElementById('addToPlaylistFooter').classList.remove('hide');
        document.getElementById('addToPlaylistFrm').classList.remove('hide');
        document.getElementById('addToPlaylistLabel').innerText = 'Add to playlist';
    } else {
        document.getElementById('addStreamFooter').classList.remove('hide');
        document.getElementById('addStreamFrm').classList.remove('hide');
        document.getElementById('addToPlaylistFooter').classList.add('hide');
        document.getElementById('addToPlaylistFrm').classList.add('hide');
        document.getElementById('addToPlaylistLabel').innerText = 'Add Stream';
    }
    modalAddToPlaylist.show();
    if (settings.featPlaylists) {
       playlistEl = 'addToPlaylistPlaylist';
       sendAPI({"cmd": "MPD_API_PLAYLIST_LIST","data": {"offset": 0, "filter": "-"}}, getAllPlaylists);
    }
}

function addToPlaylist() {
//    console.log('addToPlaylist--------');
    var uri = document.getElementById('addToPlaylistUri').value;
    if (uri == 'stream') {
        uri = document.getElementById('streamUrl').value;
        if (uri == '' || uri.indexOf('http') == -1) {
            document.getElementById('streamUrl').classList.add('is-invalid');
            document.getElementById('addStreamFrm').classList.add('was-validated');
            return;
        }
    }
    var plistEl = document.getElementById('addToPlaylistPlaylist');
    var plist = plistEl.options[plistEl.selectedIndex].text;
    if (plist == 'New Playlist') {
        var newPl = document.getElementById('addToPlaylistNewPlaylist').value;
        var valid = newPl.replace(/[\w\-]/g, '');
        if (newPl != '' && valid == '') {
            plist = newPl;
        } else {
            document.getElementById('addToPlaylistNewPlaylist').classList.add('is-invalid');
            document.getElementById('addToPlaylistFrm').classList.add('was-validated');
            return;
        }
    }
    if (plist != '') {
        if (uri == 'SEARCH')
            addAllFromSearchPlist(plist);
        else if (uri == 'DATABASE')
            addAllFromBrowseDatabasePlist(plist);
        else
            sendAPI({"cmd": "MPD_API_PLAYLIST_ADD_TRACK", "data": {"uri": uri, "plist": plist}});
        modalAddToPlaylist.hide();
    }
    else {
        document.getElementById('addToPlaylistPlaylist').classList.add('is-invalid');
        document.getElementById('addToPlaylistFrm').classList.add('was-validated');
    }
}

function addStream() {
    var streamUrl = document.getElementById('streamUrl').value;
    if (streamUrl != '' && streamUrl.indexOf('http') == 0) {
        sendAPI({"cmd": "MPD_API_QUEUE_ADD_TRACK", "data": {"uri": streamUrl}});
        modalAddToPlaylist.hide();
        showNotification('Added stream ' + streamUrl + 'to queue', '', '', 'success');
    }
    else {
        document.getElementById('streamUrl').classList.add('is-invalid');
        document.getElementById('addStreamFrm').classList.add('was-validated');
    }
}

function showRenamePlaylist(from) {
    document.getElementById('renamePlaylistFrm').classList.remove('was-validated');
    document.getElementById('renamePlaylistTo').classList.remove('is-invalid');
    modalRenamePlaylist.show();
    document.getElementById('renamePlaylistFrom').value = from;
    document.getElementById('renamePlaylistTo').value = '';
}

function renamePlaylist() {
    var from = document.getElementById('renamePlaylistFrom').value;
    var to = document.getElementById('renamePlaylistTo').value;
    var valid = to.replace(/[\w\-]/g, '');
    if (to != '' && to != from && valid == '') {
        sendAPI({"cmd": "MPD_API_PLAYLIST_RENAME", "data": {"from": from, "to": to}});
        modalRenamePlaylist.hide();
    }
    else {
        document.getElementById('renamePlaylistTo').classList.add('is-invalid');
        document.getElementById('renamePlaylistFrm').classList.add('was-validated');
    }
}


function dirname(uri) {
    return uri.replace(/\/[^\/]*$/, '');
}

function b64EncodeUnicode(str) {
    return btoa(encodeURIComponent(str).replace(/%([0-9A-F]{2})/g,
        function toSolidBytes(match, p1) {
            return String.fromCharCode('0x' + p1);
    }));
}

function b64DecodeUnicode(str) {
    return decodeURIComponent(atob(str).split('').map(function(c) {
        return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
    }).join(''));
}

function addMenuItem(href, text, ico) {
    return '<a class="dropdown-item" href="#" data-href=\'' + b64EncodeUnicode(JSON.stringify(href)) + '\'>'+ (ico ? '<i class="material-icons">'+ico+'</i>':'') + text +'</a>';
}

function addMenuItem2(href, text) {
//    return '<a class="dropdown-item" href="#" data-href=\'' + href + '\'>' + text +'</a>';
    return '<a class="dropdown-item" href="#" onclick="' + href + '">' + text +'</a>';
}

function hideMenu() {
    var menuEl = document.querySelector('[data-popover]');
    if (menuEl) {
        new Popover(menuEl, {});
        menuEl.Popover.hide();
        menuEl.removeAttribute('data-popover');
//        menuEl.removeAttribute('data-init');
    }
}
function jp_hide() {
    var contMenu = document.getElementById('contextMenu');
    contMenu.classList.remove('mshow');
}

function getSupportedPropertyName(properties) {
    for (var i = 0; i < properties.length; i++) {
        if (typeof document.body.style[properties[i]] != "undefined") {
            return properties[i];
        }
    }
    return null;
}

function modalNow(a){
    var el = document.getElementById('modalNow');
    var transform = ["transform", "msTransform", "webkitTransform", "mozTransform", "oTransform"];
//var item = document.querySelector("#theItem");
    var transformProperty = getSupportedPropertyName(transform);
    if (a == 'show') {
	var ul = document.getElementById('QueueCurrentList');
	var c = ul.getElementsByTagName('li').length;
        if (c == 0 ) getQueue();
        if (transformProperty)
    	    el.style[transformProperty] = 'translate3d(0,0,0)';
//	el.style.marginTop = '0';
    }
    else
        if (transformProperty)
	    el.style[transformProperty] = 'translate3d(0,100vh,0)';
//	el.style.marginTop = '100vh';
}

function showbotMenu(event) {
var fav, favtit, icon , menu = '';
    var contMenu = document.getElementById('contextMenu');
    var contBody = document.getElementById('contextBody');
    contBody.innerHTML = '';
    var el = document.getElementById('footerCover'); //tr
    var img = el.style.backgroundImage;
    img = img.replace('url("','');
    img = img.replace('")','');
    var type = 'track';
    var src = domCache.currentTitle.getAttribute('data-src');
    if (src == 'tidal' || src == 'qobuz') {
	if (src == 'tidal') var ap = 'Tidal';
	if (src == 'qobuz') var ap = 'Qobuz';
	var id = domCache.currentTitle.getAttribute('data-id');
	var title = domCache.currentTitle.innerHTML;
	var artid = document.getElementById("currentArtist").getAttribute('data-artid');
	var albid = document.getElementById("currentAlbum").getAttribute('data-albid');
	if (albid == 0) type = 'video';
	fav = false;
	if (ap == 'Tidal') fav = checkTFav(type,id);
	if (ap == 'Qobuz') fav = checkQFav(type,id);

	if (fav) {
	    favtit = 'Remove from My';
	    icon = 'remove';
	} else {
	    favtit = 'Add to My Collection';
	    icon = 'favorite_border';
	}
		
        menu += '<a class="dropdown-item" href="#" onclick=\'' + ap + '("'+(fav ? 'fav':'favrem')+'","'+type+'","'+ id+'",event); return false;\'><i class="material-icons">'+icon+'</i>'+favtit+'</a>';
        if (type != 'video') menu += '<a class="dropdown-item" href="#" onclick=\'jp_hide();appGoto("' + ap + '","page","album__'+ albid+'"); return false;\'><i class="material-icons">album</i>Go to Album</a>';
    	menu += '<a class="dropdown-item" href="#" onclick=\'jp_hide();appGoto("' + ap + '","page","artist__'+ artid+'"); return false;\'><i class="material-icons">person</i>Go to Artist</a>';
    } else menu ='';
//	    if (!phone) 
    contMenu.style.left = (event.pageX - 20)+ 'px';
//    contMenu.style.top = (event.pageY - 130)+'px';
    contMenu.style.bottom = '60px';
    contBody.innerHTML = menu;
    contMenu.classList.add('mshow');
    event.preventDefault();
    event.stopPropagation();
}

function showMenu2(elem, event) {
    var contMenu = document.getElementById('contextMenu');
    var w = (phone ? 160 : 50);
    var contBody = document.getElementById('contextBody');
    contMenu.style.bottom = 'unset';
    contBody.innerHTML = '';
    if (!phone) {
      if (event.pageX + 200 > window.innerWidth)
	contMenu.style.left = (event.pageX - 200) + 'px'
      else 
      	contMenu.style.left = event.pageX + 'px';

      if (event.pageY +250 > window.innerHeight)
        contMenu.style.top = (event.pageY-200)+'px';
      else
        contMenu.style.top = event.pageY+'px';
    } else {
	contMenu.style.bottom = 0;
	contMenu.style.left = 0;
    }
    contMenu.classList.add('mshow');
    
    event.preventDefault();
    event.stopPropagation();
    var menu = '';
    if (app.current.app == 'Browse' ) {
      if (app.current.tab == 'Filesystem'|| app.current.tab == 'Database'||app.current.tab == 'Last' || app.current.tab == 'Search') {
	var nextsongpos = 0;
	if (lastState)
    	    nextsongpos = lastState.data.nextSongPos;

	var el = elem.parentNode.parentNode.parentNode;
	var img = el.getElementsByTagName('img');
	var title = el.parentNode.getElementsByClassName('item-title');
	var type = el.getAttribute('data-type');
	var id   = el.getAttribute('data-id');
	var name = el.getAttribute('data-name');
	var uri = decodeURI(el.getAttribute('data-uri'));
	
	menu += '<img class="context-img" src="'+img[0].src+'" width="'+w+'px" height="'+w+'px"><div class="context-title">'+title[0].getAttribute("data-album")+'</div><hr style="margin-bottom:0;">'
        menu += addMenuItem('{"cmd": "appendQueue", "options": ["'+type+'","'+ uri+'","'+ name+'"]}', 'Add to queue','playlist_add') +
            (type == 'song' ? addMenuItem('{"cmd": "appendAfterQueue", "options": ["'+type+'","'+ uri+'",'+ nextsongpos+',"'+ name+'"]}', 'Play Next','subdirectory_arrow_right') : '') +
            addMenuItem('{"cmd": "replaceQueue", "options": ["'+type+'","'+ uri+'","' +name+'"]}', 'Play','play_arrow') +
            (type != 'plist' && type != 'smartpls' && settings.featPlaylists ? addMenuItem('{"cmd": "showAddToPlaylist", "options": ["'+uri+'"]}', 'Add to playlist') : '') +
            (type == 'song' ? addMenuItem('{"cmd": "songDetails", "options": ["'+uri+'"]}', 'Songdetails','info') : '') +
            (type == 'plist' || type == 'smartpls' ? addMenuItem('{"cmd": "playlistDetails", "options": ["'+uri+'"]}', 'View playlist') : '');

	contBody.innerHTML = menu;
	alert(1);
      }
    }
    else if (app.current.app == 'Tidal' || app.current.app == 'Qobuz') {
      var ap = app.current.app;
      var mytab = app.current.tab;
      var view = app.current.view;
      if (view == 'myalbums' || view == 'myplists' || view == 'myartists') {
        if (!phone) {
	    var el = elem.parentNode.parentNode.parentNode; // a href=
	} else {
	    var el1 = elem.parentNode.parentNode.parentNode; //card
	    var el = el1.getElementsByTagName('a')[0]; // a href
	}
	var cardId = el.parentNode.parentNode.id;  //card-item

	var img = el.getElementsByTagName('img');
	var tit  = el.parentNode.getElementsByClassName((view == 'myalbums' ? 'item-title1':'item-title'));
	var type = el.getAttribute('data-type');
	var id = el.getAttribute('data-id');
	
	var div1 = document.createElement('div');
	div1.innerHTML = '<img class="context-img" src="'+img[0].src+'" width="'+w+'px" height="'+w+'px" onclick="jp_hide();"><div class="context-title">' + tit[0].getAttribute("title") + '</div><hr style="margin-bottom:0;">';
	contBody.appendChild(div1);
	
	var div1 = document.createElement('div');
	if (view == 'myartists') {
            menu = '<a class="dropdown-item" href="#" onclick=\'' + ap + '("play","'+type+'","'+ id+'",event); return false;\'><i class="material-icons">play_arrow</i>Play Artist radio</a>' +
    		'<a class="dropdown-item" href="#" onclick=\'' + ap + '("favrem","'+type+'","'+ id+'",event,"'+cardId+'"); return false;\'><i class="material-icons">clear</i>Remove from My</a>';
	} else {
    	    menu = '<a class="dropdown-item" href="#" onclick=\'' + ap + '("add","'+type+'","'+ id+'",event); return false;\'><i class="material-icons">playlist_add</i>Add to queue</a>' +
    		'<a class="dropdown-item" href="#" onclick=\'' + ap + '("insert","'+type+'","'+ id+'",event); return false;\'><i class="material-icons">subdirectory_arrow_right</i>Play next</a>' +
        	'<a class="dropdown-item" href="#" onclick=\'' + ap + '("play","'+type+'","'+ id+'",event); return false;\'><i class="material-icons">play_arrow</i>Play</a>' +
        	'<a class="dropdown-item" href="#" onclick=\'' + ap + '("favrem","'+type+'","'+ id+'",event,"'+cardId+'"); return false;\'><i class="material-icons">clear</i>Remove from My</a>';
        }
	div1.innerHTML = menu;
	contBody.appendChild(div1);
      }
      else if (view == 'mytracks') {
	var el = elem.parentNode; // tr
	var cardId = el.id; 
	
	var img = el.getElementsByTagName('img');
	var tit = el.getAttribute('data-title');
	var id  = el.getAttribute('data-id');

	var div1 = document.createElement('div');
	div1.innerHTML = '<img class="context-img" src="'+img[0].src+'" width="'+w+'px" height="'+w+'px" onclick="jp_hide();"><div class="context-title">' + tit + '</div>';
	contBody.appendChild(div1);

	var div1 = document.createElement('div');
	menu += '<a class="dropdown-item" href="#" onclick=\'' + ap + '("add","track","'+ id+'", event); return false;\'><i class="material-icons">playlist_add</i>Add to queue</a>' +
    		'<a class="dropdown-item" href="#" onclick=\'' + ap + '("insert","track","'+ id+'", event); return false;\'><i class="material-icons">subdirectory_arrow_right</i>Play next</a>' +
        	'<a class="dropdown-item" href="#" onclick=\'' + ap + '("play","track","'+ id+'",event); return false;\'><i class="material-icons">play_arrow</i>Play</a>' +
        	'<a class="dropdown-item" href="#" onclick=\'' + ap + '("favrem","track","'+ id+'",event,"' + cardId + '"); return false;\'><i class="material-icons">clear</i>Remove from My</a>';
	div1.innerHTML = menu;
	contBody.appendChild(div1);
	
      }
      else { // all other section
    	var el = elem.parentNode; // track
    	if (el.getAttribute('data-id') == null) {
    	    if (!phone)
		var el = elem.parentNode.parentNode.parentNode
	    else {
		var el1 = elem.parentNode.parentNode.parentNode; //card
		var el = el1.getElementsByTagName('a')[0]; // a href
	    }
	}
	var type = el.getAttribute('data-type');
	var title = el.getAttribute('data-title')
	if (!title)
	    var title = el.parentNode.getElementsByClassName('item-title')[0].getAttribute("title");

	var id = el.getAttribute('data-id');

	var img = el.getElementsByTagName('img');
	if (img.length == 0) {
	    el = el.parentNode.parentNode;
	    img = el.getElementsByTagName('img');
	    img = img[0].src;
	} else
	    img = img[0].src;

	var fav = false;
	if (ap == 'Tidal') fav = checkTFav(type,id);
	if (ap == 'Qobuz') fav = checkQFav(type,id);

	if (fav) {
	    var favtit = 'Remove from My';
	    var icon = 'remove';
	} else {
	    var favtit = 'Add to My Collection';
	    var icon = 'favorite_border';
	}
	var div1 = document.createElement('div');
	div1.innerHTML = '<img class="context-img" src="' + img + '" width="'+w+'px" height="'+w+'px" onclick="jp_hide();"><div class="context-title">'+title+'</div>';
	contBody.appendChild(div1);

	var div1 = document.createElement('div');
	
    	menu += '<a class="dropdown-item" href="#" onclick=\'' + ap + '("add","'+type + '","' + id + '", event); return false;\'><i class="material-icons">playlist_add</i>Add to queue</a>' +
    	    '<a class="dropdown-item" href="#" onclick=\'' + ap + '("insert","'+type + '","' + id + '", event); return false;\'><i class="material-icons">subdirectory_arrow_right</i>Play next</a>' +
            '<a class="dropdown-item" href="#" onclick=\'' + ap + '("play","'+type + '","'+ id + '",event); return false;\'><i class="material-icons">play_arrow</i>Play</a>' +
            (ap == 'Tidal' ? '':'<a class="dropdown-item" href="#" onclick=\'' + ap + '("playtidal","' + type + '","' + id + '",event); return false;\'><i class="material-icons">local_taxi</i>Play from Tidal</a>')+
            '<a class="dropdown-item" href="#" onclick=\'' + ap + 'fav("'+type + '","'+ id + '",event,this); return false;\'><i class="material-icons">'+icon+'</i>'+favtit+'</a>';
	div1.innerHTML = menu;
	contBody.appendChild(div1);
      }
    }

}

function showMenu(el, event) {
//    console.log('---Showmenu---');
    event.preventDefault();
    event.stopPropagation();
    hideMenu();
    if (el.getAttribute('data-init'))
        return;

    var type = el.getAttribute('data-type');
    var uri = decodeURI(el.getAttribute('data-uri'));
    var name = el.getAttribute('data-name');
    var nextsongpos = 0;
    if (type == null || uri == null) {
        type = el.parentNode.parentNode.getAttribute('data-type');
        uri = decodeURI(el.parentNode.parentNode.getAttribute('data-uri'));
        name = el.parentNode.parentNode.getAttribute('data-name');
    }

    if (lastState)
        nextsongpos = lastState.data.nextSongPos;

    var menu = '';
    if (app.current.app == 'Browse' && (app.current.tab == 'Filesystem' || app.current.tab == 'Search' ||
         app.current.tab == 'Database')) {
        menu += addMenuItem({"cmd": "appendQueue", "options": [type, uri, name]}, 'Add to queue','playlist_add') +
            (type == 'song' ? addMenuItem({"cmd": "appendAfterQueue", "options": [type, uri, nextsongpos, name]}, 'Play next','subdirectory_arrow_right') : '') +
            addMenuItem({"cmd": "replaceQueue", "options": [type, uri, name]}, 'Play','play_arrow') +
            (type != 'plist' && type != 'smartpls' && settings.featPlaylists ? addMenuItem({"cmd": "showAddToPlaylist", "options": [uri]}, 'Add to playlist','add') : '') +
            (type == 'song' ? addMenuItem({"cmd": "songDetails", "options": [uri]}, 'Song details','info') : '') +
            (type == 'dir' ? addMenuItem({"cmd": "updateDB", "options": [uri]}, 'Update Folder','autorenew') : '') +
            (type == 'plist' || type == 'smartpls' ? addMenuItem({"cmd": "playlistDetails", "options": [uri]}, 'View playlist','queue_music') : '');

        if (app.current.tab == 'Search') {
            var baseuri = dirname(uri);
            menu += '<div class="dropdown-divider"></div>' +
                '<a class="dropdown-item" id="advancedMenuLink" data-toggle="collapse" href="#advancedMenu"><span class="material-icons material-icons-small-left">keyboard_arrow_right</span>Album actions</a>' +
                '<div class="collapse" id="advancedMenu">' +
                    addMenuItem({"cmd": "appendQueue", "options": [type, baseuri, name]}, 'Add to queue','playlist_add') +
                    addMenuItem({"cmd": "appendAfterQueue", "options": [type, baseuri, nextsongpos, name]}, 'Play next','subdirectory_arrow_right') +
                    addMenuItem({"cmd": "replaceQueue", "options": [type, baseuri, name]}, 'Play','play_arrow') +
                    (settings.featPlaylists ? addMenuItem({"cmd": "showAddToPlaylist", "options": [baseuri]}, 'Add to playlist','add') : '') +
               '</div>';
        }

    }
    if (app.current.app == 'Browse' && app.current.tab == 'Playlists' && app.current.view == 'All') {
        menu += addMenuItem({"cmd": "appendQueue", "options": [type, uri, name]}, 'Add to queue','playlist_add') +
            addMenuItem({"cmd": "replaceQueue", "options": [type, uri, name]},'Play','play_arrow') +
            (type == 'smartpls' ? addMenuItem({"cmd": "playlistDetails", "options": [uri]}, 'View playlist','queue_music') : addMenuItem({"cmd": "playlistDetails", "options": [uri]}, 'Edit playlist'))+
            (type == 'smartpls' ? addMenuItem({"cmd": "showSmartPlaylist", "options": [uri]}, 'Edit smart playlist') : '') +
            (uri.indexOf('myMPDsmart') != 0 ?
                addMenuItem({"cmd": "showRenamePlaylist", "options": [uri]}, 'Rename playlist') + 
                addMenuItem({"cmd": "showDelPlaylist", "options": [uri]}, 'Delete playlist') : '');
    }
    else if (app.current.app == 'Browse' && app.current.tab == 'Playlists' && app.current.view == 'Detail') {
        var x = document.getElementById('BrowsePlaylistsDetailList');
        menu += addMenuItem({"cmd": "appendQueue", "options": [type, uri, name]}, 'Add to queue','playlist_add') +
            addMenuItem({"cmd": "replaceQueue", "options": [type, uri, name]}, 'Play','play_arrow') +
            (x.getAttribute('data-ro') == 'false' ? addMenuItem({"cmd": "removeFromPlaylist", "options": [x.getAttribute('data-uri'), 
                    el.parentNode.parentNode.getAttribute('data-songpos')]}, 'Remove','clear') : '') +
            addMenuItem({"cmd": "showAddToPlaylist", "options": [uri]}, 'Add to playlist','add') +
            (uri.indexOf('http') == -1 ? addMenuItem({"cmd": "songDetails", "options": [uri]}, 'Songdetails') : '');
    }
    if (type == "qitem") {
/*    else if (app.current.app == 'Queue' && app.current.tab == 'Current') {*/
        menu += addMenuItem({"cmd": "delQueueSong", "options": ["single", el.parentNode.parentNode.getAttribute('data-trackid')]}, 'Remove') +
            addMenuItem({"cmd": "delQueueSong", "options": ["range", 0, el.parentNode.parentNode.getAttribute('data-songpos')]}, 'Remove all upwards') +
            addMenuItem({"cmd": "delQueueSong", "options": ["range", (parseInt(el.parentNode.parentNode.getAttribute('data-songpos'))-1), -1]}, 'Remove all downwards') +
            (uri.indexOf('http') == -1 ? addMenuItem({"cmd": "songDetails", "options": [uri]}, 'Songdetails') : '');
    }
/*    else if (app.current.app == 'Queue' && app.current.tab == 'LastPlayed') {
        menu += addMenuItem({"cmd": "appendQueue", "options": [type, uri, name]}, 'Add to queue') +
            addMenuItem({"cmd": "replaceQueue", "options": [type, uri, name]}, 'Replace queue') +
            addMenuItem({"cmd": "showAddToPlaylist", "options": [uri]}, 'Add to playlist') +
            (uri.indexOf('http') == -1 ? addMenuItem({"cmd": "songDetails", "options": [uri]}, 'Songdetails') : '');
    }*/
    //mytracks
    //myplists
    //myartists
    new Popover(el, { trigger: 'click', delay: 0, dismissible: true, template: '<div class="popover" role="tooltip">' +
        '<div class="arrow"></div>' +
        '<div class="popover-content">' + menu + '</div>' +
        '</div>'});
    var popoverInit = el.Popover;
    el.setAttribute('data-init', 'true');
    el.addEventListener('shown.bs.popover', function(event) {
        event.target.setAttribute('data-popover', 'true');
        document.getElementsByClassName('popover-content')[0].addEventListener('click', function(event) {
            event.preventDefault();
            event.stopPropagation();
            if (event.target.nodeName == 'A') {
                var dh = event.target.getAttribute('data-href');
                if (dh) {
                    var cmd = JSON.parse(b64DecodeUnicode(dh));
		    parseCmd(event, cmd);
                    hideMenu();
                }
            }
        }, false);        
        var collapseLink = document.getElementById('advancedMenuLink');
        if (collapseLink) {
            collapseLink.addEventListener('click', function(event) {
            var icon = this.getElementsByTagName('span')[0];
            if (icon.innerText == 'keyboard_arrow_right')
                icon.innerText = 'keyboard_arrow_down';
            else
                icon.innerText = 'keyboard_arrow_right';
        }, false);
//            var myCollapseInit = new Collapse(collapseLink);
            new Collapse(collapseLink);
        }
        document.getElementsByClassName('popover-content')[0].firstChild.focus();
    }, false);
    popoverInit.show();
}

function sendAPI(request, callback, param) {
    console.log('-----sendAPI-----');
    console.log(request);
    var ajaxRequest = new XMLHttpRequest();
    ajaxRequest.open('POST', '/api', true);
    ajaxRequest.setRequestHeader('Content-type', 'application/json');
    ajaxRequest.onreadystatechange = function() {
        if (ajaxRequest.readyState == 4) {
            if (ajaxRequest.responseText != '') {
//       		console.log(request.cmd);
		var obj = JSON.parse(ajaxRequest.responseText);

                if (obj.type == 'error') {
                    showNotification('Error', obj.data, obj.data, 'danger');
                    console.log('Error: ' + obj.data);
                }
                else if (obj.type == 'result' && obj.data != 'ok')
                    showNotification(obj.data, '', '', 'success');
                else if (callback != undefined && typeof(callback) == 'function') {
            	    if (param != undefined) {
                	callback(obj,request,param);
            	    } else
                	callback(obj,request);
                }
            }
            else {
                console.log('Empty response for request: ' + JSON.stringify(request));
            }
        }
    };
    ajaxRequest.send(JSON.stringify(request));
}

function sendAPI2(request, callback) {
    var ajaxRequest = new XMLHttpRequest();
    ajaxRequest.open('POST', '/api', true);
    ajaxRequest.setRequestHeader('Content-type', 'application/json');
    ajaxRequest.onreadystatechange = function() {
        if (ajaxRequest.readyState == 4) {
            if (ajaxRequest.responseText != '') {
                var obj = JSON.parse(ajaxRequest.responseText);
		console.log('sendapi22>>>>>>>>>>>'+obj.state);
                if (obj.state == 'start' || obj.state == 'running') {
            	    var el = document.getElementById('updateCacheprogress');
            	    var proc = parseInt(100/obj.count_albums * obj.current);
            	    el.setAttribute('aria-valuenow',proc);
            	    el.style.width = proc +'%';
            	    document.getElementById('ucur').innerHTML = obj.current;
            	    document.getElementById('ucmax').innerHTML = obj.count_albums;
		    setTimeout(function(){
			sendAPI2(request, callback);
		    },1000);
                }
                if (obj.state == 'finish') {
            	    var el = document.getElementById('updateCacheprogress');
            	    var proc = 100;
            	    el.setAttribute('aria-valuenow',proc);
            	    el.style.width = proc +'%';
            	    document.getElementById('ucur').innerHTML = obj.count_albums;
            	    document.getElementById('ucmax').innerHTML = obj.count_albums;
            	    var notf = obj.count_albums - obj.cached - obj.found_local - obj.found_embed - obj.found_inet;
            	    var str='<p>Create image cache finished.</p><h5>Summary</h5>'+
            	     'Cached up: '+obj.cached+'<br>'+
            	    'Local found : '+obj.found_local+'<br>'+
            	 'Embedded found : '+obj.found_embed+'<br>'+
            	 'Internet found : '+obj.found_inet+'<br>'+
            	 'Not found : '+notf+'<br>';
        	    document.getElementById('updateCachefinished').innerHTML = str;
                }
            }
            else {
                console.log('Empty response for request: ' + JSON.stringify(request));
            }
        }
    };
    ajaxRequest.send(JSON.stringify(request));
}


function updatecache() {
    document.getElementById('updateCachefinished').innerText = '';
    sendAPI({"cmd": "API_CACHE_UPDATE"});
    sendAPI2({"cmd": "API_CACHE_STATUS"});
    modalUpdateCache.show();
}

function updateDB(path) {
    sendAPI({"cmd": "MPD_API_DATABASE_UPDATE","path" : path});
    updateDBstarted(true);
}

function rescanDB() {
    sendAPI({"cmd": "MPD_API_DATABASE_RESCAN"});
    updateDBstarted(true);
}

function reboot() { //dimas
    sendAPI({"cmd": "MPD_API_SYSCMD","data":{"cmd":"reboot"}});
}

function poweroff() { //dimas
    sendAPI({"cmd": "MPD_API_SYSCMD","data":{"cmd":"poweroff"}});
}

function updateDBstarted(showModal) {
    if (showModal == true) {
        document.getElementById('updateDBfinished').innerText = '';
        document.getElementById('updateDBfooter').classList.add('hide');
        updateDBprogress.style.width = '20px';
        updateDBprogress.style.marginLeft = '-20px';
        modalUpdateDB.show();
        document.getElementById('updateDBprogress').classList.add('updateDBprogressAnimate');
    }
    else {
        showNotification('Database update started', '', '', 'success');
    }
}

function updateDBfinished(idleEvent) {
    if (document.getElementById('modalUpdateDB').classList.contains('show')) {
        if (idleEvent == 'update_database')
            document.getElementById('updateDBfinished').innerText = 'Database successfully updated.';
        else if (idleEvent == 'update_finished')
            document.getElementById('updateDBfinished').innerText = 'Database update finished.';
        var updateDBprogress = document.getElementById('updateDBprogress');
        updateDBprogress.classList.remove('updateDBprogressAnimate');
        updateDBprogress.style.width = '100%';
        updateDBprogress.style.marginLeft = '0px';
        document.getElementById('updateDBfooter').classList.remove('hide');
    }
    else {
        if (idleEvent == 'update_database')
            showNotification('Database successfully updated.', '', '', 'success');
        else if (idleEvent == 'update_finished')
            showNotification('Database update finished.', '', '', 'success');
    }
}

function clickPlay() {
    if (playstate != 'play')
        sendAPI({"cmd": "MPD_API_PLAYER_PLAY"});
    else
        sendAPI({"cmd": "MPD_API_PLAYER_PAUSE"});
}

function clickStop() {
    sendAPI({"cmd": "MPD_API_PLAYER_STOP"});
}

function clickPrev() {
    sendAPI({"cmd": "MPD_API_PLAYER_PREV"});
}

function clickNext() {
    sendAPI({"cmd": "MPD_API_PLAYER_NEXT"});
}



function clickExpand() {
    nowSwiper.slideTo(0,0);
    modalNow('show');
}

function clickQueue() {
    nowSwiper.slideTo(1,0);
    modalNow('show');
}

function delQueueSong(mode, start, end) {
    if (mode == 'range')
        sendAPI({"cmd": "MPD_API_QUEUE_RM_RANGE", "data": {"start": start, "end": end}});
    else if (mode == 'single')
        sendAPI({"cmd": "MPD_API_QUEUE_RM_TRACK", "data": { "track": start}});
    hideMenu();
}

function showDelPlaylist(uri) {
    document.getElementById('deletePlaylist').value = uri;
    modalDeletePlaylist.show();
}

function delPlaylist() {
    var uri = document.getElementById('deletePlaylist').value;
    sendAPI({"cmd": "MPD_API_PLAYLIST_RM", "data": {"uri": uri}});
    modalDeletePlaylist.hide();
}

/*
function confirmSettings() {
    var formOK = true;

    if (formOK == true) {
        sendAPI({"cmd": "MPD_API_SETTINGS_SET", "data": {
            "consume": (document.getElementById('btnConsume').classList.contains('active') ? 1 : 0),
            "random":  (document.getElementById('btnRandom').classList.contains('active') ? 1 : 0),
            "single":  (document.getElementById('btnSingle').classList.contains('active') ? 1 : 0),
            "repeat":  (document.getElementById('btnRepeat').classList.contains('active') ? 1 : 0),
            "notificationWeb": (document.getElementById('btnnotifyWeb').classList.contains('active') ? true : false),
            "notificationPage": (document.getElementById('btnnotifyPage').classList.contains('active') ? true : false),
        }}, getSettings);
        modalSettings.hide();
    } else
        document.getElementById('settingsFrm').classList.add('was-validated');
}*/

function addAllFromBrowseFilesystem() {
    sendAPI({"cmd": "MPD_API_QUEUE_ADD_TRACK", "data": {"uri": app.current.search}});
    showNotification('Added all songs', '', '', 'success');
}

function addAllFromSearchPlist(plist) {
    if (app.current.search.length >= 2) {
        sendAPI({"cmd": "MPD_API_DATABASE_SEARCH", "data": {"plist": plist, "filter": app.current.filter, "searchstr": app.current.search, "offset": 0}});
        showNotification('Added '+ parseInt(document.getElementById('panel-heading-search').innerText) +' songs from search to ' + plist, '', '', 'success');
    }
}

function addAllFromBrowseDatabasePlist(plist) {
    if (app.current.search.length >= 2) {
        sendAPI({"cmd": "MPD_API_DATABASE_SEARCH", "data": {"plist": plist, "filter": app.current.view, "searchstr": app.current.search, "offset": 0}});
        showNotification('Added songs from database selection to ' + plist, '', '', 'success');
    }
}

function scrollTo(pos) {
//    document.body.scrollTop = pos; // For Safari
//    document.documentElement.scrollTop = pos; // For Chrome, Firefox, IE and Opera
    domCache.maincont.scrollTop = pos;
}

function gotoPage(x) {
//    console.log('---gotoPage--'+x+'-');

    switch (x) {
        case 'next':
    	    if ((app.current.tab == 'Last')||
    		(app.current.tab == 'Database' && app.current.view == 'Genre' )|| 
    		(app.current.tab == 'Database' && app.current.view == 'Album' )) 
    	    {
        	app.current.page += settings.maxAlbumsPerPage;
    	    } else {
            app.current.page += settings.maxElementsPerPage;
    	    }
            break;
        case 'prev':
    	    if ((app.current.tab == 'Last')||
    	       (app.current.tab == 'Database' && app.current.view == 'Genre')||
    	       (app.current.tab == 'Database' && app.current.view == 'Album' )) 
    	       {
        	app.current.page -= settings.maxAlbumsPerPage;
    	    } else {
            app.current.page -= settings.maxElementsPerPage;
            }
            if (app.current.page < 0)
                app.current.page = 0;
            break;
        default:
            app.current.page = x;
    }
    appGoto(app.current.app, app.current.tab, app.current.view, app.current.page + '/' + app.current.filter + '/' + app.current.search);
}

function saveQueue() {
    var plName = document.getElementById('saveQueueName').value;
    var valid = plName.replace(/[\w\-]/g, '');
    if (plName != '' && valid == '') {
        sendAPI({"cmd": "MPD_API_QUEUE_SAVE", "data": {"plist": plName}});
        modalSavequeue.hide();
    }
    else {
        document.getElementById('saveQueueName').classList.add('is-invalid');
        document.getElementById('saveQueueFrm').classList.add('was-validated');
    }
}

function showNotification(notificationTitle,notificationText,notificationHtml,notificationType,img) {
/*    if (settings.notificationWeb == true) {
        var notification = new Notification(notificationTitle, {icon: 'assets/favicon.ico', body: notificationText});
        setTimeout(function(notification) {
            notification.close();
        }, 3000, notification);    
    } */
    if (settings.notificationPage == true) {
        var alertBox;
        if (!document.getElementById('alertBox')) {
            alertBox = document.createElement('div');
            alertBox.setAttribute('id', 'alertBox');
            alertBox.addEventListener('click', function() {
                hideNotification();
            }, false);
        }
        else {
            alertBox = document.getElementById('alertBox');
        }
        alertBox.classList.remove('alert-success', 'alert-danger', 'alert-light');
        alertBox.classList.add('alert','alert-' + notificationType);
        if (img == '' || img == undefined)
    	    alertBox.innerHTML = '<div><strong>' + notificationTitle + '</strong><br/>' + notificationHtml + '</div>'
    	else
    	    alertBox.innerHTML = '<div class="row" style="height:104px;overflow:hidden;">'+
    	    '<div style="padding:0; width:104px;">'+
    		'<img src="'+img+'" class="notifyImg">'+
    	    '</div>'+
    	    '<div class="card-body" style="color:black;padding:1rem; width:310px;">'+
    	    '<h6 class="notifyTitle">' + notificationTitle + '</h6>'+ 
    	    notificationHtml + '</div>'+
    	    '</div>';
    	        	
        document.getElementsByTagName('main')[0].appendChild(alertBox);
        document.getElementById('alertBox').classList.add('alertBoxActive');
        if (alertTimeout)
            clearTimeout(alertTimeout);
        alertTimeout = setTimeout(function() {
            hideNotification();    
        }, 3000);
    }
}

function hideNotification() {
    if (document.getElementById('alertBox')) {
        document.getElementById('alertBox').classList.remove('alertBoxActive');
        setTimeout(function() {
            var alertBox = document.getElementById('alertBox');
            if (alertBox)
                alertBox.remove();
        }, 600);
    }
}

function notificationsSupported() {
    return "Notification" in window;
}

function favSong(a,e) {
var src = domCache.currentTitle.getAttribute('data-src');
var id = domCache.currentTitle.getAttribute('data-id');
var flag = a.classList.contains('fav');
    if (src == 'tidal') {
	Tidal('fav','track',id,e);
	if (!flag) a.classList.add('fav');
    }
    if (src == 'qobuz') {
	Qobuz('fav','track',id,e);
	if (!flag) a.classList.add('fav');
    }
}

function setPlaying(a) {
//var t0=performance.now();
    if (!a) {
	var a = document.getElementById('currentTitle').getAttribute('data-id');
	if (a == null) return;
    }
    var card = document.querySelector('.card:not(.hide)');
    var elm = card.querySelector('.rpanel:not(.hide)');
//    alert(card.id+'+'+elm.id);
    if (elm) {
	var el = elm.querySelector('.track-item.isPlaying');
	if (el) el.classList.remove('isPlaying');

	var as = elm.querySelector('.track-item[data-id=\"'+a+'\"]');
	if (as) as.classList.add('isPlaying');
    }
//    var t1=performance.now();
//    console.log('setpl: '+(t1-t0));
}


function songChange(obj) {
    var footertxt = '';
    var imgurl = '';
    var cover = '';
    var header = '';
    console.log('-----songChange-----');
    console.log(obj);
    if (obj.type == 'error' || obj.type == 'result') return;
    
    var curSong = obj.data.Title + obj.data.Artist + obj.data.Album + obj.data.uri + obj.data.currentSongId;
    console.log(curSong);
    if (lastSong == curSong) 
	return;
    var textNotification = '';
    var htmlNotification = '';
//background-image playback
// inetradio icon
    var orig = false;
    if (obj.data.Name!='-' && obj.data.src != 'soundcloud') {  //Station
    	document.getElementById('currentAlbum').style.display = 'none';
    	document.getElementById('curStation').style.display = 'block';
	if (typeof obj.data.Title != 'undefined' && obj.data.Title.length > 0) {
    	    var ar = obj.data.Title.split(' - ');
    	    if (ar.length >1) {
    		textNotification = ar[1];
    		htmlNotification = ar[1]+'<br>'+ar[0];
    		var c = document.getElementById('currentArtist');
    		c.getElementsByTagName('h4')[0].innerText = ar[0];
    	    } else {
    		textNotification = ' : '+ obj.data.Title;
    		htmlNotification = obj.data.Title;
    	    }
    	}
//	var header = obj.data.Name;
	var title = obj.data.Name;
	
    	domCache.currentTitle.innerText = textNotification;
    	document.getElementById('currentStation').innerText = title;
    	
        domCache.footerTitle.innerHTML =(header ? header + '<br><span class="tart">'+htmlNotification+'</span>':'<span>'+htmlNotification+'</span>');
        domCache.currentTitle.setAttribute('data-uri', encodeURI(obj.data.uri));
        domCache.currentTitle.setAttribute('data-src', obj.data.src);
	domCache.currentTitle.setAttribute('data-duration', obj.data.Duration);
	cover = obj.data.cover;

    } else {
        domCache.currentTitle.setAttribute('data-src', obj.data.src);
    	document.getElementById('curStation').style.display = 'none';
    	document.getElementById('currentAlbum').style.display = 'block';
    	if ((obj.data.src == 'tidal' || obj.data.src == 'qobuz' || obj.data.src == 'soundcloud')&& obj.data.orig) {
    	    orig = true;
    	}
//	var header = obj.data.Title;
	var artist = (orig ? obj.data.orig.artist: obj.data.Artist);
	var album = '';
	if (orig) {
	    if (obj.data.orig.album == '') {
		album = obj.data.Album;
	    } else {
		album = obj.data.orig.album;
	    }
	} else {
	    album = obj.data.Album;
	}
//	var album = (orig ? obj.data.orig.album: obj.data.Album);
	if (artist) {
	  if (typeof artist != 'undefined' && artist.length > 0 && artist != '-') {
	    textNotification += artist;
	    htmlNotification += artist;
	  }
	}

	if (typeof album != 'undefined' && album) {
	    if (album.length > 0 && album != '-') {
    	      textNotification += ' - ' + album;
    	      htmlNotification += '<br/>' + album;
    	    }
	}
	var title = (orig ? obj.data.orig.title : obj.data.Title);
    
	if (typeof title != 'undefined' && title.length > 0) {
    	    domCache.currentTitle.innerText = title;
    	    domCache.footerTitle.innerHTML = title+'<br/><span class="tart2">'+textNotification+'</span>';
    	    domCache.currentTitle.setAttribute('data-uri', encodeURI(obj.data.uri));
    	    if (orig) {
    		domCache.currentTitle.setAttribute('data-id', obj.data.orig.id);
    		setPlaying(obj.data.orig.id);
    	    }
	} else {
    	    domCache.currentTitle.innerText = '';
    	    domCache.currentTitle.setAttribute('data-uri', '');
	}
	domCache.currentTitle.setAttribute('data-duration', obj.data.Duration);

/*	for (var i = 0; i < settings.colsPlayback.length; i++) {
    	    var c = document.getElementById('current' + settings.colsPlayback[i]);
    	    c.getElementsByTagName('h4')[0].innerText = obj.data[settings.colsPlayback[i]];
    	    c.setAttribute('data-name', encodeURI(obj.data[settings.colsPlayback[i]]));
	}*/
//	if (orig) {
    	var c = document.getElementById('currentArtist');
    	c.getElementsByTagName('h4')[0].innerText = artist;
    	c.setAttribute('data-name', encodeURI(artist));
    	if (orig) 
    	    c.setAttribute('data-artid', obj.data.orig.artid);
//    	    c.setAttribute('data-artid', encodeURI(obj.data.orig.artid));
    	var c = document.getElementById('currentAlbum');
    	c.getElementsByTagName('h4')[0].innerText = album;
    	c.setAttribute('data-name', encodeURI(album));
    	if (orig) 
    	    c.setAttribute('data-albid', obj.data.orig.albumid);
//    	    c.setAttribute('data-albid', encodeURI(obj.data.orig.albumid));
//	}
	
    } // obj.data.Name
    var tidalimage = 'https://resources.tidal.com/images/';
    cover = (orig ? obj.data.orig.cover : obj.data.cover);
    if (obj.data.src == 'youtube')
	cover = obj.data.orig.thumbnail_url;
    if (lastCover != cover) {
	if (obj.data.src == 'tidal' && cover && cover !='') {
	    imgurl = cover.replace(/-/g,'\/');
	    var imgurl1 = tidalimage + imgurl + '/640x640.jpg';
	    var imgurl2 = tidalimage + imgurl + '/80x80.jpg';
	} 
	else {
	    if (cover == '' || cover == null) cover = 'icons/disc.svg';
	    var imgurl1 = cover;
	    var imgurl2 = cover;
//		imgurl = cover;
	}
//	var left = document.getElementById("leftSrc");
	if (obj.data.src == 'tidal' || obj.data.src == 'qobuz' || obj.data.src == 'youtube' || obj.data.src == 'radio' || obj.data.src == 'soundcloud') {
	    document.getElementById("currentSrc").style.backgroundImage ='url("pics/'+obj.data.src+'2.png")';
//	    left.addEventListener("onclick");
//	    left.style.backgroundImage ='url("pics/'+obj.data.src+'2.png")';
//	    if (obj.data.src != 'radio')
//		left.setAttribute("onclick","javascript: appGoto(\""+capitalize(obj.data.src)+"\")");
	}
	else {
	    document.getElementById("currentSrc").style.backgroundImage ='none';
//	    left.style.backgroundImage ='none';
//	    left.onclick='';
	}
	domCache.currentCover.style.backgroundImage = 'url("' + imgurl1 + '")';
	domCache.footerCover.style.backgroundImage = 'url("' + imgurl2 + '")';
    } else { 
	imgurl2 = cover; 
	imgurl1 = cover; 
    }

//    if (settings.featStickers == true) {
//        setVoteSongBtns(obj.data.like, obj.data.uri);
//    }

    if (obj.data.Stitle !== undefined) {
        domCache.currentTitle.innerText = obj.data.Stitle;
        domCache.currentTitle.setAttribute('data-uri', '');
    }
 
    //Update Artist in queue view for http streams
//    var playingTr = document.getElementById('queueTrackId' + obj.data.currentSongId);
//    if (playingTr)
//        playingTr.getElementsByTagName('td')[1].innerText = obj.data.Title;
    var coverbl = document.getElementById("coverblock");
    var flag = coverbl.classList.contains('hide');
    if (flag) {
        var body = document.body;
//        if (orig) {
    	if (obj.data.src == 'tidal') {
    	    imgurl = tidalimage + imgurl + '/1280x1280.jpg';
        }
    	
	body.style.backgroundImage = 'linear-gradient(to top, black 0%, transparent 100%), url('+ imgurl+')';
/*	if (imgurl.indexOf('tidal.com')!==-1) {
	    imgurl = imgurl.replace('320x320','1280x1280');
	}
	body.style.backgroundImage = 'linear-gradient(to top, black 0%, transparent 100%), url('+ imgurl+')';*/
    }
    if (playstate == 'play' && !flag) {
	if (document.body.clientWidth > 500)
    	    showNotification(title, textNotification, htmlNotification, 'light', imgurl2);
    }
    
    genMySVG(obj.data.Duration);
/*
    if (obj.data.src == 'tidal' || obj.data.src == 'qobuz') {  //|| == 'soundcloud'
	genMySVG(obj.data.orig.duration);
    } else {
	genMySVG(obj.data.Duration);
    }*/

    var waveform = document.getElementById('songwrapperbottom');
    if (obj.data.src == 'soundcloud') {
	waveform.style.background = 'url('+obj.data.orig.waveform+')'
    }
    else
	waveform.style.background = 'unset';
    lastSong = curSong;
    lastSongObj = obj;
//    lastCover = cover;
    lastCover = imgurl2;
}

function doSetFilterLetter(x) {
    var af = document.getElementById(x + 'Letters').getElementsByClassName('active')[0];
    if (af)
        af.classList.remove('active');
    var filter = app.current.filter;
    if (filter == '0')
        filter = '#';
    
    document.getElementById(x).innerText = 'Filter' + (filter != '-' ? ': '+filter : '');
    
    if (filter != '-') {
        var btns = document.getElementById(x + 'Letters').getElementsByTagName('button');
        var btnsLen = btns.length;
        for (var i = 0; i < btnsLen; i++) {
            if (btns[i].innerText == filter) {
                btns[i].classList.add('active');
                break;
            }
        }
    }
}

function addFilterLetter(x) {
    var filter = '<button class="mr-1 mb-1 btn btn-sm btn-secondary material-icons material-icons-small">delete</button>' +
        '<button class="mr-1 mb-1 btn btn-sm btn-secondary">#</button>';
    for (var i = 65; i <= 90; i++)
        filter += '<button class="mr-1 mb-1 btn-sm btn btn-secondary">' + String.fromCharCode(i) + '</button>';

    var letters = document.getElementById(x);
    letters.innerHTML = filter;
    
    letters.addEventListener('click', function(event) {
        switch (event.target.innerText) {
            case 'delete':
                filter = '-';
                break;
            case '#':
                filter = '0';
                break;
            default:
                filter = event.target.innerText;
        }
        appGoto(app.current.app, app.current.tab, app.current.view, '0/' + filter + '/' + app.current.search);
    }, false);
}

function selectTag(btnsEl, desc, setTo) {
//    console.log('-----selectTag-------');
//    console.log('btnsEl:'+btnsEl+', desc:'+desc+', setTo:'+setTo);
    var btns = document.getElementById(btnsEl);
    var aBtn = btns.querySelector('.active')
    if (aBtn)
        aBtn.classList.remove('active');
    aBtn = btns.querySelector('[data-tag="' + setTo + '"]');
    if (aBtn) {
        aBtn.classList.add('active');
        document.getElementById(desc).innerText = aBtn.innerText;
    }
}

function addTagList(el, list) {
//    console.log('addTagList-------');
    var tagList = '';
    if (list == 'searchtags') {
	if (settings.featTags == true)
    	    tagList += '<button type="button" class="btn btn-secondary btn-sm btn-block" data-tag="any">Any Tag</button>';
        tagList += '<button type="button" class="btn btn-secondary btn-sm btn-block" data-tag="filename">Filename</button>';	
    }
    for (var i = 0; i < settings[list].length; i++)
        tagList += '<button type="button" class="btn btn-secondary btn-sm btn-block" data-tag="' + settings[list][i] + '">' + settings[list][i] + '</button>';
    document.getElementById(el).innerHTML = tagList;
}

function addTagList2(x, any) { // dimas
//    console.log('addTagList2-------');
    var tagList = '';
    var tags = ["7", "14", "30", "60", "90", "120", "182", "365", "730" ];
    for (var i = 0; i < tags.length; i++) {
	if (tags[i]>14) {
	    var months = Math.floor (tags[i] / 30);
        tagList += '<a class="dropdown-item" data-tag="' + tags[i] + '">' + months + ' months</a>';
	}
	else
        tagList += '<a class="dropdown-item" data-tag="' + tags[i] + '">' + tags[i] + ' days</a>';
    }
    var tagListEl = document.getElementById(x);
    tagListEl.innerHTML = tagList;
}

function addTagList3(x, any) { // dimas
    var tagList = '';
    var tags = ["internal", "aplayer" ];
    for (var i = 0; i < tags.length; i++) {
        tagList += '<button type="button" class="btn btn-secondary btn-sm btn-block" data-tag="' + tags[i] + '">' + tags[i] + '</button>';
    }
    var tagListEl = document.getElementById(x);
    tagListEl.innerHTML = tagList;
}

function gotoTagList() {
//    console.log('---gotoTagList---');
    appGoto(app.current.app, app.current.tab, app.current.view, '0/-/');
}

function openModal(modal) {
    window[modal].show();
}

function openDropdown(dropdown) {
    window[dropdown].toggle();
}

function focusSearch() {
//    console.log('---focus-search---');
    if (app.current.app == 'Queue')
        document.getElementById('searchqueuestr').focus();
    else if (app.current.app == 'Browse' && app.current.tab == 'Search')
        document.getElementById('searchstr').focus();
    else
        appGoto('Browse','Search');
}

function chVolume(increment) {
    var newValue = (increment == 0 ? -1 : parseInt(domCache.volumeBar.value) + increment);
    if (newValue < 0) 
        newValue = 0
    else if (newValue > 100)
        newValue = 100;
    if (domCache.volumeBar.value == 0 && increment == 0) newValue = 100;
    domCache.volumeBar.value = newValue;
    sendAPI({"cmd": "MPD_API_PLAYER_VOLUME_SET", "data": {"volume": newValue}});
}


function beautifyDuration(x) {
    var days = Math.floor(x / 86400);
    var hours = Math.floor(x / 3600) - days * 24;
    var minutes = Math.floor(x / 60) - hours * 60 - days * 1440;
    var seconds = x - days * 86400 - hours * 3600 - minutes * 60;

    return (days > 0 ? days + 'd ' : '') +
        (hours > 0 ? hours + 'h ' + (minutes < 10 ? '0' : '') : '') +
        minutes + 'm ' + (seconds < 10 ? '0' : '') + seconds + 's';
}

function fullsc() {
    if (document.fullscreen) {
	if (document.cancelFullScreen) {
	    document.cancelFullScreen();
	} else if (document.mozCancelFullScreen) {
	    document.mozCancelFullScreen();
	} else if(document.webkitCancelFullScreen) {
	    document.webkitCancelFullScreen();
	}
    } else {
	if(domCache.body.requestFullScreen) {
	    domCache.body.requestFullScreen();
	} else if(domCache.body.mozRequestFullScreen) {
	    domCache.body.mozRequestFullScreen();
	} else if(domCache.body.webkitRequestFullScreen) {
	    domCache.body.webkitRequestFullScreen();
	}
    }
}

function auu(param) {
}


