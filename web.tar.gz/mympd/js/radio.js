"use strict";

function podcast(){
    sendAPI({"cmd": "API_RADIO_GROUPS","data":{"service":"aero"}}, parsePodcast);
    var cardContainer = document.getElementById('podcastList');
    if (phone) cardContainer.classList.add('phone');
    var cards = cardContainer.getElementsByClassName('my-item');
    if (cards.length == 0) {
        cardContainer.innerHTML = '';
//	sendAPI({"cmd": "API_RADIO_LIST","data": {"service":"aero","group": "2019"}},parsePodcastList); // заполняем 1 закладку
    }
}

function getServ(ap) {
    if (ap == 'SunRadio') return 'sunshine';
    if (ap == 'CapRadio') return 'radcap';
    if (ap == 'RedRadio') return 'onlinered';
    if (ap == 'APRadio') return 'apradio';
    if (ap == 'MyRadio') return 'mpdradio';
    if (ap == 'Soundcloud') return 'soundcloud';
    if (ap == 'Sygma') return 'sygma';
}

function getApp(serv) {
    if (serv == 'sunshine') return 'SunRadio';
    if (serv == 'radcap') return 'CapRadio';
    if (serv == 'onlinered') return 'RedRadio';
    if (serv == 'apradio') return 'APRadio';
    if (serv == 'mpdradio') return 'MyRadio';
    if (serv == 'soundcloud') return 'Soundcloud';
    if (serv == 'sygma') return 'Sygma';
}

function initradio() {
var apparr = ['APRadio','MyRadio','CapRadio','SunRadio','RedRadio','Soundcloud','Sygma'];
//var apparr = ['APRadio','MyRadio','CapRadio','SunRadio','RedRadio','Sygma'];
    var len = apparr.length;
    for (var i=0; i < len; i++) {
//	console.log(getServ(apparr[i]));
	sendAPI({"cmd": "API_RADIO_GROUPS","data":{"service":getServ(apparr[i])}}, parseRadio);
    }
}

function parseRadio(obj, request) {
var service = request.data.service;
    var nrItems = obj.length;

    var app1 = getApp(service);
    var cardContainer = document.getElementById(app1+'Menu');

    var card = document.getElementById('card'+app1);
    var pd = card.getElementsByClassName('dropdown-menu');

    if (app1 == 'MyRadio') {

    	var name = 'All';
        app.apps.MyRadio.tabs[name] = { "state": "0/-/", "scrollPos": 0 };
        var item = document.createElement('div');
	item.classList.add('card-cloud');
        item.id = 'card'+app1+'Nav'+name;
	item.innerHTML = '' +
         ' <a class="clickable" onclick=\'appGoto("MyRadio","'+name+'");\'>'+
         '  <span class="cloud-title talb">' + name + '</span>' +
         '</div>';
        cardContainer.appendChild(item);

        var item = document.createElement('a');
        item.classList.add('dropdown-item');
        item.classList.add('clickable');
        item.onclick = createClickHandler(app1,name);
        var textNode = document.createTextNode(name);
        item.id = 'card'+app1+'Drop'+name;
        item.appendChild(textNode);
        pd[0].appendChild(item);

      for (var i = 0; i < nrItems; i++) {
    	var name = obj[i];
        app.apps.MyRadio.tabs[name] = { "state": "0/-/", "scrollPos": 0 };
        var item = document.createElement('div');
	item.classList.add('card-cloud');
        item.id = 'card'+app1+'Nav'+name;
	item.innerHTML = '' +
         ' <a class="clickable" onclick=\'appGoto("MyRadio","'+name+'");\'>'+
         '  <span class="cloud-title talb">' + name + '</span>' +
         '</div>';
        cardContainer.appendChild(item);

        var item = document.createElement('a');
        item.classList.add('dropdown-item');
        item.classList.add('clickable');
        item.onclick = createClickHandler(app1,name);
        var textNode = document.createTextNode(name);
        item.id = 'card'+app1+'Drop'+name;
        item.appendChild(textNode);
        pd[0].appendChild(item);
      }
    
    } else {
//      console.log(app1);
      if (app1 == 'Soundcloud') { // search
        var item = document.createElement('a');
        item.classList.add('list-group-item');
        item.id = 'card'+app1+'Navsearch';
        item.href = '#';
        item.onclick = createClickHandler(app1,'search');
    	var textNode = document.createTextNode('** Search **');
    	item.appendChild(textNode);
        cardContainer.appendChild(item);
      }

      for (var i = 0; i < nrItems; i++) {
        if (app1 == 'SunRadio')
    	    app.apps.SunRadio.tabs[i] = { "state": "0/-/", "scrollPos": 0 };
        if (app1 == 'CapRadio')
    	    app.apps.CapRadio.tabs[i] = { "state": "0/-/", "scrollPos": 0 };
        if (app1 == 'RedRadio')
    	    app.apps.RedRadio.tabs[i] = { "state": "0/-/", "scrollPos": 0 };
        if (app1 == 'APRadio')
    	    app.apps.APRadio.tabs[i] = { "state": "0/-/", "scrollPos": 0 };
        if (app1 == 'Soundcloud')
    	    app.apps.Soundcloud.tabs[i] = { "state": "0/-/", "scrollPos": 0 };
        if (app1 == 'Sygma') {
    	    app.apps.Sygma.tabs[i] = { "state": "0/-/", "scrollPos": 0 };
//    	    console.log('***sygma');
    	}
    	    
        var item = document.createElement('a');
        item.classList.add('list-group-item');
        item.id = 'card'+app1+'Nav'+i;
        item.href = '#';
        item.onclick = createClickHandler(app1,i);
        if (app1 == 'APRadio') {
    	    var v = obj[i].name;
    	    v = v.replace(/\(/g,"<span class=\"badge badge-light2\">");
    	    v = v.replace(/\)/g,"</span>");
	    item.innerHTML = v;
        } else {
            if (app1 == 'Soundcloud' || app1 == 'Sygma') {
    		var textNode = document.createTextNode(obj[i].title);
    	    }
	    else {
    		var textNode = document.createTextNode(obj[i].name);
    	    }
    	    item.appendChild(textNode);
    	    if (app1 == 'Sygma') item.setAttribute("data-desc",obj[i].desc);

    	}
        cardContainer.appendChild(item);
        
        var item = document.createElement('a');
        item.classList.add('dropdown-item');
        item.href = '#';
        item.onclick = createClickHandler(app1,i);
        if (app1 == 'Soundcloud' || app1 == 'Sygma') {
           var textNode = document.createTextNode(obj[i].title);
        } else {
           var textNode = document.createTextNode(obj[i].name);
        }
        item.appendChild(textNode);
        pd[0].appendChild(item);
      }
    }
}

function parsePodcast(obj) {
    var nrItems = obj.length;

    var cardContainer = document.getElementById('podcastMenu');
      for (var i = 0; i < nrItems; i++) {
        app.apps.Podcast.tabs[obj[i].name] = { "state": "0/-/", "scrollPos": 0 };
        var item = document.createElement('a');
        item.classList.add('list-group-item');
        item.id = 'cardPodcastNav'+obj[i].name;
        item.href = '#';
        item.onclick = createClickHandler('Podcast',obj[i].name);
        var textNode = document.createTextNode(obj[i].name);
        item.appendChild(textNode);
        cardContainer.appendChild(item);
      }
}

function playCloud(tab,id){
    sendAPI({"cmd": "API_SOUNDCLOUD_REPLACE_PLAYLIST", "data": {"tab":tab,"id":id}});
//    showNotification('Soundcloud play', '', '', 'success');
}

function playCloudURL(type,id,e){
    sendAPI({"cmd": "API_SOUNDCLOUD_CMD", "data": {"cmd":"play","type":type,"id":id}});
//    showNotification('Soundcloud play', '', '', 'success');
    e.stopPropagation();
}

function parsecastInfo(obj){
    var title = document.getElementById('radTitle');
    title.innerHTML = obj.desc;
    var cardContainer = document.getElementById('radInfo');
    cardContainer.innerHTML = "";

    var div = document.createElement('div');
    div.classList.add('cast-item');
    div.innerHTML = 
    		'<div class="card-item-imgw item-wrapper" onclick=\'replaceQueue("song","'+obj.url+'","Podcast");modalRadio.hide();\'>'+
                    '<img class="lozad" src="' + obj.img + '" width="100%" height="100%">' +
                    '<div class="overlayv">'+
                    '     <button class="btn material-icons" type="button" role="button" onclick=\'replaceQueue("song","'+obj.url+'","Podcast")\'>play_arrow</button>'+
                    '</div>'+
                '</div>'+
            	'<div class="cast-item-body">'+
            		'<h5>'+obj.title+'</h5>'+
            		'<p class="card-item-title">'+obj.date+'</p>'+
            		'<p class="card-text">Duration: '+obj.duration+'</p>'+
            	'</div>';
    observer.observe();
    cardContainer.appendChild(div);
    var div = document.createElement('p');
    div.innerHTML = obj.summary;
    cardContainer.appendChild(div);
    modalRadio.show();
}

function castInfo(a){
    sendAPI({"cmd":"API_RADIO_INFO","data":{"service":"aero","group":a}},parsecastInfo);
}

function parsePodcastList(obj){
    var nrItems = obj.length;
    var cardContainer = document.getElementById('podcastList');
    cardContainer.innerHTML = '';
    
    for (var i = 0; i < nrItems; i++) {
//        var card = document.createElement('li');
        var card = document.createElement('a');
        card.setAttribute("data-id",obj[i].id);
    	card.classList.add('my-item');
    	card.classList.add('list-group-item');
    	card.classList.add('clickable');

	var v = obj[i].name;
        v = v.replace(/\(/g,"<span class=\"badge badge-light2\">");
        v = v.replace(/\)/g,"</span>");
        card.innerHTML = v;

//    	card.onclick = 'castInfo("'+obj[i].id+'")';
	card.addEventListener("click",function(event){
	    castInfo(this.getAttribute("data-id"))},false);
//        card.innerHTML = '<a class="clickable" onclick=\'castInfo("'+obj[i].id+'")\'>'+v+'</a>';

//        ul.appendChild(card);
	cardContainer.appendChild(card);

    }
//    cardContainer.appendChild(ul);
    modalLoader.hide();
}

function parseCapInfo(obj){
    var title = document.getElementById('radTitle');
    title.innerHTML = 'Info';
    var cardContainer = document.getElementById('radInfo');
    cardContainer.innerHTML = "";

    var div = document.createElement('div');
    div.classList.add('cast-item2');
    div.innerHTML = 
    		'<div class="card-item-img240 item-wrapper" onclick=\'replaceQueue("song","'+obj.url+'","Radio Caprice");modalRadio.hide();\'>'+
                    '<img src="http://radcap.ru/' + obj.img + '" width="100%" height="100%">' +
                    '<div class="overlayv">'+
                    '     <button class="btn material-icons clickable" type="button" role="button" onclick=\'replaceQueue("song","'+obj.url+'","Radio")\'>play_arrow</button>'+
                    '</div>'+
            	'</div>';

    cardContainer.appendChild(div);
    var div = document.createElement('p');
    div.innerHTML = obj.desc;
    cardContainer.appendChild(div);
    modalRadio.show();
}

function getRedInfo(group,id){
    if (group != null)
	sendAPI({"cmd": "API_RADIO_INFO","data":{"service":"onlinered","group":group,"id":id}}, parseRedInfo); //menu
}

function getCapInfo(group,id){
    if (group != null)
	sendAPI({"cmd": "API_RADIO_INFO","data":{"service":"radcap","group":group,"id":id}}, parseCapInfo); //menu
}


function parseRedInfo(obj,request){
    var title = document.getElementById('radTitle');
    title.innerHTML = obj.name;
    var cardContainer = document.getElementById('radInfo');
    cardContainer.innerHTML = "";

    var div = document.createElement('div');
    div.classList.add('cast-item2');
    div.innerHTML = 
    		'<div class="card-item-img240 item-wrapper" onclick=\'replaceQueue("song","'+obj.url+'","");modalRadio.hide();\'>'+
                    '<img src="' + obj.img + '" width="100%" height="100%">' +
                    '<div class="overlayv">'+
                    '     <button class="btn material-icons clickable" type="button" role="button" onclick=\'replaceQueue("song","'+obj.url+'","")\'>play_arrow</button>'+
                    '</div>'+
            	'</div>';

    cardContainer.appendChild(div);
    var div = document.createElement('p');
    div.innerHTML = obj.desc;
    cardContainer.appendChild(div);
    modalRadio.show();
}

function parseSygmaInfo(id){
    var el = document.getElementById(id);
    var title = document.getElementById('radTitle');

    title.innerHTML = el.getAttribute('data-title');
    var url = el.getAttribute('data-url');
    var cardContainer = document.getElementById('radInfo');
    cardContainer.innerHTML = "";

    var div = document.createElement('div');
    div.classList.add('cast-item2');
    div.innerHTML = 
    		'<div class="card-item-img240 item-wrapper" onclick=\'replaceQueue("song","' + url + '","");modalRadio.hide();\'>'+
                    '<img src="' + el.getAttribute('data-img') + '" width="100%" height="100%">' +
                    '<div class="overlayv">'+
                    '     <button class="btn material-icons" type="button" role="button" onclick=\'replaceQueue("song","' + url + '","")\'>play_arrow</button>'+
                    '</div>'+
            	'</div>';

    var pd = el.getElementsByClassName('card-text');

    cardContainer.appendChild(div);
    var div = document.createElement('p');
    div.innerHTML = pd[0].innerHTML;
    cardContainer.appendChild(div);
    modalRadio.show();
}

function favclick(a,e) {
var type = a.getAttribute('data-type');
var url = a.getAttribute('data-url');
    e.stopPropagation();
    var flag = a.classList.contains('fav');
    if (flag) {
	sendAPI({"cmd": "API_FAV_REM","data":{"type":type,"name":"-","url":url}});
	a.classList.remove('fav');
    } else {
	sendAPI({"cmd": "API_FAV_ADD","data":{"type":type,"url":url}});
	a.classList.add('fav');
    }
}

function editInfo(a,e){
var type = a.getAttribute('data-type');
    var favid = document.getElementById('favid');
    var favtype = document.getElementById('favtype');
    var favname = document.getElementById('favname');
    var favurl = document.getElementById('favurl');
    var favimg = document.getElementById('favimg');
    favtype.value = type;
    if (type == 'useradd') {
      favname.value = "";
      favurl.value = "";
      favimg.src = "/assets/coverimage-httpstream.png";
      favname.removeAttribute('readonly');
    } else {
      favid.value = a.id;
      favname.value = a.getAttribute('data-name');
      favurl.value = a.getAttribute('data-url');
      favimg.src = a.getAttribute('data-img');
      favimgurl.value = favimg.src;
      favname.setAttribute('readonly','readonly');
    }
    e.stopPropagation();
    modalFav.show();
}

function favchangeimg(a){
    document.getElementById('favimg').src = a.value;
}

function favremove(){
    var type = document.getElementById('favtype').value;
    var name = document.getElementById('favname').value;
    sendAPI({"cmd": "API_FAV_REM","data":{"type":type,"name":name}});
    var id = document.getElementById('favid').value;
    var item = document.getElementById(id).parentNode.parentNode;
    item.parentNode.removeChild(item);
}

function favupdate(){
    var id = document.getElementById('favid').value;
    var type = document.getElementById('favtype').value;
    var name = document.getElementById('favname').value;
    var url = document.getElementById('favurl').value;
    var img = document.getElementById('favimgurl').value;
    if (type == "useradd") {
	//add new element
	var a = document.getElementById('favaddbtn');
        var card = document.createElement('div');
    	card.classList.add('grid-smallest');
        var prev = a.parentNode.previousSibling.getElementsByClassName('favbox')[0];
        var previd = prev.id;
        previd = previd.replace('fav','')
        var i = parseInt(previd)+1;

        card.innerHTML = '<div class="card1">' +
    	     '<div id="fav'+i+'" class="clickable favbox material-icons" data-type="useradio" data-name="'+name+'" data-url="'+url+'" data-img="'+img+'" onclick="editInfo(this,event);">crop_free</div>'+
             ' <a class="clickable" onclick=\'replaceQueue("song","'+url+'","Fav")\'>'+
             ' <div class="item-wrapper"><img src="' + img + '" width="100%" height="100%">' +
	     '   <div class="overlay">' +
             '     <button class="btn material-icons" type="button" role="button" onclick=\'replaceQueue("song","'+url+'","Fav")\'>play_arrow</button>'+
	     ' </div></div></a>'+
             '  <span class="multititle talb clickable" title="'+name+'" onclick=\'replaceQueue("song","'+url+'","Fav")\'>' + name + '</span>' +
             '</div>'; 
	a.parentNode.parentNode.insertBefore(card,a.parentNode);
    } else {
	//update
	var item = document.getElementById(id);
	var img0 = item.parentNode.getElementsByTagName('img')[0];
	img0.src = img;
	// onclick, simple reload page ?
	item.setAttribute('data-url',url);
	item.setAttribute('data-img',img);
//	document.getElementById('favimgurl').value =;
    }
    sendAPI({"cmd": "API_FAV_UPDATE","data":{"type":type,"name":name,"url":url,"img":img}},function(){ appGoto("Fav");});
}

function parseFavorites(obj,request){
    var cardContainer = document.getElementById('favList');
    cardContainer.innerHTML = '';
    var nrItems = obj.length;
/*    if (phone) {
    cardContainer.classList.add('phone');
    cardContainer.classList.remove('row');
    var ul = document.createElement('ul');
    ul.classList.add('list-group');
    for (var i = 0; i < nrItems - 1; i++) {
	var li = document.createElement('li');
	li.classList.add('list-group-item');
        var item = obj[i];
	li.innerHTML = '<a href="#" onclick=\'replaceQueue("song","'+item.url+'","Fav")\'><div style="width:40px;"><img src="'+item.img+'" style="width:100%"></div><span class="title">'+item.name+'</span></a>';
	ul.appendChild(li);
    }
    cardContainer.appendChild(ul);
    } else {*/
    for (var i = 0; i < nrItems; i++) {
        var card = document.createElement('div');
        var item = obj[i];
    	card.classList.add('grid-smallest');
    	
        card.innerHTML = '<div class="card1">' +
    	     '<div id="fav'+i+'" class="clickable favbox material-icons" data-type="'+item.type+'" data-name="'+item.name+'" data-url="'+item.url+'" data-img="'+item.img+'" onclick="editInfo(this,event);">crop_free</div>'+
             ' <a class="clickable" onclick=\'replaceQueue("song","'+item.url+'","Fav")\'>'+
             ' <div class="item-wrapper"><img class="lozad" src="/assets/coverimage-httpstream.png" data-src="' + item.img + '" width="100%" height="100%">' +
	     '   <div class="overlay">' +
             '     <button class="btn material-icons" type="button" role="button" onclick=\'replaceQueue("song","'+item.url+'","Fav")\'>play_arrow</button>'+
	     ' </div></div></a>'+
             '  <span class="multititle talb clickable" title="'+item.name+'" onclick=\'replaceQueue("song","'+item.url+'","Fav")\'>' + item.name + '</span>' +
             '</div>'; 

	cardContainer.appendChild(card);
    }
//    }
    var card = document.createElement('div');
    card.classList.add('grid-smallest');
    card.style.position = 'relative';
    	
    card.innerHTML = '<a id="favaddbtn" class="btn btn-secondary addfav" data-type="useradd" onclick="editInfo(this,event);"><i class="material-icons" style="font-size:50px;">add_circle</i>'+
         '</a>'; 

    cardContainer.appendChild(card);

    observer.observe();
    modalLoader.hide();
}

function parseRadioList(obj,request){
    var serv = request.data.service;
    var app1 = getApp(serv);
    
    var nrItems = obj.length;
    var cardContainer = document.getElementById(app1+'List');
    if (phone) { 
	cardContainer.classList.add('phone');
//	cardContainer.classList.remove('row');
    }
    cardContainer.innerHTML = '';
    if (app1 == 'APRadio') {
      if (phone) cardContainer.classList.remove('row');
      if (nrItems <= 14) {
        var ul = document.createElement('div');
        ul.classList.add('list-group');
        ul.classList.add('auto');
      }
      for (var i = 0; i < nrItems; i++) {
        var card = document.createElement('a');
    	if (nrItems>14) 
    	    card.classList.add('my-item');
    	card.classList.add('list-group-item');
    	card.classList.add('clickable');
        card.setAttribute('data-url',obj[i].url);

	var v = obj[i].name;
        v = v.replace(/\(/g,"<span class=\"badge badge-light2\">");
        v = v.replace(/\)/g,"</span>");
    	
        card.innerHTML = v + '<span class="favbox opa clickable material-icons" data-type="apradio" data-url="'+obj[i].url+'" onclick="favclick(this,event)">favorite</span>';

	card.addEventListener("click",function(event){
	    replaceQueue("song",this.getAttribute("data-url"),"AP Radio")},false);

      if (nrItems > 14)
	cardContainer.appendChild(card);
      else
        ul.appendChild(card);
      }
      if (nrItems <= 14)
	cardContainer.appendChild(ul);
    }
    if (app1 == 'SunRadio') {
//      if (phone) {
//      } else {
      var tab = app.apps.SunRadio.active;
      for (var i = 0; i < nrItems - 1; i++) {
        var card = document.createElement('div');
    	card.classList.add('grid-small');
    	
        card.innerHTML = '<div class="card1">' +
    			     '<div class="clickable favbox material-icons" data-type="sunradio" data-url="'+obj[i].url+'" onclick="favclick(this,event)">favorite</div>'+
                             ' <a class="clickable" id="red'+i+'" data-group="'+tab+'" data-id="'+i+'" data-toggle="popover">'+
                             ' <div class="item-wrapper">'+
                             '<img class="lozad" src="icons/disc.svg" data-src="' + obj[i].img + '" width="100%" height="100%">' +
			     '   <div class="overlay">' +
                             '     <button class="btn material-icons" type="button" role="button" onclick=\'replaceQueue("song","'+obj[i].url+'","SunRadio")\'>play_arrow</button>'+
			     ' </div></div></a>'+
                             '  <span class="multititle talb clickable" title="'+obj[i].name+'" onclick=\'replaceQueue("song","'+obj[i].url+'","SunRadio")\'>' + obj[i].name + '</span>' +
                             '</div>'; 

            cardContainer.appendChild(card);

      }
//      }
    }
    if (app1 == 'RedRadio'){
      var nrItems = obj.items.length;
      var tab = app.apps.RedRadio.active;
      for (var i = 0; i < nrItems - 1; i++) {
        var card = document.createElement('div');
        var item = obj.items[i];
    	card.classList.add('grid-small');
    	
        card.innerHTML = '<div class="card1">' +
    			     '<div class="clickable favbox material-icons" data-type="redradio" data-url="'+item.url+'" onclick="favclick(this,event)">favorite</div>'+
                             ' <a class="clickable" id="red'+i+'" onclick=\'getRedInfo("'+tab+'","'+i+'")\' data-group="'+tab+'" data-id="'+i+'" data-toggle="popover">'+
                             ' <div class="item-wrapper ensemble"><img class="lozad" src="icons/disc.svg" data-src="' + item.img + '" width="100%" height="100%">' +
			     '   <div class="overlay">' +
                             '     <button class="btn material-icons" type="button" role="button" onclick=\'replaceQueue("song","'+item.url+'","RedRadio")\'>play_arrow</button>'+
			     ' </div></div></a>'+
                             '  <span class="multititle talb clickable" title="'+item.name+'" onclick=\'replaceQueue("song","'+item.url+'","RedRadio")\'>' + item.name + '</span>' +
                             '  <span class="multititle tart2">' + item.span + '</span>' +
                             '</div>'; 

	card.addEventListener("click",function(event){
	    getRedInfo(this.getAttribute("data-group"),this.getAttribute("data-id"))},false);

        cardContainer.appendChild(card);

      }
    }
    if (app1 == 'CapRadio') {
      if (phone) cardContainer.classList.remove('row');
      var tab = app.apps.CapRadio.active;
      var ul = document.createElement('div');
      if (!phone && nrItems >14)
	ul.classList.add('row');
//    ul.classList.add('auto');
      for (var i = 0; i < nrItems; i++) {
        var card = document.createElement('a');
        if (nrItems >14)
    	    card.classList.add('my-item');
    	card.classList.add('list-group-item');
    	card.classList.add('clickable');
        card.setAttribute('data-url',obj[i].url);
        card.setAttribute('data-group',tab);
        card.setAttribute('data-id',obj[i].link);

        card.innerHTML = obj[i].name+'<span class="favbox opa clickable material-icons" data-type="capradio"  data-url="'+obj[i].url+'" onclick="favclick(this,event)">favorite</span>';

	card.addEventListener("click",function(event){
	    getCapInfo(this.getAttribute("data-group"),this.getAttribute("data-id"));
	    },false);

        ul.appendChild(card);

      }
      cardContainer.appendChild(ul);

    
    }
    if (app1 == 'MyRadio') {
      var tab = app.apps.MyRadio.active;
      if (tab == 'All') {
    	cardContainer.classList.remove('row');
        for (var i = 0; i < nrItems; i++) {
    	  var h5 = document.createElement('div');
    	  h5.innerHTML = '<h5>'+obj[i].group+'</h5>';
    	  h5.classList.add('group-header');
    	  cardContainer.appendChild(h5);
    	  var div = document.createElement('div');
          div.classList.add('row');
          var nr = obj[i].items.length;
          for (var j = 0; j<nr; j++) {
    	    var item = obj[i].items[j];
            var card = document.createElement('div');
     	    card.classList.add('grid-small');
            card.innerHTML = '<div class="card1">' +
    			     '<div class="clickable favbox material-icons" data-type="myradio" data-url="'+item.url+'" onclick="favclick(this,event)">favorite</div>'+
                             ' <a class="clickable" onclick=\'replaceQueue("song","' + item.url + '","MyRadio")\' data-placement="bottom">'+
                             ' <div class="item-wrapper"><img class="lozad" src="icons/disc.svg" data-src="http://' + location.host + item.img + '" width="100%" height="100%">' +
			     '   <div class="overlay">' +
                             '     <button class="btn material-icons" type="button" role="button" onclick=\'replaceQueue("song","' + item.url + '","MyRadio")\'>play_arrow</button>'+
			     ' </div></div></a>'+
                             '  <span class="multititle talb clickable" title="' + item.name+'" onclick=\'replaceQueue("song","' + item.url + '","MyRadio")\'>' + item.name + '</span>' +
                             '</div>'; 

            div.appendChild(card);

    	  }
          cardContainer.appendChild(div);
        }
      } else {
        cardContainer.classList.add('row');
        for (var i = 0; i < nrItems; i++) {
          var card = document.createElement('div');
    	  card.classList.add('grid-small');
          card.innerHTML = '<div class="card1">' +
    			     '<div class="clickable favbox material-icons" data-type="myradio" data-url="'+obj[i].url+'" onclick="favclick(this,event)">favorite</div>'+
                             ' <a class="clickable" onclick=\'replaceQueue("song","'+obj[i].url+'","MyRadio")\' data-placement="bottom">'+
                             ' <div class="item-wrapper"><img class="lozad" src="icons/disc.svg" data-src="http://' + location.host + obj[i].img + '" width="100%" height="100%">' +
			     '   <div class="overlay">' +
                             '     <button class="btn material-icons clickable" type="button" role="button" onclick=\'replaceQueue("song","'+obj[i].url+'","MyRadio")\'>play_arrow</button>'+
			     ' </div></div></a>'+
                             '  <span class="multititle talb clickable" title="'+obj[i].name+'" onclick=\'replaceQueue("song","'+obj[i].url+'","MyRadio")\'>' + obj[i].name + '</span>' +
                             '</div>'; 

            cardContainer.appendChild(card);

        }
      }
    }
    if (app1 == 'Soundcloud') {
      var tab=app.apps.Soundcloud.active;
      var art = '';
      for (var i = 0; i < nrItems; i++) {
        var card = document.createElement('div');
    	card.classList.add('card-item');
    	card.classList.add('mb-10');
    	card.innerHTML = 
    		'<div class="card-item-img" onclick=\'playCloud("'+tab+'","'+i+'")\'>'+
    		'<div class="item-wrapper">'+
                    '<img class="lozad" src="icons/disc.svg" data-src="' + obj[i].art + '" width="100%" height="100%">' +
                    '<div class="overlay">'+
                    '     <button class="btn material-icons" type="button" role="button" onclick=\'playCloud("'+tab+'","'+i+'")\'>play_arrow</button>'+
                    '</div>'+
                '</div></div>'+
            	'<div class="card-item-body">'+
            		'<p class="card-item-title clickable" onclick=\'playCloud("'+tab+'","'+i+'")\'>'+obj[i].title+'</p>'+
            		'<p class="card-text">'+obj[i].user+'</p>'+
            	'</div>';

        cardContainer.appendChild(card);
      }
    }
    if (app1 == 'Sygma') {
      for (var i = 0; i < nrItems; i++) {
        var card = document.createElement('div');
//    	card.classList.add('my-item2');
    	card.classList.add('card-itemw');
    	card.setAttribute('id',app1+i);
    	card.setAttribute('data-title',obj[i].title);
    	card.setAttribute('data-url',obj[i].mc_link);
    	card.setAttribute('data-img',obj[i].picture.small.url);
    	
    	var desc = obj[i].description;
    	desc = desc.replace(/"/g,'\'');

    	card.innerHTML = 
    		'<div class="card-item-imgw" onclick=\'replaceQueue("song","'+obj[i].mc_link+'","Radio Sygma")\'>'+
    		    '<div class="item-wrapper">'+
                    '<img class="lozad" src="icons/disc.svg" data-src="' + obj[i].picture.small.url + '" width="100%">' +
                    '<div class="overlay">'+
                    '     <button class="btn material-icons" type="button" role="button" onclick=\'replaceQueue("song","'+obj[i].mc_link+'","Radio Sygma")\'>play_arrow</button>'+
                    '</div>'+
                    '</div>'+
                '</div>'+
            	'<div class="card-item-body2" onclick="parseSygmaInfo(\''+app1+i+'\')">'+
            		'<p class="card-item-title clickable" onclick=\'replaceQueue("song","'+obj[i].mc_link+'","Radio Sygma")\'>'+obj[i].title+'</p>'+
//            		'<p class="card-text" data-toggle="popover" data-content="'+desc+'">'+desc+'</p>'+
//            		'<p class="card-item-title clickable" onclick="parseSygmaInfo(\"'+app1+i+'\")">'+obj[i].title+'</p>'+
            		'<p class="card-text" onclick="parseSygmaInfo(\''+app1+i+'\')">'+desc+'</p>'+
            	'</div>';

        cardContainer.appendChild(card);

      }
    }
    observer.observe();
    modalLoader.hide();
}

function parseScloudSearch(obj, request) {
    var len = 0;
    var cardContainer = document.getElementById('SoundcloudSbody');
    if (!request.data.offset) {
	while (cardContainer.firstChild) {
    	    cardContainer.removeChild(cardContainer.firstChild);
	};
    }
    len = obj.collection.length;
    
    if (request.data.type == 'tracks') {
	if (!request.data.offset) {
	    var tbl = document.createElement('ul');
	  
    	    var tr = document.createElement('li');
    	    tr.innerHTML = '<span class="track-cover"></span><span class="track-title">Title</span><span class="track-artist">Artist</span><span class="track-album">Genre</span><span class="track-duration">Time</span><span class="track-action"></span>'
    	    tr.classList.add('tracklist-label');
    	    tbl.appendChild(tr);
	    cardContainer.setAttribute('data-offset',20);
	} else {
    	    tbl = cardContainer.getElementsByClassName('tracklist')[0];
	    var offset = parseInt(cardContainer.getAttribute('data-offset'));
//	    offset = offset + len;
	    offset = offset + 20;
	    cardContainer.setAttribute('data-offset',offset);
	}
	for (var i = 0; i < len; i++) {
	    var item = obj.collection[i];
	    var img = item.artwork_url;
	    if (img == null) {
		var img = 'icons/disc.svg';
	    }
	    if (item.genre == "") {
		var genre = '&nbsp;';
	    } else {
		var genre = item.genre;
	    }
	    if (item.user) {
		var artist = item.user.username;
	    } else {
		var artist = '&nbsp;';
	    }

	    if (item.publisher_metadata) {
		if (item.publisher_metadata.artist) {
		    var artist = item.publisher_metadata.artist;
		}
	    } 
	    var url = item.permalink_url;
	
	    var tr = document.createElement('li');
	    tr.setAttribute('data-type','track');
	    tr.setAttribute('data-title',item.title);
	    tr.setAttribute('data-id',item.id);

	    tr.innerHTML = '<span class="track-cover">'+
	    '<a class="clickable" onclick=\'playCloudURL("track","'+item.id+'",event);\'>'+
	    '<div class="item-wrapper">'+
	    '<img class="lozad" src="icons/disc.svg" data-src="' + img + '" width="50px" height="50px">'+
	    '<div class="overlay">'+
                '<button class="btn material-icons" type="button" role="button" onclick=\'playCloudURL("track","'+item.id+'",event);\' title="Play">play_arrow</button>'+
	    '</div></div></a></span>'+
	    '<span class="track-title"><a onclick=\'playCloudURL("track","'+item.id+'",event);\' title="'+item.title+'">'+item.title+'</a></span>'+
	    '<span class="track-artist clickable"><a onclick="">' + artist + '</a></span>'+
	    '<span class="track-album"><a onclick="" title="' + genre + '">' + genre + '</a></span>'+
	    '<span class="track-duration">'+HHMMSS(parseInt(item.duration*0.001))+'</span>'+
	    '<span class="track-action"><a class="material-icons" onclick="showMenu2(this.parentNode,event);" title="Show menu">more_vert</a></span>';
    	    tbl.appendChild(tr);
	
	}
	if (!request.data.offset) {
    	    tbl.classList.add('tracklist');
	    cardContainer.appendChild(tbl);
	}
//    .duration, .description, .artwork_url, .genre,.created_at,.permalink_url,
// .waveform_url publisher_metadata.artist
    }
    if (request.data.type == 'albums') {
	if (!request.data.offset) {
	    var div = document.createElement('div');
    	    div.classList.add('row');
    	    if (phone) div.classList.add('phone');
	    cardContainer.setAttribute('data-offset',20);
	} else {
	    div = cardContainer.getElementsByClassName('row')[0];
	    var offset = parseInt(cardContainer.getAttribute('data-offset'));
	    offset = offset + 20;
	    cardContainer.setAttribute('data-offset',offset);
	}
	for (var i = 0; i < len; i++) {
	    var item = obj.collection[i];
	    if (item.tracks.length>0) {
	    var img = item.artwork_url;
    	    if (img == null) {
    		img = item.user.avatar_url;
    		if (img == null) img = 'icons/disc.svg';
    	    }
	    var url = item.permalink_url;
	    var card = document.createElement('div');
    	    card.classList.add('grid-item');
    	    card.innerHTML = '<div class="card1">' +
                             ' <a class="clickable" onclick=\'playCloudURL("album","'+url+'",event);\' title="Play">' +
                             '<div class="item-wrapper">' +
                             ' <img class="lozad" src="icons/disc.svg" data-src="' + img + '" width="100%" height="100%">' +
                             ' <div class="overlay">' +
                             '     <button class="btn material-icons" type="button" role="button" onclick=\'playCloudURL("album","'+url+'",event);\' title="Play">play_arrow</button>' +
                             ' </div>'+
                             '</div>'+
                             '</a>'+
                             '  <span class="item-title talb clickable" onclick=\'playCloudURL("album","'+url+'",event);\' title="'+item.title+'">' + item.title + '</span>' +
                             '  <span class="item-title tart" title="'+item.user.username+'">' + item.user.username + '</span>' +
                             '  <span class="item-title tart">' + item.set_type + '</span>' +
                             '</div>';

	    div.appendChild(card);
	    }
	}
	if (!request.data.offset)
	    cardContainer.appendChild(div);
// artwork_url,title ,tracks[],set_type ,permalink_url,uri, user.username
    }
    if (request.data.type == 'playlists') {
	if (!request.data.offset) {
	    var div = document.createElement('div');
    	    div.classList.add('row');
    	    if (phone) div.classList.add('phone');
	    cardContainer.setAttribute('data-offset',20);
	} else {
	    div = cardContainer.getElementsByClassName('row')[0];
	    var offset = parseInt(cardContainer.getAttribute('data-offset'));
	    offset = offset + 20;
	    cardContainer.setAttribute('data-offset',offset);
	}
	for (var i = 0; i < len; i++) {
	    var item = obj.collection[i];
    	    var img = item.artwork_url;
    	    if (img == null) {
    		img = item.user.avatar_url;
    		if (img == null) img = 'icons/disc.svg';
    	    }
	    var url = item.permalink_url;
	    var card = document.createElement('div');
    	    card.classList.add('my-item');
    	    card.classList.add('grid-item');
    	    card.innerHTML = '<div class="card1">' +
                             ' <a class="clickable" onclick=\'playCloudURL("playlist","'+url+'",event);\' title="Play">'+
                             ' <div class="item-wrapper">'+
                             ' <img class="lozad" src="icons/disc.svg" data-src="' + img + '" width="100%" height="100%">' +
                             ' <div class="overlay">'+
                             '     <button class="btn material-icons" type="button" role="button" onclick=\'playCloudURL("playlist","'+url+'",event);\' title="Play">play_arrow</button>'+
                             ' </div></div></a>'+
                             ' <span class="item-title talb clickable" onclick=\'playCloudURL("playlist","'+url+'",event);\' title="'+item.title+'">' + item.title +'</span>' +
                             ' <span class="item-title tart" onclick="" title="'+item.user.username+'">' + item.user.username + '</span>' +
                             '</div>'; 

	    div.appendChild(card);
	
	}
	if (!request.data.offset)
	    cardContainer.appendChild(div);
//permalink_url,uri,title,user.username
    }
    observer.observe();
    modalLoader.hide();
}

function playSygma(a){
    var img = a.style.backgroundImage;
    var title = a.getAttribute("data-name");
    replaceQueue('song',a.getAttribute("data-url"),'Radio Sygma');
    setTimeout(function(){ 
	domCache.currentCover.style.backgroundImage = img;
	domCache.footerCover.style.backgroundImage = img;
	domCache.currentTitle.innerHTML = title;
	document.getElementById('cardPlaybackTags').style.display = 'none';
    },6000);
}


function searchSoundcloud(query,type){
    if (type == undefined)
	type = document.getElementById('scloudsearchType').value;

    sendAPI({"cmd": "API_SOUNDCLOUD_SEARCH","data":{"query":encodeURI(query), "type":type}},parseScloudSearch);
}
