//var height = 20;
//var notchPercentHeight = 90;

function formatTime(seconds, dur) {
  if (seconds / 60 >= 1) {
    const minutes = parseInt(seconds / 60, 10);
    seconds = parseInt(seconds % 60, 10);
    seconds = (seconds < 10) ? '0' + seconds : seconds;
    return (dur > 1800 ? '' + minutes+'m':'' + minutes + ':' + seconds);
  }
  return Math.round(seconds * 1000) / 1000;
}

function timeInterval(pxPerSec) {
  if (pxPerSec >= 25) {
     return 1;
  } else if (pxPerSec * 5 >= 25) {
     return 5;
  } else if (pxPerSec * 15 >= 25) {
     return 15;
  }
  return Math.ceil(0.5 / pxPerSec) * 60;
}

function primaryLabelInterval(pxPerSec) {
  if (pxPerSec >= 25) {
     return 10;
  } else if (pxPerSec * 5 >= 25) {
     return 6;
  } else if (pxPerSec * 15 >= 25) {
     return 4;
  }
  return 4;
}

function secondaryLabelInterval(pxPerSec) {
  if (pxPerSec >= 25) {
     return 5;
  } else if (pxPerSec * 5 >= 25) {
     return 2;
  } else if (pxPerSec * 15 >= 25) {
     return 2;
  }
  return 2;
}

//const fontSize1 = fontSize * wsParams.pixelRatio;

function genMySVG(duration) {
  var wr = document.getElementById("songwrapperbottom");
  var sv = document.getElementById("songwrappersvg");
  sv.innerHTML = '';
  if (duration == 0) return;
  var width = document.body.clientWidth - 194;
  var pixelsPerSec = width / duration;
  var primaryInterval = primaryLabelInterval(pixelsPerSec);
  var secondaryInterval = secondaryLabelInterval(pixelsPerSec);
  var curPixel = 0;
  var curSeconds = 0;
  var svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.setAttribute("width", width);
  svg.setAttribute("height", "50");
  var interval = timeInterval(pixelsPerSec);
  for (var i = 0; i < duration / interval; i++) {
     const cir1 = document.createElementNS("http://www.w3.org/2000/svg", "line");
     cir1.setAttribute("x1",curPixel);
     cir1.setAttribute("y2",30);
     cir1.setAttribute("x2",curPixel);
     if (i % primaryInterval == 0) {
        cir1.setAttribute("y1",12);
//        cir1.setAttribute("y2",3);
        cir1.setAttribute("stroke","white");
        var newText = document.createElementNS("http://www.w3.org/2000/svg","text");
        newText.setAttributeNS(null,"x",curPixel+5);     
        newText.setAttributeNS(null,"y",30); 
        newText.setAttributeNS(null,"font-size","10");
        newText.setAttributeNS(null,"fill","white");

        var textNode = document.createTextNode(formatTime(curSeconds,duration));
        newText.appendChild(textNode);
        svg.appendChild(newText);
     } else if (i % secondaryInterval == 0) {
//height1
//text
        cir1.setAttribute("y1",15);
        cir1.setAttribute("stroke","gray");

        var newText = document.createElementNS("http://www.w3.org/2000/svg","text");
        newText.setAttributeNS(null,"x",curPixel+5);     
        newText.setAttributeNS(null,"y",30); 
        newText.setAttributeNS(null,"font-size","10");
        newText.setAttributeNS(null,"fill","gray");

        var textNode = document.createTextNode(formatTime(curSeconds,duration));
        newText.appendChild(textNode);
        svg.appendChild(newText);

     } else {
//height2
        cir1.setAttribute("y1",15);
        cir1.setAttribute("stroke","gray");

        var newText = document.createElementNS("http://www.w3.org/2000/svg","text");
        newText.setAttributeNS(null,"x",curPixel+5);     
        newText.setAttributeNS(null,"y",30); 
        newText.setAttributeNS(null,"font-size","10");
        newText.setAttributeNS(null,"fill","gray");

        var textNode = document.createTextNode(formatTime(curSeconds,duration));
        newText.appendChild(textNode);
        svg.appendChild(newText);
     }
     svg.appendChild(cir1);
     curSeconds += interval;
     curPixel += pixelsPerSec * interval;
  } 
  svg.style.fontFamily = 'arial';
  sv.innerHTML = '';
  sv.appendChild(svg);
}
