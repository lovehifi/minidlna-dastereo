rm -rf ./tmp/*
rm -f /opt/utils/web.tar.gz
tar -zcvf /opt/utils/web.tar.gz .
sync
#sudo mv -f web.tar.gz /home