#!/bin/bash

sudo mkdir /tmp/muscache
sudo chmod 777 /tmp/muscache

mpdconf=/etc/mpd.conf
if test -f $mpdconf ; then
    a=$(stat -c %s $mpdconf)
else
    a=0
fi

#tidal=$(systemctl status tidal|grep Active)
#if [ -n "$(echo $tidal|grep running)" ]; then
    #sudo /opt/tidal/init.sh stop
    #sudo systemctl stop tidal
    #sudo systemctl disable tidal
#fi

if [ "$a" = "0" ]; then
    sudo cp -f /home/mpd.conf $mpdconf
    sudo /var/www/scripts/restorempd.sh
    sync; echo 3 >/proc/sys/vm/drop_caches
else
    username=$(cat /etc/mpd.conf |grep tidal -a2 |grep username)
    username=${us#*\"}
    username=${username%\"*}
    user=$(jq -r ".username" /home/tidal.json)
    if [ -z "$username" ] && [ -n "$user" ]; then
	sudo /var/www/scripts/restorempd.sh
	sync; echo 3 >/proc/sys/vm/drop_caches
    fi
fi

#sudo echo "123" > /tmp/123
proxy=$(cat $mpdconf |grep "proxy" |grep -v "#")
if [ -n "$proxy" ]; then
#    sudo echo "1$proxy" >> /tmp/123
    sudo /bin/systemctl enable polipo
    sudo /bin/systemctl start polipo
fi

echo "mpdcheck">>/tmp/run.log
